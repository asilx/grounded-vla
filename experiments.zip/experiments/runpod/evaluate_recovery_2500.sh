#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
while [ ! -f "$status/recovery-v10-1000-eval.exit" ]; do sleep 5; done
for i in $(seq 1 1800); do
  if [ -f "$status/recovery-v10-train-2500.exit" ]; then break; fi
  sleep 2
done
[ "$(cat "$status/recovery-v10-train-2500.exit")" = 0 ]
JAX_PLATFORMS=cpu TOKENIZERS_PARALLELISM=false timeout 6500 \
 /workspace/pi0-train-env/bin/grounded-vla-serve runs/franka-pi0-recovery-v10/step-00002500 \
 --host 127.0.0.1 --port 8000 --device cuda --num-steps 10 --inference-seed 37 --zero-noise \
 > "$status/recovery-v10-2500-task-server.log" 2>&1 &
server_pid=$!
echo "$server_pid" > "$status/recovery-v10-2500-task-server.pid"
trap 'kill "$server_pid" 2>/dev/null || true' EXIT
/workspace/pi0-train-env/bin/python - <<'PY'
import time
from grounded_vla.backends.openpi import OpenPiTransport
for i in range(240):
    try:
        with OpenPiTransport('ws://127.0.0.1:8000',timeout=1.) as c:
            assert c.metadata['checkpoint_step']==2500 and c.metadata['robot_interface_adaptation'] and c.metadata['action_expert_adaptation'] and c.metadata['action_encoding']=='bounded_joint_interval_logits'
        print('RECOVERY_2500_POLICY_READY',flush=True)
        break
    except Exception:time.sleep(1)
else:raise TimeoutError('Model did not become ready')
PY
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1
for seed in 0 1 2; do
 timeout 1800 /workspace/isaac6-env/bin/python -u experiments/runpod/evaluate_pi0_task.py \
   --seed "$seed" --execute-steps 1 --out "$status/recovery-v10-2500-task/seed-$seed" \
   > "$status/recovery-v10-2500-task-seed-$seed.log" 2>&1
done
