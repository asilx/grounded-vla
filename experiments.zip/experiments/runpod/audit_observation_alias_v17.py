import json
from pathlib import Path
import numpy as np
from learned_directional_v17 import read_numeric
p=Path('/workspace/grounded-vla/data/franka-recovery-v16/prepared.json');meta=json.loads(p.read_text());x,y,q,a=read_numeric(p,meta,'train',4)
# Exact and near identical inputs, with no extra unobserved phase features.
records=[]
for decimals in [6,4,3]:
 rounded=np.round(x,decimals);_,inverse,counts=np.unique(rounded,axis=0,return_inverse=True,return_counts=True)
 worst=[]
 for group in np.flatnonzero(counts>1):
  indices=np.flatnonzero(inverse==group);v=a[indices]-q[indices];spread=np.linalg.norm(v.max(0)[:7]-v.min(0)[:7]);finger=float(np.ptp(v[:,7:].mean(1)))
  if spread>.001 or finger>.001:
   worst.append({'count':len(indices),'indices':indices[:8].tolist(),'arm_delta_spread_rad':float(spread),'finger_delta_spread_m':finger,'max_input_difference':float(np.max(np.ptp(x[indices],axis=0)))})
 worst.sort(key=lambda z:z['arm_delta_spread_rad']+z['finger_delta_spread_m'],reverse=True)
 records.append({'rounding_decimals':decimals,'duplicate_groups':int(np.count_nonzero(counts>1)),'conflicting_groups':len(worst),'worst':worst[:10]})
report={'scope':'Training observation alias audit; near identical rounded inputs are not exact equality','samples':len(x),'audits':records}
Path('/workspace/grounded-forge-status/v17-observation-alias-audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
