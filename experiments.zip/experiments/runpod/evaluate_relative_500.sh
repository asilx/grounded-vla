#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
for i in $(seq 1 1800); do
  if [ -f "$status/relative-v8-train-500.exit" ]; then break; fi
  sleep 2
done
[ "$(cat "$status/relative-v8-train-500.exit")" = 0 ]
JAX_PLATFORMS=cpu TOKENIZERS_PARALLELISM=false timeout 3600 \
 /workspace/pi0-train-env/bin/grounded-vla-serve runs/franka-pi0-relative-v8/step-00000500 \
 --host 127.0.0.1 --port 8000 --device cuda --num-steps 10 --inference-seed 37 --zero-noise \
 > "$status/relative-v8-500-task-server.log" 2>&1 &
server_pid=$!
echo "$server_pid" > "$status/relative-v8-500-task-server.pid"
trap 'kill "$server_pid" 2>/dev/null || true' EXIT
/workspace/pi0-train-env/bin/python - <<'PY'
import time
from grounded_vla.backends.openpi import OpenPiTransport
for i in range(240):
    try:
        with OpenPiTransport('ws://127.0.0.1:8000',timeout=1.) as c:
            assert c.metadata['checkpoint_step']==500 and c.metadata['robot_interface_adaptation']
        print('GUARDED_2000_ZERO_POLICY_READY',flush=True)
        break
    except Exception:time.sleep(1)
else:raise TimeoutError('Model did not become ready')
PY
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1
for seed in 0; do
 timeout 1200 /workspace/isaac6-env/bin/python -u experiments/runpod/evaluate_pi0_task.py \
   --seed "$seed" --execute-steps 1 --out "$status/relative-v8-500-task/seed-$seed" \
   > "$status/relative-v8-500-task-seed-$seed.log" 2>&1
done
