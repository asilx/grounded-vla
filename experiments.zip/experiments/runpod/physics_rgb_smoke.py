from pathlib import Path
import json,importlib.metadata
ISAAC_VERSION=importlib.metadata.version('isaacsim')
import isaacsim
from isaacsim.simulation_app import SimulationApp
app=SimulationApp({'headless':True,'width':640,'height':480})
try:
    import numpy as np
    import omni.kit.app,omni.usd,carb
    from pxr import UsdLux,UsdGeom,Gf
    from PIL import Image
    manager=omni.kit.app.get_app().get_extension_manager()
    for ext in ['isaacsim.core.api','isaacsim.sensors.experimental.rtx']:
        manager.set_extension_enabled_immediate(ext,True)
    from isaacsim.core.api import World
    from isaacsim.core.api.objects import DynamicCuboid,FixedCuboid
    from isaacsim.sensors.experimental.rtx import RtxCamera,CameraSensor
    out=Path('/workspace/grounded-forge-status/physics-rgb-smoke'); out.mkdir(exist_ok=True,parents=True)
    world=World(stage_units_in_meters=1.0,physics_dt=1/60,rendering_dt=1/60)
    world.scene.add(FixedCuboid(prim_path='/World/Ground',name='ground',position=np.array([0.,0.,-.05]),scale=np.array([4.,4.,.1]),color=np.array([.25,.25,.25])))
    cube=world.scene.add(DynamicCuboid(prim_path='/World/Cube',name='cube',position=np.array([0.,0.,.8]),size=.1,color=np.array([1.,0.,0.])))
    stage=omni.usd.get_context().get_stage()
    UsdLux.DomeLight.Define(stage,'/World/Light').CreateIntensityAttr(1500.)
    camera=RtxCamera('/World/Camera',tick_rate=30.0)
    transform=UsdGeom.Xformable(stage.GetPrimAtPath('/World/Camera'))
    transform.ClearXformOpOrder()
    transform.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(0,0,2),Gf.Vec3d(0,0,0),Gf.Vec3d(0,1,0)).GetInverse())
    sensor=CameraSensor(camera,resolution=(480,640),annotators=['rgb'])
    world.reset()
    start,_=cube.get_world_pose(); poses=[]; valid_frames=0; rgba=None
    for step in range(240):
        world.step(render=True)
        position,_=cube.get_world_pose(); poses.append(position.tolist())
        data,info=sensor.get_data('rgb')
        if data is not None:
            a=data.numpy() if hasattr(data,"numpy") else np.asarray(data)
            if a.size and a.ndim==3:
                rgba=a.copy(); valid_frames+=1
    final,_=cube.get_world_pose()
    physics_ok=bool(np.isfinite(final).all() and start[2]-final[2]>.5 and .02<final[2]<.15)
    rgb_ok=bool(rgba is not None and rgba.shape[:2]==(480,640) and rgba.shape[-1] in [3,4] and np.isfinite(rgba).all() and np.std(rgba[...,:3])>1 and valid_frames>=3)
    if rgba is not None:
        np.save(out/'raw_rgb.npy',rgba)
        Image.fromarray(rgba.astype(np.uint8)).save(out/'camera.png')
    np.save(out/'cube_positions.npy',np.array(poses))
    result={'scope':'procedural cube gravity/contact and RTX camera smoke check','isaac_version':ISAAC_VERSION,'seed':0,'steps':240,'initial_position':start.tolist(),'final_position':final.tolist(),'physics_passed':physics_ok,'rgb_passed':rgb_ok,'valid_rgb_frames':valid_frames,'rgba_shape':None if rgba is None else list(rgba.shape),'rgba_dtype':None if rgba is None else str(rgba.dtype),'rgb_std':None if rgba is None else float(np.std(rgba[...,:3])),'multitick_enabled':carb.settings.get_settings().get('/rtx/hydra/supportMultiTickRate')}
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2),flush=True)
except BaseException:
    import traceback,sys
    traceback.print_exc(); sys.stderr.flush(); raise
finally:
    app.close()
