#!/usr/bin/env bash
set -u
ulimit -c 0
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 PYTHONUNBUFFERED=1
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
for seed in 0 1 2; do
    dir=$(printf '%s/franka-pilot/seed-%03d' "$status" "$seed")
    if [ -f "$dir/result.json" ]; then mv "$dir/result.json" "$dir/previous-result.json"; fi
    timeout 900 /workspace/isaac6-env/bin/python experiments/runpod/franka_pickplace_pilot.py --seed "$seed" > "$status/franka-seed-$seed.log" 2>&1
    process_exit=$?
    python3.11 - "$dir/result.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
sys.exit(0 if r['success'] else 1)
PY
    result=$?
    echo "$process_exit $result" > "$status/franka-seed-$seed.exit"
    if [ "$process_exit" != 0 ] || [ "$result" != 0 ]; then exit 1; fi
done
