"""Closed-loop learned Franka evaluation with independent physical success tests.

No scripted motion, policy-output clipping, or waypoint replay occurs here.
Graph geometry is simulator oracle data; semantic predicates remain unknown.
"""
import argparse
import json
from pathlib import Path


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--seed',type=int,required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--uri',default='ws://127.0.0.1:8000')
    p.add_argument('--config',default='configs/runpod-franka-guarded.json')
    p.add_argument('--max-steps',type=int,default=6000)
    p.add_argument('--execute-steps',type=int,default=10)
    args=p.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    from isaacsim import SimulationApp
    app=SimulationApp({'headless':True})
    env=client=None
    video_process=None;video_log=None;video_records=[]
    result={'scope':'Closed-loop learned numeric baseline; RGB and language unused; unchanged joint/step guards; no critic.',
            'seed':args.seed,'task_success':False,'executed_steps':0,'proposals':0,
            'graph_geometry':'simulator oracle poses','success_conditions':
            'Lift >70mm, destination XY error <40mm, Z error <30mm, gripper released/separated, stable for 120 physics steps.'}
    try:
        import numpy as np
        from PIL import Image
        from isaacsim.core.prims import SingleRigidPrim
        from grounded_vla.backends.isaacsim import IsaacSimConfig,IsaacSimEnvironment
        from grounded_vla.backends.openpi import OpenPiTransport
        from grounded_vla.belief import BeliefStore
        from grounded_vla.simulation import CanonicalSimPolicy,GraphSnapshot
        from grounded_vla.training.graph import encode_belief_graph
        from dataclasses import asdict
        config=IsaacSimConfig.load(args.config)
        result['environment_config']=asdict(config)
        env=IsaacSimEnvironment.from_config(config)
        gains=json.loads(Path('/workspace/grounded-forge-status/franka-expert-guarded-v7/seed-000/drive-gains.json').read_text())
        servo=env.robot.get_articulation_controller()
        assert config.robot_gravity_compensation
        assert np.allclose(config.drive_kp,gains['kp']) and np.allclose(config.drive_kd,gains['kd'])
        kp,kd=servo.get_gains()
        assert np.allclose(kp,gains['kp']) and np.allclose(kd,gains['kd'])
        result['drive_gains']=gains
        cargo=SingleRigidPrim('/World/Cargo',name='evaluation_cargo');cargo.initialize()
        gripper=SingleRigidPrim('/World/Robot/panda_rightfinger',name='evaluation_gripper');gripper.initialize()
        while env.world.current_time<1.:env._step_world()
        obs=env.observe()
        initial=cargo.get_world_pose()[0].copy();peak=float(initial[2]);stable=0
        goal=np.array([.3,-.3,.02575],np.float64)
        goal[:2]+=np.random.default_rng(args.seed).uniform(-.015,.015,size=2)
        result.update(initial_position=initial.tolist(),destination=goal.tolist(),initial_state=obs.state.tolist())
        client=OpenPiTransport(args.uri,timeout=120.)
        policy=CanonicalSimPolicy(client,config)
        if not 1<=args.execute_steps<=policy.max_horizon:raise ValueError('Invalid executed chunk prefix')
        result['policy_metadata']=policy.meta
        result['scope']='Closed-loop '+str(policy.meta.get('scope',policy.meta.get('policy','learned numeric policy')))
        snapshots=[]; captured=set(); snapshot_dir=out/'snapshots';snapshot_dir.mkdir()
        witness=witness_timer=None
        try:
            from isaacsim.sensors.experimental.rtx import CameraSensor,RtxCamera
            import omni.replicator.core as rep
            witness=CameraSensor(RtxCamera(config.camera_paths['base_0_rgb'],tick_rate=60.),resolution=(1024,1024),annotators=['rgb'])
            witness_timer=rep.AnnotatorRegistry.get_annotator('IsaacReadSimulationTime')
            witness_timer.attach([str(witness.render_product.GetPath())])
        except Exception as exc:
            result['document_camera_setup_error']=str(exc)
        import subprocess,shutil,hashlib
        if witness is None:raise RuntimeError('1024 documentary camera unavailable')
        video_log=(out/'pitch-video-encoder.log').open('w')
        video_process=subprocess.Popen([shutil.which('ffmpeg'),'-hide_banner','-loglevel','warning','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1024x1024','-r','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','18','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',str(out/'grounded-forge-v18-live-1024.mp4')],stdin=subprocess.PIPE,stdout=video_log,stderr=subprocess.STDOUT)
        def capture_video_frame():
            before_time=float(env.world.current_time);before_state=env._positions().copy()
            for _ in range(4):
                env.world.render()
                assert float(env.world.current_time)==before_time and np.array_equal(before_state,env._positions()),'Video render advanced physics'
                rgb,_=witness.get_data('rgb');timing=witness_timer.get_data()
                if rgb is None or not isinstance(timing,dict) or 'simulationTime' not in timing:continue
                rgb=rgb.numpy() if hasattr(rgb,'numpy') else np.asarray(rgb);ct=float(timing['simulationTime'])
                if rgb.dtype!=np.uint8 or rgb.shape!=(1024,1024,3) or not np.isfinite(ct) or ct>before_time+1e-6 or before_time-ct>.05:continue
                video_process.stdin.write(np.ascontiguousarray(rgb).tobytes());video_records.append(dict(frame=len(video_records),step=result['executed_steps'],simulation_time=before_time,camera_time=ct));return True
            if not video_records and result['executed_steps']<=120:return False
            raise RuntimeError('No fresh 1024 video camera frame')
        def save_snapshot(label,observation,cp,gp,*,success=False):
            record={'label':label,'step':result['executed_steps'],'simulation_timestamp':float(observation.timestamp),
                    'cube_position_m':cp.tolist(),'gripper_position_m':gp.tolist(),'joint_positions':observation.state.tolist(),
                    'destination_m':goal.tolist(),'camera_times':dict(env._last_camera_times),
                    'task_success_verified':bool(success),'policy_metadata':policy.meta,
                    'scope':'Actual simulator camera buffers and physical measurements; documentary only, never policy inputs or semantic labels.'}
            stem=f"{result['executed_steps']:06d}-{label}"
            record['images']={}
            for name,image in observation.images.items():
                filename=stem+'-'+name+'.png';Image.fromarray(image).save(snapshot_dir/filename);record['images'][name]=filename
            if witness is not None:
                before_time=float(env.world.current_time);before_state=env._positions().copy()
                for _ in range(4):
                    env.world.render()
                    assert float(env.world.current_time)==before_time and np.array_equal(before_state,env._positions()),'Document camera advanced physics'
                    rgb,_=witness.get_data('rgb');timing=witness_timer.get_data()
                    if rgb is None or not isinstance(timing,dict) or 'simulationTime' not in timing:continue
                    rgb=rgb.numpy() if hasattr(rgb,'numpy') else np.asarray(rgb)
                    ct=float(timing['simulationTime'])
                    if rgb.dtype!=np.uint8 or rgb.shape!=(1024,1024,3) or not np.isfinite(ct) or ct>before_time+1e-6 or before_time-ct>.05:continue
                    filename=stem+'-document-camera-1024.png';Image.fromarray(rgb).save(snapshot_dir/filename)
                    record['images']['document_camera_1024']=filename;record['document_camera_capture_time']=ct;break
            (snapshot_dir/(stem+'.json')).write_text(json.dumps(record,indent=2))
            snapshots.append(record);captured.add(label)
            (snapshot_dir/'index.json').write_text(json.dumps(snapshots,indent=2))
            result['snapshots']=snapshots
        save_snapshot('initial',obs,initial,gripper.get_world_pose()[0])
        capture_video_frame()
        def graph_for(observation):
            cp,_=cargo.get_world_pose();gp,_=gripper.get_world_pose()
            visible=False
            for image in observation.images.values():
                x=image.astype(np.float32)
                if int(((x[...,0]>60)&(x[...,0]>1.5*x[...,1])&(x[...,0]>1.5*x[...,2])).sum())>=4:visible=True
            objects=[dict(id='cargo',position=cp,visible=visible,is_target=True),
                     dict(id='goal',position=goal,visible=False,is_target=False),
                     dict(id='gripper',position=gp,visible=False,is_target=False)]
            relations=[('goal','target_of','cargo')]
            if np.linalg.norm(cp-gp)<.12:relations += [('cargo','near','gripper'),('gripper','near','cargo')]
            return GraphSnapshot(encode_belief_graph(BeliefStore(),objects,relations,now=observation.timestamp),observation.timestamp)
        for name,image in obs.images.items():Image.fromarray(image).save(out/(name+'-initial.png'))
        from grounded_vla.training.recording import EpisodeRecorder
        recorder=EpisodeRecorder(client.metadata['graph_schema_id'])
        capture_times=[];capture_fresh=[]
        result['recording_scope']='Actual accepted learned-policy actions and causal camera observations; failed trajectories are not successful distillation labels'
        result['reason']='budget_exhausted'
        with (out/'trace.jsonl').open('w') as trace,(out/'proposals.jsonl').open('w') as proposals:
            while result['executed_steps']<args.max_steps and not result['task_success']:
                snap=graph_for(obs)
                actions=policy.infer(obs,snap,'Place the red cube at the graph goal.')
                assert env.world.current_time==obs.timestamp
                result['proposals']+=1
                proposals.write(json.dumps({'timestamp':obs.timestamp,'state':obs.state.tolist(),
                    'actions':actions.tolist(),'graph_features':snap.graph['features'].tolist()})+'\n');proposals.flush()
                for action in actions[:min(args.execute_steps,args.max_steps-result['executed_steps'])]:
                    before=env._positions();before_time=float(env.world.current_time)
                    previous_observation=obs
                    previous_camera_times=dict(env._last_camera_times)
                    try:obs=env.step(action)
                    except ValueError as exc:
                        if not str(exc).startswith('Action exceeds'):raise
                        assert env.world.current_time==before_time and np.array_equal(before,env._positions())
                        result.update(verified=True,reason='guard_rejected',rejection=str(exc),physics_unchanged_on_rejection=True,
                                      rejected_action=action.tolist(),rejected_from_state=before.tolist())
                        return
                    recorder.append(state=previous_observation.state,action=action,images=previous_observation.images,prompt='Place the red cube at the graph goal.',graph=snap.graph,timestamp=float(previous_observation.timestamp),graph_timestamp=float(snap.timestamp))
                    capture_times.append([previous_camera_times[k] for k in ('base_0_rgb','left_wrist_0_rgb')])
                    capture_fresh.append([True,True] if len(capture_times)==1 else [capture_times[-1][i]>capture_times[-2][i] for i in range(2)])
                    result['executed_steps']+=1
                    cp,_=cargo.get_world_pose();gp,_=gripper.get_world_pose()
                    peak=max(peak,float(cp[2]))
                    error=float(np.linalg.norm(cp[:2]-goal[:2]))
                    released=bool(np.linalg.norm(cp-gp)>.08 and np.min(obs.state[7:])>.026)
                    candidate=bool(peak>initial[2]+.07 and error<.04 and abs(cp[2]-goal[2])<.03 and released)
                    stable=stable+1 if candidate else 0
                    trace.write(json.dumps({'step':result['executed_steps'],'timestamp':obs.timestamp,
                        'cube_position':cp.tolist(),'joint_positions':obs.state.tolist(),'peak_height':peak,
                        'xy_error':error,'released':released,'stable_steps':stable,'camera_times':env._last_camera_times})+'\n')
                    trace.flush()
                    result.update(final_position=cp.tolist(),peak_height_m=peak,planar_error_m=error,
                                  stable_steps=stable,final_timestamp=obs.timestamp)
                    if result['executed_steps']%2==0 or stable>=120:capture_video_frame()
                    if result['executed_steps']%120==0:
                        Image.fromarray(obs.images['base_0_rgb']).save(out/f"frame-{result['executed_steps']:06d}.png")
                        print('LEARNED_TASK_PROGRESS',args.seed,result['executed_steps'],error,peak,flush=True)
                    if cp[2]>initial[2]+.07 and 'first_lift_gt70mm' not in captured:
                        save_snapshot('first_lift_gt70mm',obs,cp,gp)
                    if cp[2]>initial[2]+.07 and np.linalg.norm(cp-gp)<.08 and np.linalg.norm(cp[:2]-initial[:2])>.10 and 'transport_after_lift_gt10cm' not in captured:
                        save_snapshot('transport_after_lift_gt10cm',obs,cp,gp)
                    if candidate and 'release_candidate' not in captured:
                        save_snapshot('release_candidate',obs,cp,gp)
                    if stable>=120:
                        result.update(task_success=True,reason='independent_physical_success')
                        save_snapshot('final_success_stable120',obs,cp,gp,success=True)
                        break
        result['verified']=True
    except BaseException as exc:
        result.update(verified=False,reason='error',error_type=type(exc).__name__,error=str(exc))
        raise
    finally:
        if video_process is not None:
            video_process.stdin.close();encoder_exit=video_process.wait(timeout=120)
            video_log.close()
            result['pitch_video']={'filename':'grounded-forge-v18-live-1024.mp4','encoder_exit':encoder_exit,'frames':len(video_records),'fps':30,'source_resolution':[1024,1024],'camera_warmup_skipped_steps':video_records[0]['step'] if video_records else None,'scope':'New live learned-controller rollout; actual native documentary camera frames, sampled every second physics step after camera warmup and at final success; no interpolated frames or scripted command replay'}
            (out/'video-capture-records.json').write_text(json.dumps(video_records,indent=2))
            if encoder_exit!=0:result.update(verified=False,reason='video_encoder_failure')
        if 'recorder' in locals() and capture_times:
            recording=out/'learned-rollout.npz'
            recorder.save(recording)
            with np.load(recording,allow_pickle=False) as z: arrays={k:z[k] for k in z.files}
            arrays['capture_timestamps']=np.asarray(capture_times);arrays['capture_fresh']=np.asarray(capture_fresh,dtype=bool)
            with recording.open('wb') as f:np.savez_compressed(f,**arrays)
            import hashlib
            result['rollout_recording_sha256']=hashlib.file_digest(recording.open('rb'),'sha256').hexdigest()
            result['recorded_accepted_actions']=len(capture_times)
        if env is not None:
            env.pause()
            result.setdefault('final_position',cargo.get_world_pose()[0].tolist() if 'cargo' in locals() else None)
        if client is not None:client.close()
        (out/'result.json').write_text(json.dumps(result,indent=2))
        if result.get('task_success') and result.get('verified'):
            import shutil
            archive=Path('/workspace/grounded-forge-status/successful-learned-snapshots')/(out.parent.name+'-'+out.name)
            archive.parent.mkdir(parents=True,exist_ok=True)
            shutil.copytree(out/'snapshots',archive)
            shutil.copy2(out/'result.json',archive/'verified-result.json')
            print('VERIFIED_SUCCESS_SNAPSHOTS',str(archive),flush=True)
        print('LEARNED_TASK_RESULT',json.dumps(result),flush=True)
        app.close()


if __name__=='__main__':main()
