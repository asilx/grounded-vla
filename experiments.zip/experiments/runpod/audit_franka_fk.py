"""Controlled same-q FK audit, fresh vendor scene versus exported evaluation scene."""
import argparse,json
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['fresh','loaded'],required=True);args=parser.parse_args()
import isaacsim
from isaacsim.simulation_app import SimulationApp
app=SimulationApp({'headless':True,'width':640,'height':480})
out=Path('/workspace/grounded-forge-status')/('franka-fk-'+args.mode+'-audit.json')
result=dict(scope='Controlled kinematics/scene diagnostic only; no policy, training or task success',mode=args.mode)
try:
 import numpy as np
 import omni.kit.app
 manager=omni.kit.app.get_app().get_extension_manager()
 for name in ['isaacsim.core.api','isaacsim.robot.manipulators.examples']:manager.set_extension_enabled_immediate(name,True)
 from isaacsim.core.api import World
 from isaacsim.core.prims import SingleRigidPrim
 from isaacsim.core.utils.types import ArticulationAction
 from grounded_vla.backends.isaacsim import IsaacSimConfig,IsaacSimEnvironment
 from isaacsim.robot.manipulators.examples.franka import Franka
 root=Path('/workspace/grounded-vla');status=Path('/workspace/grounded-forge-status');meta=json.loads((root/'data/franka-recovery-v16/prepared.json').read_text());entry=next(e for e in meta['episodes'] if e['id']=='franka-seed-000')
 with np.load(root/'data/franka-recovery-v16'/entry['path'],allow_pickle=False) as z:q=z['state'][0].astype(np.float64).copy();recorded_pose=z['graph_features'][0,2,:3].copy()
 config=IsaacSimConfig.load(root/'configs/runpod-franka-guarded.json')
 if args.mode=='fresh':
  world=World(stage_units_in_meters=1.,physics_dt=1/60,rendering_dt=1/60)
  robot=world.scene.add(Franka(prim_path='/World/Robot',name='franka'));world.reset();indices=np.arange(9)
  assert list(robot.dof_names)==list(config.joint_names)
  robot.disable_gravity();controller=robot.get_articulation_controller();controller.set_gains(kps=np.asarray(config.drive_kp),kds=np.asarray(config.drive_kd))
 else:
  env=IsaacSimEnvironment.from_config(config);world=env.world;robot=env.robot;indices=env.indices
 robot.set_joint_positions(q,joint_indices=indices);robot.set_joint_velocities(np.zeros(9),joint_indices=indices)
 robot.apply_action(ArticulationAction(joint_positions=q,joint_indices=indices))
 # No contacts at this elevated initial pose. Let the same commanded q settle in both scenes.
 for _ in range(60):world.step(render=True);world.render()
 observed=np.asarray(robot.get_joint_positions(),np.float64)[indices];poses={}
 for link in ['panda_rightfinger','panda_leftfinger','panda_hand','panda_link7','panda_link0']:
  prim=SingleRigidPrim('/World/Robot/'+link,name='audit_'+link);prim.initialize();p,o=prim.get_world_pose();poses[link]=dict(position=np.asarray(p).tolist(),orientation=np.asarray(o).tolist())
 result.update(verified=True,commanded_q=q.tolist(),observed_q=observed.tolist(),q_max_error=float(np.max(np.abs(observed-q))),ordered_joint_names=list(config.joint_names),native_joint_names=list(robot.dof_names),world_time=float(world.current_time),poses=poses,recorded_teacher_gripper_position=recorded_pose.tolist(),recorded_teacher_pose_difference_m=float(np.linalg.norm(np.array(poses['panda_rightfinger']['position'])-recorded_pose)),stage_path=str(config.stage_path),robot_class=type(robot).__name__)
 if args.mode=='fresh':
  result['teacher_end_effector_prim_path']=robot.end_effector.prim_path
  result['teacher_api_end_effector_position']=np.asarray(robot.end_effector.get_world_pose()[0]).tolist()
  result['teacher_vs_rigid_prim_pose_difference_m']=float(np.linalg.norm(np.array(result['teacher_api_end_effector_position'])-np.array(poses['panda_rightfinger']['position'])))
 print(json.dumps(result,indent=2),flush=True)
except BaseException as e:
 result.update(verified=False,error_type=type(e).__name__,error=str(e));raise
finally:
 out.write_text(json.dumps(result,indent=2));app.close()
