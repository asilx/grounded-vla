#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
for i in $(seq 1 900); do
  if [ -f "$status/guarded-v7-expert.exit" ]; then break; fi
  sleep 2
done
[ "$(cat "$status/guarded-v7-expert.exit")" = 0 ]
/workspace/pi0-train-env/bin/python - <<'PY'
from pathlib import Path
import re
s=Path('/workspace/grounded-forge-status/guarded-v5-runtime-tests.log').read_text()
assert re.search(r'\d+ passed',s) and not re.search(r'\d+ failed|\d+ errors?',s)
print('GUARDED_RUNTIME_TESTS_PASSED',flush=True)
PY
/workspace/pi0-train-env/bin/python -u experiments/runpod/prepare_guarded_training.py
export JAX_PLATFORMS=cpu OPENPI_SOURCE=/workspace/support/openpi-source
export TOKENIZERS_PARALLELISM=false PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
timeout 3600 /workspace/pi0-train-env/bin/grounded-vla-train configs/runpod-pi0-guarded.json --stop-after 200
