"""Scripted Franka physics pilot; does not measure pretrained VLA performance."""
import argparse
import json
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=0)
args = parser.parse_args()
import importlib.metadata
ISAAC_VERSION=importlib.metadata.version("isaacsim")
import isaacsim
from isaacsim.simulation_app import SimulationApp
app = SimulationApp({'headless':True, 'width':640, 'height':480})
try:
    import omni.kit.app
    manager = omni.kit.app.get_app().get_extension_manager()
    manager.set_extension_enabled_immediate('isaacsim.core.api', True)
    manager.set_extension_enabled_immediate('isaacsim.sensors.experimental.rtx', True)
    manager.set_extension_enabled_immediate('isaacsim.robot.manipulators.examples', True)
    import numpy as np
    import omni.usd
    from pxr import UsdLux, UsdGeom, Gf
    from PIL import Image
    from isaacsim.core.api import World
    from isaacsim.core.api.objects import DynamicCuboid, FixedCuboid
    from isaacsim.robot.manipulators.examples.franka import Franka
    from isaacsim.robot.manipulators.examples.franka.controllers import PickPlaceController
    from isaacsim.sensors.experimental.rtx import RtxCamera, CameraSensor
    rng = np.random.default_rng(args.seed)
    destination = np.array([0.3,-0.3,0.02575])
    destination[:2] += rng.uniform(-0.015,0.015,size=2)
    directory = Path('/workspace/grounded-forge-status/franka-pilot')/f'seed-{args.seed:03d}'
    directory.mkdir(parents=True,exist_ok=True)
    world = World(stage_units_in_meters=1.,physics_dt=1/60,rendering_dt=1/60)
    world.scene.add(FixedCuboid(prim_path='/World/Ground',name='ground',position=np.array([0.,0.,-.05]),scale=np.array([4.,4.,.1]),color=np.array([.25,.25,.25])))
    arm = world.scene.add(Franka(prim_path='/World/Robot',name='franka'))
    cargo = world.scene.add(DynamicCuboid(prim_path='/World/Cargo',name='cargo',position=np.array([0.3,0.3,0.15]),scale=np.full(3,0.0515),color=np.array([0.9,0.1,0.1])))
    dome = UsdLux.DomeLight.Define(omni.usd.get_context().get_stage(),'/World/Light')
    dome.CreateIntensityAttr(1500.)
    camera = RtxCamera('/World/Camera',tick_rate=30.0)
    transform=UsdGeom.Xformable(omni.usd.get_context().get_stage().GetPrimAtPath('/World/Camera'))
    transform.ClearXformOpOrder()
    transform.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(1.3,1.3,1.1),Gf.Vec3d(.3,0.,.2),Gf.Vec3d(0.,0.,1.)).GetInverse())
    sensor=CameraSensor(camera,resolution=(480,640),annotators=['rgb'])
    world.reset()
    for _ in range(60): world.step(render=True)
    controller = PickPlaceController(name='scripted_pickplace',gripper=arm.gripper,robot_articulation=arm,events_dt=[.004,.004,.01,.01,.005,.005,.004,.01,.004,.01])
    initial,_ = cargo.get_world_pose()
    highest = float(initial[2])
    done_at = None
    with (directory/'trace.jsonl').open('w') as trace:
        for step in range(2400):
            position,orientation = cargo.get_world_pose()
            highest = max(highest,float(position[2]))
            if not controller.is_done():
                command = controller.forward(picking_position=position,placing_position=destination,current_joint_positions=arm.get_joint_positions())
                arm.apply_action(command)
            elif done_at is None:
                done_at = step
            world.step(render=True)
            if step % 6 == 0:
                trace.write(json.dumps({'step':step,'sim_time':step/60,'position':position.tolist(),'orientation':orientation.tolist(),'joint_positions':arm.get_joint_positions().tolist(),'end_effector_position':arm.end_effector.get_world_pose()[0].tolist(),'controller_event':controller.get_current_event()})+'\n')
            if step % 60 == 0:
                rgba, info = sensor.get_data("rgb")
                if rgba is not None: rgba=rgba.numpy() if hasattr(rgba,"numpy") else np.asarray(rgba)
                if rgba is not None and rgba.size:
                    Image.fromarray(rgba.astype(np.uint8)).save(directory/f'frame-{step:04d}.png')
            if done_at is not None and step-done_at >= 120: break
    final,_ = cargo.get_world_pose()
    planar_error = float(np.linalg.norm(final[:2]-destination[:2]))
    success = bool(done_at is not None and highest > initial[2]+0.07 and planar_error < 0.04 and abs(final[2]-destination[2]) < 0.03)
    result = {'scope':'scripted Franka pick/place physics pilot','isaac_version':ISAAC_VERSION,'robot_api':'legacy Franka compatibility extension','events_dt':[.004,.004,.01,.01,.005,.005,.004,.01,.004,.01],'seed':args.seed,'controller_completed':done_at is not None,'success':success,'initial_position':initial.tolist(),'destination':destination.tolist(),'final_position':final.tolist(),'planar_error_m':planar_error,'peak_height_m':highest,'steps':step+1}
    (directory/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not success: raise RuntimeError('Franka pilot did not meet independent physical success criteria.')
finally:
    app.close()
