#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
python3 - <<'PY'
import socket,time
for i in range(240):
 try:
  with socket.create_connection(('127.0.0.1',8000),timeout=1): break
 except OSError: time.sleep(1)
else: raise TimeoutError('Model server did not listen within 240 seconds')
print('MODEL_PORT_READY',flush=True)
PY
OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1 timeout 240 /workspace/isaac6-env/bin/python -u experiments/runpod/probe_pi0_native.py --out /workspace/grounded-forge-status/pi0-native-probe-002
