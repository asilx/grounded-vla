"""Collect existing run evidence and user-project changes without model/image data."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path('/workspace/grounded-vla')
status = Path('/workspace/grounded-forge-status')
def read_json(p):
    return json.loads(p.read_text())

metrics = [json.loads(x) for x in (root/'runs/franka-pi0-smoke/metrics.jsonl').read_text().splitlines()]
assert metrics[-1]['step'] == 100
assert (status/'pi0-train-100.exit').read_text().strip() == '0'
files = [
 'src/grounded_vla/training/runtime.py', 'src/grounded_vla/training/pi0.py',
 'src/grounded_vla/backends/isaacsim.py', 'scripts/convert_pi0_checkpoint.py',
 'tests/test_pi0_integration.py', 'tests/test_isaacsim.py',
 'experiments/runpod/franka_expert_raw.py', 'experiments/runpod/check_native_bridge.py',
 'experiments/runpod/prepare_franka_training.py', 'experiments/runpod/probe_pi0_native.py',
 'experiments/runpod/run_pi0_native_probe.sh', 'experiments/runpod/run_pi0_smoke.sh',
 'experiments/runpod/setup_pi0_training.sh', 'experiments/runpod/download_convert_pi0.sh',
 'configs/runpod-pi0-smoke.json', 'configs/runpod-franka-native.json', 'configs/runpod-franka-pi0.json',
 'data/franka-native-v1/canonical-manifest.json', 'data/franka-native-v1/canonical-prepared.json',
 'data/franka-native-v1/audit.json', 'runs/franka-pi0-smoke/metrics.jsonl',
 'runs/franka-pi0-smoke/step-00000100/metadata.json',
]
sources = {p:(root/p).read_text() for p in files}
bundle = {
 'evidence_type': 'Grounded Forge actual Runpod experiment evidence',
 'collected_at': datetime.now(timezone.utc).isoformat(), 'gpu_pod': 'mvo49jfg7zf9c0',
 'retained_backup_pod': 'wrhtb2hhhtouqa', 'metrics': metrics,
 'tests': (status/'pi0-full-final-tests.log').read_text(),
 'conversion': read_json(Path('/workspace/models/pi0-base-torch/conversion.json')),
 'native_bridge': read_json(status/'native-bridge-check/result.json'),
 'probes': {p.name:read_json(p/'result.json') for p in sorted(status.glob('pi0-native-probe-*')) if p.is_dir() and (p/'result.json').exists()},
 'raw_episodes': {f'seed-{i:03d}':{name:read_json(status/f'franka-expert-raw/seed-{i:03d}'/f'{name}.json') for name in ['result','verification','expert-metadata']} for i in range(3)},
 'files': sources,
 'file_sha256': {p:hashlib.sha256(v.encode()).hexdigest() for p,v in sources.items()},
 'large_assets_not_bundled': ['raw and prepared episode NPZs', 'base model weights', 'adapter and optimizer binary checkpoints'],
 'checkpoint': '/workspace/grounded-vla/runs/franka-pi0-smoke/step-00000100',
 'dataset': '/workspace/grounded-vla/data/franka-native-v1/canonical-prepared.json',
}
(status/'RESUME_RESULTS.txt').write_text(json.dumps(bundle,indent=2))
print('EVIDENCE_COLLECTED',len(metrics),len(sources))
