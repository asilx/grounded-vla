"""Causal GRU numeric control baseline, no teacher/clock/waypoints at inference."""
import argparse,copy,hashlib,json
from collections import deque
from pathlib import Path
import numpy as np
import torch
from torch import nn
from safetensors.torch import load_file,save_file
from grounded_vla.training.data import load_prepared,encode_action_chunk,decode_action_chunk
from learned_graph_baseline import numeric_inputs,causal_state_features,physical_targets
from gripper_direction_v17 import direction_labels

class Actor(nn.Module):
 def __init__(self,input_dim,action_dim=9,width=128):
  super().__init__();self.project=nn.Sequential(nn.Linear(input_dim,width),nn.SiLU());self.gru=nn.GRU(width,width,batch_first=True);self.action=nn.Linear(width,action_dim);self.direction=nn.Linear(width,3)
 def forward(self,x,hidden=None):
  latent,hidden=self.gru(self.project(x),hidden)
  return self.action(latent),self.direction(latent),hidden

def masked_mean(values,mask):
 return (values*mask).sum()/mask.sum().clamp_min(1)

def episodes(prepared,meta,split):
 data=[]
 for e in meta['episodes']:
  if e['split']!=split:continue
  with np.load(prepared.parent/e['path'],allow_pickle=False) as z:
   q=z['state'].copy();a=z['actions'].copy();context=causal_state_features(q,4,meta['control_period_seconds'])
   x=numeric_inputs(context,z['graph_features'],z['graph_edges'],z['graph_valid'],len(meta['graph_schema']['relations']))
  encoded=np.stack([encode_action_chunk(a[i:i+1],q[i],meta)[0] for i in range(len(q))]);stats=meta['normalization']['action']
  y=(encoded-np.array(stats['mean'],np.float32))/np.array(stats['std'],np.float32)
  data.append(dict(id=e['id'],x=x.astype(np.float32),y=y.astype(np.float32),q=q.astype(np.float32),a=a.astype(np.float32),direction=direction_labels(q,a)))
 if not data:raise ValueError('Empty split')
 return data

def train(prepared,out,updates=1200):
 torch.set_num_threads(4);torch.manual_seed(43);np.random.seed(43)
 prepared=Path(prepared).resolve();out=Path(out).resolve();assert not out.exists();meta=load_prepared(prepared)
 assert meta['action_encoding']=='bounded_joint_interval_logits' and meta['action_encoding_horizon']==1
 train_data=episodes(prepared,meta,'train');val_data=episodes(prepared,meta,'val')
 allx=np.concatenate([e['x'] for e in train_data]);mean=allx.mean(0);std=np.maximum(allx.std(0),.1)
 counts=np.bincount(np.concatenate([e['direction'] for e in train_data]),minlength=3);assert np.all(counts>0)
 weights=counts.sum()/(3*counts);device=torch.device('cuda');model=Actor(len(mean)).to(device)
 optimizer=torch.optim.AdamW(model.parameters(),lr=5e-4,weight_decay=1e-5)
 scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=updates,eta_min=5e-5)
 classweight=torch.tensor(weights,dtype=torch.float32,device=device);scale=torch.tensor(meta['encoding_max_joint_step'],device=device)
 length=max(len(e['x']) for e in train_data);batch=len(train_data)
 arrays={k:torch.zeros((batch,length,w),device=device) for k,w in [('x',len(mean)),('y',9),('q',9),('a',9)]}
 directions=torch.zeros((batch,length),dtype=torch.long,device=device);mask=torch.zeros((batch,length),device=device)
 for i,e in enumerate(train_data):
  n=len(e['x']);mask[i,:n]=1;directions[i,:n]=torch.tensor(e['direction'],device=device)
  for k in arrays:arrays[k][i,:n]=torch.tensor((e[k]-mean)/std if k=='x' else e[k],device=device)
 out.mkdir(parents=True);history=[];best=float('inf');best_state=None;best_step=0;step=0;epoch=0
 while step<updates:
  epoch+=1;hidden=None;model.train()
  # Chronological chunks, hidden carried then detached; no future/teacher labels fed as input.
  for start in range(0,length,256):
   if step>=updates:break
   end=min(start+256,length);m=mask[:,start:end];target=directions[:,start:end]
   prediction,classification,hidden=model(arrays['x'][:,start:end],hidden)
   hidden=hidden.detach();decoded=physical_targets(prediction,arrays['q'][:,start:end],meta)
   logit_error=((prediction-arrays['y'][:,start:end])**2).mean(-1)
   physical_error=(((decoded-arrays['a'][:,start:end])/scale)**2).mean(-1)
   direction_error=nn.functional.cross_entropy(classification.reshape(-1,3),target.reshape(-1),weight=classweight,reduction='none').reshape_as(m)
   frameweight=classweight[target]
   loss=masked_mean((logit_error+20*physical_error)*frameweight+2*direction_error,m)
   if not torch.isfinite(loss):raise FloatingPointError('Non-finite recurrent loss')
   optimizer.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);optimizer.step();scheduler.step();step+=1
   if step%100==0 or step==updates:
    model.eval();errors=[];arm=[];correct=np.zeros(3);total=np.zeros(3)
    with torch.no_grad():
     for e in val_data:
      x=torch.tensor((e['x']-mean)/std,device=device)[None];q=torch.tensor(e['q'],device=device)[None];a=torch.tensor(e['a'],device=device)[None]
      p,c,_=model(x);decoded=physical_targets(p,q,meta);physical=(((decoded-a)/scale)**2).mean(-1)
      labels=direction_labels(e['q'],e['a']);predicted=direction_labels(e['q'],decoded[0].cpu().numpy())
      errors.append(physical.mean().item());arm.append(torch.linalg.vector_norm(decoded[:,:,:7]-a[:,:,:7],dim=-1).mean().item())
      for k in range(3):total[k]+=int((labels==k).sum());correct[k]+=int(((labels==k)&(predicted==k)).sum())
    accuracy=np.divide(correct,total,out=np.zeros(3),where=total>0);balanced=float(accuracy[total>0].mean())
    score=float(np.mean(errors))+.1*(1-balanced)
    record=dict(update=step,epoch=epoch,train_loss=float(loss),val_physical_mse=float(np.mean(errors)),val_arm_error_rad=float(np.mean(arm)),val_gripper_direction_accuracy=accuracy.tolist(),val_balanced_gripper_direction_accuracy=balanced,selection_score=score)
    history.append(record);print(json.dumps(record),flush=True)
    if score<best:best=score;best_step=step;best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    model.train()
 if best_state is None:raise RuntimeError('No finite validation checkpoint')
 save_file(best_state,str(out/'actor.safetensors'))
 artifact=dict(dataset=meta,input_dim=len(mean),width=128,history_steps=4,input_mean=mean.tolist(),input_std=std.tolist(),selected_step=best_step,training_updates=updates,architecture='causal GRU128 + auxiliary training-only direction head',scope='Learned numeric proprioception/geometric-KG recurrent control; no RGB/language/VLA, no teacher/waypoints/phase clock at inference',selection='val normalized physical command MSE +0.1*(1-balanced gripper direction accuracy); test split untouched',direction_train_counts=counts.tolist(),dataset_sha256=hashlib.file_digest(prepared.open('rb'),'sha256').hexdigest(),weights_sha256=hashlib.file_digest((out/'actor.safetensors').open('rb'),'sha256').hexdigest(),train_episodes=[e['id'] for e in train_data],val_episodes=[e['id'] for e in val_data])
 (out/'metadata.json').write_text(json.dumps(artifact,indent=2));(out/'metrics.json').write_text(json.dumps(history,indent=2));print('V17B_RECURRENT_MODEL_SAVED',best_step,best,flush=True)

class Policy:
 def __init__(self,checkpoint):
  torch.set_num_threads(2);cp=Path(checkpoint);self.artifact=json.loads((cp/'metadata.json').read_text());self.meta=self.artifact['dataset']
  assert hashlib.file_digest((cp/'actor.safetensors').open('rb'),'sha256').hexdigest()==self.artifact['weights_sha256']
  self.actor=Actor(self.artifact['input_dim'],9,self.artifact['width']);self.actor.load_state_dict(load_file(str(cp/'actor.safetensors')),strict=True);self.actor.eval();self.reset()
  self.metadata=dict(policy='learned-proprio-geometric-graph-gru-baseline',uses_rgb=False,uses_language=False,scope=self.artifact['scope'],weights_sha256=self.artifact['weights_sha256'],checkpoint_step=self.artifact['selected_step'],history_steps=4,recurrent=True,input_preset='canonical',graph_required=True,state_dim=9,action_dim=9,action_horizon=1,action_encoding=self.meta['action_encoding'],action_convention=self.meta['action_convention'],control_period_seconds=self.meta['control_period_seconds'],graph_schema_id=self.meta['graph_schema']['id'],graph_feature_dim=len(self.meta['graph_schema']['features']),graph_relation_types=len(self.meta['graph_schema']['relations']))
 def reset(self):self.hidden=None;self.states=deque(maxlen=4)
 @torch.no_grad()
 def infer(self,payload):
  q=np.asarray(payload['state'],np.float32);g=payload['graph'];assert q.shape==(9,) and g['schema_id']==self.metadata['graph_schema_id'];self.states.append(q.copy())
  context=causal_state_features(np.stack(self.states),4,self.meta['control_period_seconds'])[-1:]
  x=numeric_inputs(context,np.asarray(g['features'])[None],np.asarray(g['edges'])[None],np.asarray(g['valid'])[None],self.metadata['graph_relation_types'])
  x=(x-np.array(self.artifact['input_mean'],np.float32))/np.array(self.artifact['input_std'],np.float32)
  p,_,self.hidden=self.actor(torch.from_numpy(x)[None],self.hidden);stats=self.meta['normalization']['action'];logits=p[0].numpy()*np.array(stats['std'],np.float32)+np.array(stats['mean'],np.float32)
  actions=decode_action_chunk(logits,q,self.meta);assert np.isfinite(actions).all();return dict(actions=actions)

def main():
 parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='command',required=True);t=sub.add_parser('train');t.add_argument('prepared');t.add_argument('out');t.add_argument('--updates',type=int,default=1200);s=sub.add_parser('serve');s.add_argument('checkpoint');s.add_argument('--port',type=int,default=8010);args=parser.parse_args()
 if args.command=='train':train(args.prepared,args.out,args.updates)
 else:
  from openpi.serving.websocket_policy_server import WebsocketPolicyServer
  class EpisodeServer(WebsocketPolicyServer):
   active=False
   async def _handler(self,websocket):
    if self.active:await websocket.close(code=1013,reason='One recurrent episode connection at a time');return
    self.active=True;self._policy.reset()
    try:await super()._handler(websocket)
    finally:self.active=False
  p=Policy(args.checkpoint);EpisodeServer(p,host='127.0.0.1',port=args.port,metadata=p.metadata).serve_forever()
if __name__=='__main__':main()
