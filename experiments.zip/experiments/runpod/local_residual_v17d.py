"""Learned Gaussian-feature residual, fitted only on training observations.
No runtime demonstration actions, nearest-trajectory index, phase clock, or teacher.
"""
import json,hashlib,copy,argparse
from pathlib import Path
import numpy as np
import torch
from safetensors.torch import load_file,save_file
from learned_directional_v17 import Actor,BaselinePolicy,read_numeric,physical_targets,causal_state_features,numeric_inputs
from grounded_vla.training.data import decode_action_chunk

def basis(x,centers,width):
 dist=(x.square().sum(1)[:,None]+centers.square().sum(1)[None]-2*x@centers.T).clamp_min(0)
 return torch.exp(-dist/(2*width*width))

def train():
 torch.set_num_threads(4);root=Path('/workspace/grounded-vla');cp=root/'runs/learned-graph-baseline-v17';out=root/'runs/learned-graph-baseline-v17d';assert not out.exists()
 md=json.loads((cp/'metadata.json').read_text());meta=md['dataset'];p=root/'data/franka-recovery-v16/prepared.json'
 actor=Actor(md['input_dim'],meta['action_dim'],md['width']);original=load_file(str(cp/'actor.safetensors'));actor.load_state_dict(original);actor.eval()
 assert hashlib.file_digest((cp/'actor.safetensors').open('rb'),'sha256').hexdigest()==md['weights_sha256']
 data={s:read_numeric(p,meta,s,md['history_steps']) for s in ['train','val']}
 mean=np.asarray(md['input_mean'],np.float32);std=np.asarray(md['input_std'],np.float32)
 xs={s:torch.from_numpy((d[0]-mean)/std) for s,d in data.items()}
 with torch.no_grad():base={s:actor(x) for s,x in xs.items()}
 indices=[];offset=0
 for e in meta['episodes']:
  if e['split']!='train':continue
  with np.load(p.parent/e['path'],allow_pickle=False) as z:n=len(z['state'])
  indices.extend((offset+np.unique(np.r_[np.arange(min(64,n)),np.linspace(0,n-1,128,dtype=int)])).tolist());offset+=n
 indices=np.unique(indices);centers=xs['train'][indices].double();x=xs['train'].double()
 target=torch.from_numpy(data['train'][1][:,:7]).double()-base['train'][:,:7].double()
 weights=torch.ones(len(x),dtype=torch.float64);offset=0
 for e in meta['episodes']:
  if e['split']!='train':continue
  with np.load(p.parent/e['path'],allow_pickle=False) as z:n=len(z['state'])
  weights[offset:offset+min(n,64)]=10;offset+=n
 def score(s,pred):
  q=torch.from_numpy(data[s][2]);a=torch.from_numpy(data[s][3]);err=torch.linalg.vector_norm((physical_targets(pred.float(),q,meta)-a)[:,:7],dim=1)
  return dict(mean_arm_error_rad=err.mean().item(),first_arm_error_rad=err[0].item(),first32_arm_error_rad=err[:32].mean().item())
 before={s:score(s,base[s]) for s in data};records=[];best=None
 print('BEFORE',before,'CENTERS',len(centers),flush=True)
 for width in [.15,.3,.6]:
  h=basis(x,centers,width);gram=h.T@(weights[:,None]*h);rhs=h.T@(weights[:,None]*target)
  hv=basis(xs['val'].double(),centers,width)
  for ridge in [.0001,.01]:
   coeff=torch.linalg.solve(gram+ridge*torch.eye(len(centers),dtype=torch.float64),rhs)
   scores={}
   for s,hlocal in [('train',h),('val',hv)]:
    pred=base[s].clone();pred[:,:7]+=(hlocal@coeff).float();scores[s]=score(s,pred)
   gate=scores['train']['first_arm_error_rad']<before['train']['first_arm_error_rad']/5 and scores['val']['first32_arm_error_rad']<before['val']['first32_arm_error_rad']*.5 and scores['val']['mean_arm_error_rad']<=before['val']['mean_arm_error_rad']*1.05
   record=dict(width=width,ridge=ridge,scores=scores,eligible=gate);records.append(record);print(json.dumps(record),flush=True)
   if gate and (best is None or scores['val']['mean_arm_error_rad']<best[0]):best=(scores['val']['mean_arm_error_rad'],coeff.clone(),record)
 report={'scope':'Learned local Gaussian-feature correction to numeric MLP arm commands; same guards; no task success claim','before':before,'candidates':records,'centers':len(centers),'selected':None if best is None else best[2]}
 Path('/workspace/grounded-forge-status/v17d-local-residual-fit.json').write_text(json.dumps(report,indent=2))
 if best is None:print('LOCAL_RESIDUAL_GATE_FAILED',flush=True);return
 out.mkdir();save_file(original,str(out/'actor.safetensors'));save_file({'centers':centers.float().contiguous(),'coefficients':best[1].float().contiguous()},str(out/'residual.safetensors'))
 md['scope']=report['scope'];md['residual']=best[2];md['residual_sha256']=hashlib.file_digest((out/'residual.safetensors').open('rb'),'sha256').hexdigest();md['selection']='train startup improvement and heldout validation gate; test untouched';(out/'metadata.json').write_text(json.dumps(md,indent=2));(out/'metrics.json').write_text(json.dumps(report,indent=2));print('LOCAL_RESIDUAL_SAVED',out,flush=True)

class Policy(BaselinePolicy):
 def __init__(self,checkpoint):
  super().__init__(checkpoint);cp=Path(checkpoint)
  assert hashlib.file_digest((cp/'residual.safetensors').open('rb'),'sha256').hexdigest()==self.artifact['residual_sha256']
  r=load_file(str(cp/'residual.safetensors'));self.centers=r['centers'];self.coeff=r['coefficients'];self.width=self.artifact['residual']['width'];self.metadata['residual_sha256']=self.artifact['residual_sha256'];self.metadata['policy']='learned-mlp-local-gaussian-residual'
 @torch.no_grad()
 def infer(self,payload):
  # Preserve all input validation and history behavior of the existing policy.
  super().infer(payload)
  state=np.asarray(payload['state'],np.float32);graph=payload['graph'];f,e,v=np.asarray(graph['features']),np.asarray(graph['edges']),np.asarray(graph['valid'])
  context=causal_state_features(np.stack(self.states),self.history,self.meta['control_period_seconds'])[-1:]
  x=numeric_inputs(context,f[None],e[None],v[None],self.metadata['graph_relation_types']);x=(x-np.asarray(self.artifact['input_mean'],np.float32))/np.asarray(self.artifact['input_std'],np.float32);xt=torch.from_numpy(x)
  pred=self.actor(xt);pred[:,:7]+=basis(xt,self.centers,self.width)@self.coeff
  stats=self.meta['normalization']['action'];logits=pred.numpy()*np.asarray(stats['std'],np.float32)+np.asarray(stats['mean'],np.float32);actions=decode_action_chunk(logits,state,self.meta)
  if not np.isfinite(actions).all():raise FloatingPointError('Non-finite residual command')
  return {'actions':actions}

def main():
 p=argparse.ArgumentParser();p.add_argument('command',choices=['train','serve']);p.add_argument('--checkpoint',default='/workspace/grounded-vla/runs/learned-graph-baseline-v17d');p.add_argument('--port',type=int,default=8011);a=p.parse_args()
 if a.command=='train':train();return
 from openpi.serving.websocket_policy_server import WebsocketPolicyServer
 class Server(WebsocketPolicyServer):
  active=False
  async def _handler(self,websocket):
   if self.active:await websocket.close(code=1013,reason='One episode at a time');return
   self.active=True;self._policy.reset()
   try:await super()._handler(websocket)
   finally:self.active=False
 policy=Policy(a.checkpoint)
 Server(policy,host='127.0.0.1',port=a.port,metadata=policy.metadata).serve_forever()
if __name__=='__main__':main()
