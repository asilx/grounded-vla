"""Independent physical tests of the explicitly labelled learned numeric baseline."""
from pathlib import Path
import datetime
import json
import os
import shutil
import subprocess
import time

root=Path('/workspace/grounded-vla');status=Path('/workspace/grounded-forge-status');os.chdir(root)
env=dict(os.environ,OPENPI_SOURCE='/workspace/support/openpi-source',JAX_PLATFORMS='cpu',
         TOKENIZERS_PARALLELISM='false',OMNI_KIT_ACCEPT_EULA='YES',OMNI_KIT_ALLOW_ROOT='1')
cp=root/'runs/learned-graph-baseline-v17e'
audit={'scope':'Learned proprioception + geometric-KG MLP baseline; not pi0/VLA success',
       'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempts':[]}


def save():
    (status/'learned-baseline-v17e-audit.json').write_text(json.dumps(audit,indent=2))


def evaluate(seed):
    for attempt in range(2):
        out=status/'learned-graph-baseline-v17e-task'/f'seed-{seed}-attempt-{attempt}'
        if out.exists():raise FileExistsError(out)
        with (status/f'learned-baseline-v17e-seed-{seed}-attempt-{attempt}.log').open('w') as log:
            try:
                code=subprocess.run(['/workspace/isaac6-env/bin/python','-u','experiments/runpod/evaluate_learned_recovery_v16_task.py',
                     '--seed',str(seed),'--execute-steps','1','--uri','ws://127.0.0.1:8012','--out',str(out)],
                     env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3000).returncode
            except subprocess.TimeoutExpired:code=124
        p=out/'result.json';result=json.loads(p.read_text()) if p.exists() else {'verified':False,'task_success':False,'reason':'no_authoritative_result'}
        audit['attempts'].append(dict(seed=seed,attempt=attempt,process_exit=code,output=str(out),result=result));save()
        print('BASELINE_PHYSICAL_RESULT',seed,attempt,result.get('verified'),result.get('task_success'),result.get('reason'),flush=True)
        if result.get('verified') and result.get('task_success'):
            archive=status/'successful-learned-baseline-snapshots'/f'v17e-seed-{seed}-attempt-{attempt}'
            archive.mkdir(parents=True,exist_ok=True)
            shutil.copy2(cp/'metadata.json',archive/'model-provenance.json');shutil.copy2(p,archive/'verified-result.json')
            shutil.copytree(out/'snapshots',archive/'snapshots',dirs_exist_ok=True)
            return True
        if result.get('verified') or result.get('error_type')!='CameraNotReady':return False
    return False


server=None
try:
    save()
    while not (status/'learned-baseline-v17e-train.exit').exists():time.sleep(2)
    assert int((status/'learned-baseline-v17e-train.exit').read_text())==0
    prior=status/'learned-baseline-v17d-audit.json'
    while prior.exists() and json.loads(prior.read_text()).get('status') not in ('completed','error'):time.sleep(2)
    assert json.loads((status/'v17e-local-residual-checks.json').read_text())['verified']
    if not cp.exists():
        audit['status']='deferred_calibration_gate_failed';save();raise SystemExit(0)
    from grounded_vla.backends.openpi import OpenPiTransport
    log=(status/'learned-baseline-v17e-server.log').open('w')
    server=subprocess.Popen(['/workspace/pi0-train-env/bin/python','-u','experiments/runpod/local_residual_v17e.py','serve','--checkpoint',str(cp),'--port','8012'],env=env,stdout=log,stderr=subprocess.STDOUT)
    deadline=time.monotonic()+120
    while True:
        if server.poll() is not None:raise RuntimeError('Baseline server exited before readiness')
        try:
            with OpenPiTransport('ws://127.0.0.1:8012',timeout=2) as c:
                assert c.metadata['policy']=='learned-mlp-local-gaussian-residual'
                assert c.metadata['uses_rgb'] is False and c.metadata['uses_language'] is False
                assert c.metadata['history_steps']==4
                assert c.metadata['weights_sha256']==json.loads((cp/'metadata.json').read_text())['weights_sha256']
            break
        except Exception:
            if time.monotonic()>deadline:raise TimeoutError('Baseline server readiness')
            time.sleep(1)
    if evaluate(0):
        for seed in (1,2):evaluate(seed)
    audit['status']='completed'
except BaseException as exc:
    if not isinstance(exc,SystemExit):audit.update(status='error',error_type=type(exc).__name__,error=str(exc))
    raise
finally:
    if server is not None:
        server.terminate()
        try:server.wait(timeout=15)
        except subprocess.TimeoutExpired:server.kill();server.wait()
    audit['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
