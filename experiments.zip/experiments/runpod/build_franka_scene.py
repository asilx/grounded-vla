"""Scripted Franka physics pilot; does not measure pretrained VLA performance."""
import argparse
import json
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=0)
args = parser.parse_args()
import importlib.metadata
ISAAC_VERSION=importlib.metadata.version("isaacsim")
import isaacsim
from isaacsim.simulation_app import SimulationApp
app = SimulationApp({'headless':True, 'width':640, 'height':480})
try:
    import omni.kit.app
    manager = omni.kit.app.get_app().get_extension_manager()
    manager.set_extension_enabled_immediate('isaacsim.core.api', True)
    manager.set_extension_enabled_immediate('isaacsim.sensors.experimental.rtx', True)
    manager.set_extension_enabled_immediate('isaacsim.robot.manipulators.examples', True)
    import numpy as np
    import omni.usd
    from pxr import UsdLux, UsdGeom, Gf
    from PIL import Image
    from isaacsim.core.api import World
    from isaacsim.core.api.objects import DynamicCuboid, FixedCuboid
    from isaacsim.robot.manipulators.examples.franka import Franka
    from isaacsim.robot.manipulators.examples.franka.controllers import PickPlaceController
    from isaacsim.sensors.experimental.rtx import RtxCamera, CameraSensor
    rng = np.random.default_rng(args.seed)
    destination = np.array([0.3,-0.3,0.02575])
    destination[:2] += rng.uniform(-0.015,0.015,size=2)
    directory = Path('/workspace/grounded-forge-status/franka-pilot')/f'seed-{args.seed:03d}'
    directory.mkdir(parents=True,exist_ok=True)
    world = World(stage_units_in_meters=1.,physics_dt=1/60,rendering_dt=1/60)
    world.scene.add(FixedCuboid(prim_path='/World/Ground',name='ground',position=np.array([0.,0.,-.05]),scale=np.array([4.,4.,.1]),color=np.array([.25,.25,.25])))
    arm = world.scene.add(Franka(prim_path='/World/Robot',name='franka'))
    cargo = world.scene.add(DynamicCuboid(prim_path='/World/Cargo',name='cargo',position=np.array([0.3,0.3,0.15]),scale=np.full(3,0.0515),color=np.array([0.9,0.1,0.1])))
    dome = UsdLux.DomeLight.Define(omni.usd.get_context().get_stage(),'/World/Light')
    dome.CreateIntensityAttr(1500.)
    camera = RtxCamera('/World/Camera',tick_rate=30.0)
    transform=UsdGeom.Xformable(omni.usd.get_context().get_stage().GetPrimAtPath('/World/Camera'))
    transform.ClearXformOpOrder()
    transform.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(1.3,1.3,1.1),Gf.Vec3d(.3,0.,.2),Gf.Vec3d(0.,0.,1.)).GetInverse())
    sensor=CameraSensor(camera,resolution=(480,640),annotators=['rgb'])
    wrist=RtxCamera('/World/Robot/panda_hand/WristCamera',tick_rate=60.0)
    wt=UsdGeom.Xformable(omni.usd.get_context().get_stage().GetPrimAtPath('/World/Robot/panda_hand/WristCamera'))
    wt.ClearXformOpOrder()
    wt.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(.05,0.,-.03),Gf.Vec3d(.05,0.,.5),Gf.Vec3d(1.,0.,0.)).GetInverse())
    world.reset()
    for _ in range(60): world.step(render=True)
    scene_dir=Path('/workspace/grounded-vla/assets/runpod');scene_dir.mkdir(parents=True,exist_ok=True)
    stage_path=scene_dir/'franka-native.usda'
    omni.usd.get_context().get_stage().GetRootLayer().Export(str(stage_path))
    props=arm.dof_properties
    names=list(arm.dof_names)
    config={'stage_path':str(stage_path),'robot_prim_path':'/World/Robot','camera_paths':{'base_0_rgb':'/World/Camera','left_wrist_0_rgb':'/World/Robot/panda_hand/WristCamera'},'joint_names':names,'lower_limits':[float(x) for x in props['lower']],'upper_limits':[float(x) for x in props['upper']],'max_joint_step':[.05]*7+[.005,.005],'physics_dt':1/60,'steps_per_action':6,'warmup_steps':120,'max_camera_age_seconds':.05}
    config_path=Path('/workspace/grounded-vla/configs/runpod-franka-native.json')
    config_path.write_text(json.dumps(config,indent=2))
    print(json.dumps({'stage':str(stage_path),'config':str(config_path),'joint_names':names}),flush=True)
except BaseException:
    import traceback;traceback.print_exc();raise
finally:
    app.close()
