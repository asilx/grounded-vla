"""One real pretrained-policy proposal with unchanged articulation guards.

Simulator oracle poses supply graph geometry. No critic or success claim.
"""
import argparse
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--out', required=True)
    args = p.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    from isaacsim import SimulationApp
    app = SimulationApp({'headless': True})
    env = client = None
    result = {'scope': 'Single learned proposal and joint guard probe; no task-success evaluation.',
              'critic': None, 'graph_geometry': 'simulator oracle poses', 'seed': 2}
    try:
        import numpy as np
        from PIL import Image
        from isaacsim.core.prims import SingleRigidPrim
        from grounded_vla.backends.isaacsim import IsaacSimConfig, IsaacSimEnvironment
        from grounded_vla.backends.openpi import OpenPiTransport
        from grounded_vla.belief import BeliefStore
        from grounded_vla.simulation import CanonicalSimPolicy, GraphSnapshot
        from grounded_vla.training.graph import encode_belief_graph
        def red_cube_visible(*images):
            for rgb in images:
                x = rgb.astype(np.float32)
                red = (x[..., 0] > 60) & (x[..., 0] > 1.5*x[..., 1]) & (x[..., 0] > 1.5*x[..., 2])
                if int(red.sum()) >= 4:
                    return True
            return False
        config = IsaacSimConfig.load('configs/runpod-franka-pi0.json')
        env = IsaacSimEnvironment.from_config(config)
        cargo = SingleRigidPrim('/World/Cargo', name='probe_cargo')
        gripper = SingleRigidPrim('/World/Robot/panda_rightfinger', name='probe_gripper')
        cargo.initialize()
        gripper.initialize()
        while env.world.current_time < 1.0:
            env._step_world()
        obs = env.observe()
        cp, _ = cargo.get_world_pose()
        gp, _ = gripper.get_world_pose()
        goal = np.array([.3, -.3, .02575], np.float64)
        goal[:2] += np.random.default_rng(2).uniform(-.015, .015, size=2)
        objects = [dict(id='cargo', position=cp, visible=red_cube_visible(*obs.images.values()), is_target=True),
                   dict(id='goal', position=goal, visible=False, is_target=False),
                   dict(id='gripper', position=gp, visible=False, is_target=False)]
        relations = [('goal', 'target_of', 'cargo')]
        if np.linalg.norm(cp - gp) < .12:
            relations += [('cargo', 'near', 'gripper'), ('gripper', 'near', 'cargo')]
        graph = encode_belief_graph(BeliefStore(), objects, relations, now=obs.timestamp)
        for name, image in obs.images.items():
            Image.fromarray(image).save(out / (name + '.png'))
        client = OpenPiTransport('ws://127.0.0.1:8000', timeout=120.0)
        policy = CanonicalSimPolicy(client, config)
        actions = policy.infer(obs, GraphSnapshot(graph, obs.timestamp), 'Place the red cube at the graph goal.')
        assert env.world.current_time == obs.timestamp
        np.savez_compressed(out / 'proposal.npz', state=obs.state, actions=actions,
                            graph_features=graph['features'], graph_edges=graph['edges'],
                            graph_valid=graph['valid'], cube_position=cp, gripper_position=gp,
                            **{f'images/{k}': v for k, v in obs.images.items()})
        before = env._positions()
        result.update(policy_metadata=policy.meta, proposal_shape=list(actions.shape),
                      timestamp_before=obs.timestamp, first_action=actions[0].tolist(),
                      measured_state=before.tolist(), camera_times=env._last_camera_times,
                      maximum_joint_delta=float(np.max(np.abs(actions[0]-before))))
        try:
            after = env.step(actions[0])
            result.update(reason='one_action_executed', timestamp_after=after.timestamp,
                          state_after=after.state.tolist(), guard_rejected=False)
        except ValueError as exc:
            assert env.world.current_time == obs.timestamp
            assert np.array_equal(env._positions(), before)
            result.update(reason='guard_rejected', guard_rejected=True, rejection=str(exc),
                          timestamp_after=float(env.world.current_time), physics_unchanged=True)
        result['verified'] = True
    except BaseException as exc:
        result.update(verified=False, reason='error', error_type=type(exc).__name__, error=str(exc))
        raise
    finally:
        if env is not None:
            env.pause()
        if client is not None:
            client.close()
        (out / 'result.json').write_text(json.dumps(result, indent=2))
        app.close()


if __name__ == '__main__':
    main()
