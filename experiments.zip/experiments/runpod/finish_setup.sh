#!/usr/bin/env bash
set -euo pipefail
export UV_CACHE_DIR=/workspace/uv-cache
export OMNI_KIT_ACCEPT_EULA=YES
while [[ ! -f /workspace/grounded-forge-status/install.exit ]]; do sleep 5; done
[[ $(cat /workspace/grounded-forge-status/install.exit) == 0 ]]
uv pip install --python /workspace/isaac-env/bin/python --no-deps /workspace/support/openpi/packages/openpi-client
cd /workspace/grounded-vla
/workspace/isaac-env/bin/python -m pytest -q > /workspace/grounded-forge-status/integration-tests.log 2>&1
uv pip freeze --python /workspace/isaac-env/bin/python > /workspace/grounded-forge-status/installed-packages.txt
/workspace/isaac-env/bin/python - <<'PY'
import importlib.metadata as meta
import json
from pathlib import Path
p = Path('/workspace/grounded-forge-status/status.json')
s = json.loads(p.read_text())
s.update(isaac_installed=True, isaac_version=meta.version('isaacsim'), eula_approved=True, gpu_currently_assigned=False, physics_experiments_run=False, next_step='Regain an RTX GPU, run physics_rgb_smoke.py, then author and validate the Franka task scene.')
s['installed_versions'] = {k:meta.version(k) for k in ['isaacsim','torch','torchvision','numpy','openpi-client']}
s['integration_test_summary'] = Path('/workspace/grounded-forge-status/integration-tests.log').read_text()[-1800:]
p.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(s,indent=2))
PY
