"""Check causal streaming, unchanged finger commands, decoder bounds and parity."""
import json
from pathlib import Path
import numpy as np
import torch
from local_residual_v17e import Policy,basis
from learned_directional_v17 import BaselinePolicy,causal_state_features,numeric_inputs,physical_targets
cp=Path('/workspace/grounded-vla/runs/learned-graph-baseline-v17e')
if not cp.exists():raise SystemExit('No model passed the calibration gate')
p=Policy(cp);original=BaselinePolicy('/workspace/grounded-vla/runs/learned-graph-baseline-v17');meta=p.meta
prepared=Path('/workspace/grounded-vla/data/franka-recovery-v16/prepared.json');entry=next(e for e in meta['episodes'] if e['split']=='val')
with np.load(prepared.parent/entry['path'],allow_pickle=False) as z:
 q=z['state'][:64].copy();f=z['graph_features'][:64].copy();e=z['graph_edges'][:64].copy();v=z['graph_valid'][:64].copy()
x=numeric_inputs(causal_state_features(q,p.history,meta['control_period_seconds']),f,e,v,p.metadata['graph_relation_types']);x=(x-np.asarray(p.artifact['input_mean'],np.float32))/np.asarray(p.artifact['input_std'],np.float32)
with torch.no_grad():
 xt=torch.from_numpy(x);pred=p.actor(xt);pred[:,:7]+=(basis(xt,p.centers,p.width)@p.coeff).float();expected=physical_targets(pred,torch.from_numpy(q),meta).numpy()
actual=[]
for i in range(len(q)):
 payload={'state':q[i],'graph':{'schema_id':p.metadata['graph_schema_id'],'features':f[i],'edges':e[i],'valid':v[i]}}
 a=p.infer(payload)['actions'][0];b=original.infer(payload)['actions'][0];actual.append(a)
 np.testing.assert_allclose(a[7:],b[7:],rtol=0,atol=1e-7)
 assert np.all(a>=np.asarray(meta['encoding_lower_limits'])-1e-7) and np.all(a<=np.asarray(meta['encoding_upper_limits'])+1e-7)
 assert np.all(np.abs(a-q[i])<=np.asarray(meta['encoding_max_joint_step'])+1e-7)
actual=np.asarray(actual);np.testing.assert_allclose(actual,expected,rtol=0,atol=1e-6)
p.reset();first=p.infer({'state':q[0],'graph':{'schema_id':p.metadata['graph_schema_id'],'features':f[0],'edges':e[0],'valid':v[0]}})['actions'][0]
np.testing.assert_allclose(first,actual[0],rtol=0,atol=1e-7)
report={'verified':True,'samples':len(q),'stream_batch_max_error_rad':float(np.max(np.abs(actual-expected))),'checks':['finger commands unchanged','native joint and per-step bounds','batch/stream parity','episode reset'],'model_sha256':p.artifact['residual_sha256']}
Path('/workspace/grounded-forge-status/v17e-local-residual-checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
