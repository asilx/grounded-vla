#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1
status=/workspace/grounded-forge-status
for seed in 6 7 8; do
 timeout 900 /workspace/isaac6-env/bin/python -u experiments/runpod/franka_expert_recovery_v16.py --seed "$seed" > "$status/recovery-v16-seed-$seed.log" 2>&1
 /workspace/isaac6-env/bin/python - "$seed" <<'PY'
import sys,json,hashlib
from pathlib import Path
import numpy as np
from grounded_vla.backends.isaacsim import IsaacSimConfig
p=Path('/workspace/grounded-forge-status/franka-expert-recovery-v16')/f'seed-{int(sys.argv[1]):03d}'
m=json.loads((p/'expert-metadata.json').read_text());r=json.loads((p/'result.json').read_text())
assert m['physics_success'] and r['success'] and r['stable_release_steps']>=120
c=IsaacSimConfig.load('/workspace/grounded-vla/configs/runpod-franka-guarded.json')
with np.load(p/'expert-raw.npz',allow_pickle=False) as d:
 n=len(d['states']);assert d['states'].shape==d['actions'].shape==(n,9)
 assert np.all(d['actions']>=c.lower_limits) and np.all(d['actions']<=c.upper_limits)
 assert np.all(np.abs(d['actions']-d['states'])<=np.asarray(c.max_joint_step)+1e-7)
 assert np.allclose(np.diff(d['state_timestamps']),1/60,atol=1e-7)
 ages=d['state_timestamps'][:,None]-d['image_timestamps'];assert np.all(ages>=-1e-6) and np.all(ages<=.05)
 assert d['base_rgb'].shape==d['wrist_rgb'].shape==(n,224,224,3)
digest=hashlib.file_digest((p/'expert-raw.npz').open('rb'),'sha256').hexdigest()
(p/'verification.json').write_text(json.dumps(dict(verified=True,samples=n,sha256=digest,scope='scripted recovery data; not learned policy success'),indent=2))
print('RECOVERY_DEMONSTRATION_VERIFIED',sys.argv[1],n,digest,flush=True)
PY
done
