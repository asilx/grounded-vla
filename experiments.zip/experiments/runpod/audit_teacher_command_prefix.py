"""Replay a recorded teacher command prefix in evaluation environment; never learned success."""
import json
from pathlib import Path
import isaacsim
from isaacsim.simulation_app import SimulationApp
app=SimulationApp({'headless':True})
status=Path('/workspace/grounded-forge-status');result=dict(scope='Recorded teacher command replay diagnostic, not learned policy or task success',verified=False)
try:
 import numpy as np
 from grounded_vla.backends.isaacsim import IsaacSimConfig,IsaacSimEnvironment
 from isaacsim.core.utils.types import ArticulationAction
 root=Path('/workspace/grounded-vla');m=json.loads((root/'data/franka-recovery-v16/prepared.json').read_text());e=next(e for e in m['episodes'] if e['id']=='franka-seed-000')
 with np.load(root/'data/franka-recovery-v16'/e['path'],allow_pickle=False) as z:q=z['state'].copy();a=z['actions'].copy()
 config=IsaacSimConfig.load(root/'configs/runpod-franka-guarded.json');env=IsaacSimEnvironment.from_config(config)
 env.robot.set_joint_positions(q[0],joint_indices=env.indices);env.robot.set_joint_velocities(np.zeros(9),joint_indices=env.indices)
 env.robot.apply_action(ArticulationAction(joint_positions=q[0],joint_indices=env.indices))
 for _ in range(60):env._step_world()
 env._last_camera_times.clear();obs=env.observe();rows=[];rejected=None
 for i in range(min(600,len(q)-1)):
  before=obs.state.copy();time=float(env.world.current_time)
  try:obs=env.step(a[i])
  except ValueError as error:
   assert float(env.world.current_time)==time and np.array_equal(before,env._positions())
   rejected=dict(index=i,error=str(error),state=before.tolist(),command=a[i].tolist(),physics_unchanged=True);break
  difference=obs.state-q[i+1]
  rows.append(dict(index=i,expected_q=q[i+1].tolist(),actual_q=obs.state.tolist(),arm_error_norm_rad=float(np.linalg.norm(difference[:7])),finger_error_max_m=float(np.abs(difference[7:]).max())))
 result.update(verified=True,executed_steps=len(rows),rejected=rejected,initial_q_reference=q[0].tolist(),source='recorded guarded-v7 seed0 teacher',first_arm_error_gt1e_4=next((r['index'] for r in rows if r['arm_error_norm_rad']>1e-4),None),first_arm_error_gt1e_3=next((r['index'] for r in rows if r['arm_error_norm_rad']>1e-3),None),max_arm_error_norm_rad=max((r['arm_error_norm_rad'] for r in rows),default=None),max_finger_error_m=max((r['finger_error_max_m'] for r in rows),default=None),rows=rows)
 env.pause();print('TEACHER_PREFIX_RESULT',{k:v for k,v in result.items() if k!='rows'},flush=True)
except BaseException as e:
 result.update(verified=False,error_type=type(e).__name__,error=str(e));raise
finally:
 (status/'teacher-command-prefix-audit.json').write_text(json.dumps(result,indent=2));app.close()
