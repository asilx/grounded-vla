"""Paired target-binding KG intervention on real observations; no semantic-task success claim."""
import copy,json
from pathlib import Path
import numpy as np
from grounded_vla.training.inference import TrainedPi0Policy
from grounded_vla.training.velocity_graph import with_joint_velocities
ROOT=Path('/workspace/grounded-vla');STATUS=Path('/workspace/grounded-forge-status')
a=json.loads((STATUS/'pi0-mlp-transfer-v16-eval-audit.json').read_text())
assert a['status']=='completed' and {e['seed'] for e in a['attempts'] if e['result'].get('verified') and e['result'].get('task_success')}=={0,1,2}
mlp=json.loads((STATUS/'learned-baseline-v16-audit.json').read_text());e=next(e for e in mlp['attempts'] if e['seed']==0 and e['result'].get('task_success'))
p=Path(e['output'])/'learned-rollout.npz'
policy=TrainedPi0Policy(ROOT/'runs/franka-pi0-mlp-transfer-v16/step-00002000',device='cuda',num_steps=10,zero_noise=True)
meta=policy.meta;relation=meta['graph_schema']['relations'].index('target_of');none=meta['graph_schema']['relations'].index('none');results=[]
with np.load(p,allow_pickle=False) as z:
 q=z['state'];n=len(q)
 for i in np.linspace(0,n-1,16,dtype=int):
  graph=dict(schema_id=meta['proprio_velocity_graph']['source_schema_id'],features=z['graph_features'][i].copy(),edges=z['graph_edges'][i].copy(),valid=z['graph_valid'][i].copy())
  graph=with_joint_velocities(graph,q[i],q[max(i-1,0)],meta['control_period_seconds'])
  payload=dict(state=q[i],images={k:z['images/'+k][i] for k in ('base_0_rgb','left_wrist_0_rgb')},prompt=str(z['prompt'][i]),graph=graph)
  baseline=policy.infer(payload)['actions']
  changed=copy.deepcopy(payload);mask=changed['graph']['edges']==relation;assert mask.any();changed['graph']['edges'][mask]=none
  altered=policy.infer(changed)['actions']
  repeated=policy.infer(payload)['actions'];np.testing.assert_allclose(repeated,baseline,atol=1e-6)
  results.append(dict(frame=int(i),timestamp=float(z['timestamps'][i]),removed_target_of_edges=int(mask.sum()),baseline=baseline.tolist(),intervention=altered.tolist(),arm_command_delta_l2_rad=float(np.linalg.norm(altered[:,:7]-baseline[:,:7])),repeat_delta_max=float(np.abs(repeated-baseline).max())))
report=dict(scope='Offline paired semantic target-binding relation removal on actual successful learned-rollout images/state. Geometry, motor state, RGB, prompt and zero inference noise held fixed. Tests causal KG influence on command proposals; does not demonstrate semantic understanding, safety certification or successful execution of an altered semantic task.',model=policy.metadata,source_recording=str(p),results=results)
(STATUS/'v16-semantic-relation-intervention.json').write_text(json.dumps(report,indent=2));print('V16_PAIRED_SEMANTIC_RELATION_INTERVENTION_COMPLETE',flush=True)
