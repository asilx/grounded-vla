from pathlib import Path
import json,os
import numpy as np
from grounded_vla.training.data import prepare_dataset,load_prepared,encode_action_chunk
from grounded_vla.backends.isaacsim import IsaacSimConfig

root=Path('/workspace/grounded-vla'); original=root/'data/franka-guarded-v7/prepared.json'
meta=load_prepared(original); out=root/'data/franka-bounded-v9'
out.mkdir(parents=True,exist_ok=True)
assert not (out/'prepared.json').exists()
meta.pop('normalization');meta.pop('normalization_split')
limits=IsaacSimConfig.load(root/'configs/runpod-franka-guarded.json')
meta.update(action_encoding='bounded_joint_interval_logits',action_encoding_horizon=1,
            encoding_lower_limits=list(limits.lower_limits),encoding_upper_limits=list(limits.upper_limits),
            encoding_max_joint_step=list(limits.max_joint_step))
for e in meta['episodes']:e['path']=os.path.relpath((original.parent/e['path']).resolve(),out)
(out/'manifest.json').write_text(json.dumps(meta,indent=2))
prepared=prepare_dataset(out/'manifest.json',out/'prepared.json')
values=[]
for e in prepared['episodes']:
    if e['split']!='train':continue
    with np.load(out/e['path'],allow_pickle=False) as z:
        values.extend(encode_action_chunk(a[None],q,prepared) for a,q in zip(z['actions'],z['state']))
x=np.concatenate(values).astype(np.float64)
np.testing.assert_allclose(prepared['normalization']['action']['mean'],x.mean(0),atol=1e-7)
config=json.loads((root/'configs/runpod-pi0-guarded.json').read_text())
config.update(dataset='../data/franka-bounded-v9/prepared.json',output_dir='../runs/franka-pi0-bounded-v9',
              action_horizon=1,steps=2000,learning_rate=0.00005,eval_every=250,save_every=500,
              train_action_io=True,train_action_expert=True)
config.setdefault('adapter',{})['initial_gate']=0.05
(root/'configs/runpod-pi0-bounded.json').write_text(json.dumps(config,indent=2))
print('BOUNDED_DATA_PREPARED',prepared['normalization']['action'],flush=True)
