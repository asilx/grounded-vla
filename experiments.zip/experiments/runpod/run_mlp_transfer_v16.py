"""Finite next-stage coordinator; no transfer claim without three verified MLP successes."""
from pathlib import Path
import datetime,json,os,subprocess,time
ROOT=Path('/workspace/grounded-vla');STATUS=Path('/workspace/grounded-forge-status');os.chdir(ROOT)
out=STATUS/'v16-transfer-stage.json'
state=dict(status='waiting_for_mlp',scope='Conditional MLP to pi0 transfer; semantic relation intervention planned only after verified transfer',started=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():out.write_text(json.dumps(state,indent=2))
env=dict(os.environ,OPENPI_SOURCE='/workspace/support/openpi-source',JAX_PLATFORMS='cpu',TOKENIZERS_PARALLELISM='false',PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True')
try:
 save();deadline=time.monotonic()+7200
 while True:
  f=STATUS/'learned-baseline-v16-audit.json'
  if f.exists():
   a=json.loads(f.read_text())
   if a.get('status') in ('completed','error'):break
  pipeline=STATUS/'recovery-v16-pipeline.exit'
  if pipeline.exists() and int(pipeline.read_text())!=0:raise RuntimeError('Recovery pipeline failed')
  if time.monotonic()>deadline:raise TimeoutError('MLP physical evaluation deadline')
  time.sleep(5)
 successes={e['seed'] for e in a.get('attempts',[]) if e['result'].get('verified') and e['result'].get('task_success')}
 if a.get('status')!='completed' or successes!={0,1,2}:
  state.update(status='deferred_no_reproducible_mlp_success',mlp_audit_status=a.get('status'),successful_seeds=sorted(successes));save()
 else:
  state['status']='preparing_transfer';save()
  subprocess.run(['/workspace/pi0-train-env/bin/python','-u','experiments/runpod/prepare_mlp_pi0_transfer_v16.py'],env=env,check=True)
  state['status']='training_pi0_transfer';save()
  code=subprocess.run(['/workspace/pi0-train-env/bin/grounded-vla-train','configs/runpod-pi0-mlp-transfer-v16.json','--warm-start','runs/franka-pi0-velocity-v14/step-00004000','--stop-after','2000'],env=env).returncode
  (STATUS/'pi0-mlp-transfer-v16-train.exit').write_text(str(code));assert code==0
  state['status']='evaluating_pi0_transfer';save()
  subprocess.run(['/workspace/pi0-train-env/bin/python','-u','experiments/runpod/evaluate_pi0_transfer_v16.py'],env=env,check=True)
  pa=json.loads((STATUS/'pi0-mlp-transfer-v16-eval-audit.json').read_text())
  pi0_successes={e['seed'] for e in pa.get('attempts',[]) if e['result'].get('verified') and e['result'].get('task_success')}
  if pa.get('status')=='completed' and pi0_successes=={0,1,2}:
   state['status']='semantic_relation_intervention';save()
   subprocess.run(['/workspace/pi0-train-env/bin/python','-u','experiments/runpod/semantic_relation_intervention_v16.py'],env=env,check=True)
   state.update(status='completed',semantic_intervention=str(STATUS/'v16-semantic-relation-intervention.json'));save()
  else:
   state.update(status='deferred_no_reproducible_pi0_success',successful_pi0_seeds=sorted(pi0_successes));save()
except BaseException as e:
 state.update(status='error',error_type=type(e).__name__,error=str(e));save();raise
