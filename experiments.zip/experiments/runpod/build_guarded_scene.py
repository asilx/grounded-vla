"""Scripted Franka physics pilot; does not measure pretrained VLA performance."""
import argparse
import json
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=0)
args = parser.parse_args()
import importlib.metadata
ISAAC_VERSION=importlib.metadata.version("isaacsim")
import isaacsim
from isaacsim.simulation_app import SimulationApp
app = SimulationApp({'headless':True, 'width':640, 'height':480})
try:
    import omni.kit.app
    manager = omni.kit.app.get_app().get_extension_manager()
    manager.set_extension_enabled_immediate('isaacsim.core.api', True)
    manager.set_extension_enabled_immediate('isaacsim.sensors.experimental.rtx', True)
    manager.set_extension_enabled_immediate('isaacsim.robot.manipulators.examples', True)
    import numpy as np
    import omni.usd
    from pxr import UsdLux, UsdGeom, Gf
    from PIL import Image
    from isaacsim.core.api import World
    from isaacsim.core.api.objects import DynamicCuboid, FixedCuboid
    from isaacsim.robot.manipulators.examples.franka import Franka
    from isaacsim.robot.manipulators.examples.franka.controllers import PickPlaceController
    from isaacsim.sensors.experimental.rtx import RtxCamera, CameraSensor
    rng = np.random.default_rng(args.seed)
    destination = np.array([0.3,-0.3,0.02575])
    destination[:2] += rng.uniform(-0.015,0.015,size=2)
    directory = Path('/workspace/grounded-forge-status/franka-scene-calibration')/f'seed-{args.seed:03d}'
    directory.mkdir(parents=True,exist_ok=False)
    world = World(stage_units_in_meters=1.,physics_dt=1/60,rendering_dt=1/60)
    world.scene.add(FixedCuboid(prim_path='/World/Ground',name='ground',position=np.array([0.,0.,-.05]),scale=np.array([4.,4.,.1]),color=np.array([.25,.25,.25])))
    arm = world.scene.add(Franka(prim_path='/World/Robot',name='franka'))
    cargo = world.scene.add(DynamicCuboid(prim_path='/World/Cargo',name='cargo',position=np.array([0.3,0.3,0.15]),scale=np.full(3,0.0515),color=np.array([0.9,0.1,0.1])))
    dome = UsdLux.DomeLight.Define(omni.usd.get_context().get_stage(),'/World/Light')
    dome.CreateIntensityAttr(1500.)
    camera = RtxCamera('/World/Camera',tick_rate=60.0)
    transform=UsdGeom.Xformable(omni.usd.get_context().get_stage().GetPrimAtPath('/World/Camera'))
    transform.ClearXformOpOrder()
    transform.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(1.3,1.3,1.1),Gf.Vec3d(.3,0.,.2),Gf.Vec3d(0.,0.,1.)).GetInverse())
    sensor=CameraSensor(camera,resolution=(224,224),annotators=['rgb'])
    from grounded_vla.backends.rtx_camera import RtxCameraBridge
    import omni.replicator.core as rep
    timer=rep.AnnotatorRegistry.get_annotator('IsaacReadSimulationTime')
    timer.attach([str(sensor.render_product.GetPath())])
    base_bridge=RtxCameraBridge(sensor,timer)
    wrist_path='/World/Robot/panda_hand/WristCamera'
    wrist=RtxCamera(wrist_path,tick_rate=60.0)
    wt=UsdGeom.Xformable(omni.usd.get_context().get_stage().GetPrimAtPath(wrist_path))
    wt.ClearXformOpOrder()
    wt.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(.05,0,-.03),Gf.Vec3d(.05,0,.5),Gf.Vec3d(1,0,0)).GetInverse())
    wrist_bridge=RtxCameraBridge.attach(wrist_path,tick_rate=60.0)
    rows=[]
    last_image_times=None
    from grounded_vla.backends.isaacsim import IsaacSimConfig
    from isaacsim.core.utils.types import ArticulationAction
    limits=IsaacSimConfig.load('/workspace/grounded-vla/configs/runpod-franka-pi0.json')
    teacher_limited=0
    world.reset()
    arm.disable_gravity()
    servo=arm.get_articulation_controller()
    original_kp,original_kd=servo.get_gains()
    gains_kp=np.array([6000.]*7+[1000.,0.])
    gains_kd=np.array([300.]*7+[50.,0.])
    servo.set_gains(kps=gains_kp,kds=gains_kd,save_to_usd=True)
    (directory/'drive-gains.json').write_text(json.dumps({'kp':gains_kp.tolist(),'kd':gains_kd.tolist(),'original_kp':np.asarray(original_kp).tolist(),'original_kd':np.asarray(original_kd).tolist(),'scope':'simulation actuator tracking calibration; unchanged joint/step bounds','robot_gravity_compensation':'ideal: disabled gravity on robot links only','object_gravity':True},indent=2))
    print('SIMULATOR_DRIVE_GAINS',gains_kp.tolist(),gains_kd.tolist(),flush=True)
    for _ in range(60): world.step(render=True); world.render()
    stage=omni.usd.get_context().get_stage()
    target=Path('/workspace/grounded-vla/assets/runpod/franka-guarded.usda')
    assert not target.exists()
    for transient in ['/Render','/Replicator']:
        if stage.GetPrimAtPath(transient).IsValid():stage.RemovePrim(transient)
    stage.GetRootLayer().Export(str(target))
    (directory/'scene.json').write_text(json.dumps({'scope':'Matched training scene at initial settled state; not a task outcome','stage_path':str(target),'joint_state':arm.get_joint_positions().tolist(),'cube_position':cargo.get_world_pose()[0].tolist(),'robot_gravity_compensation':True,'cube_gravity_enabled':True},indent=2))
    print('MATCHED_SCENE_EXPORTED',target,flush=True)
except BaseException:
    import traceback;traceback.print_exc();raise
finally:
    app.close()
