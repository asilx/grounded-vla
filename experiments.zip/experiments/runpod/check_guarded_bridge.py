from pathlib import Path
import json
import isaacsim
from isaacsim.simulation_app import SimulationApp
app=SimulationApp({'headless':True})
try:
 import numpy as np
 from PIL import Image
 from grounded_vla.backends.isaacsim import IsaacSimConfig,IsaacSimEnvironment
 config=IsaacSimConfig.load('/workspace/grounded-vla/configs/runpod-franka-guarded.json')
 env=IsaacSimEnvironment.from_config(config)
 out=Path('/workspace/grounded-forge-status/guarded-native-bridge-check');out.mkdir(parents=True,exist_ok=True)
 obs=env.observe();times=[obs.timestamp];states=[obs.state.tolist()]
 for step in range(3):
  obs=env.step(np.clip(obs.state,config.lower_limits,config.upper_limits))
  times.append(obs.timestamp);states.append(obs.state.tolist())
  for name,image in obs.images.items():Image.fromarray(image).save(out/f'{name}-{step:02d}.png')
 checks=[]
 for kind in ['joint_limit','joint_step']:
  if kind=='joint_step':obs=env.reset()
  before=float(env.world.current_time);state=env.robot.get_joint_positions().copy()
  target=obs.state.copy()
  if kind=='joint_limit':target[0]=config.upper_limits[0]+1
  else:target[0]+=2*config.max_joint_step[0]
  try:
   env.step(target);raise AssertionError('Invalid target unexpectedly executed')
  except ValueError as error:
   after=float(env.world.current_time)
   unchanged=np.array_equal(state,env.robot.get_joint_positions())
   assert before==after and unchanged
   checks.append({'kind':kind,'error':str(error),'physics_time_before':before,'physics_time_after':after,'joint_state_unchanged':bool(unchanged)})
 assert np.allclose(np.diff(times),config.physics_dt*config.steps_per_action,atol=1e-7), ('control period mismatch',times)
 result={'scope':'native camera/state/action-guard integration; no learned policy','cameras':list(obs.images),'rgb_shapes':{k:list(v.shape) for k,v in obs.images.items()},'rgb_std':{k:float(v.std()) for k,v in obs.images.items()},'joint_count':len(obs.state),'timestamps':times,'state_history':states,'camera_freshness_passed':bool(np.all(np.diff(times)>0)),'rejections':checks}
 assert result['camera_freshness_passed'] and len(checks)==2
 (out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
except BaseException:
 import traceback;traceback.print_exc();raise
finally:app.close()
