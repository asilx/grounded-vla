#!/usr/bin/env bash
set -euo pipefail
export UV_CACHE_DIR=/tmp/isaac6-uv-cache
export UV_PYTHON_INSTALL_DIR=/workspace/python-runtimes
if [ ! -x /workspace/isaac6-env/bin/python ]; then uv venv --python 3.12 /workspace/isaac6-env; fi
uv pip install --python /workspace/isaac6-env/bin/python torch==2.11.0 --index-url https://download.pytorch.org/whl/cu130
uv pip install --python /workspace/isaac6-env/bin/python 'isaacsim[all,extscache]==6.1.0.0' --extra-index-url https://pypi.nvidia.com --index-strategy unsafe-best-match --prerelease allow
uv pip install --python /workspace/isaac6-env/bin/python -e '/workspace/grounded-vla[dev,simulation]' pillow
uv pip install --python /workspace/isaac6-env/bin/python --no-deps /workspace/support/openpi/packages/openpi-client
uv pip install --python /workspace/isaac6-env/bin/python --no-deps -r /workspace/grounded-vla/requirements-simulation.txt
uv pip freeze --python /workspace/isaac6-env/bin/python > /workspace/grounded-forge-status/isaac6-packages.txt
