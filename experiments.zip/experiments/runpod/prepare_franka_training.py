"""Convert actual Franka records into causal, pose-grounded training episodes.

This is a small pipeline check, not a semantic perception or safety benchmark.
Pose inputs come from simulator measurements. Semantic predicates stay unknown.
"""
import json
from pathlib import Path

import numpy as np

from grounded_vla.belief import BeliefStore
from grounded_vla.backends.isaacsim import IsaacSimConfig
from grounded_vla.training.data import prepare_dataset, load_prepared, load_episode
from grounded_vla.training.graph import FEATURES, RELATIONS, SCHEMA_ID, encode_belief_graph
from grounded_vla.training.recording import EpisodeRecorder
from grounded_vla.training.runtime import sha256

ROOT = Path('/workspace/grounded-forge-status/franka-expert-raw')
OUT = Path('/workspace/grounded-vla/data/franka-native-v1')


def red_cube_visible(base, wrist):
    # The procedural scene contains exactly one red object; this is not a
    # general-purpose learned detector. Pixel timestamps are retained below.
    for rgb in (base, wrist):
        x = rgb.astype(np.float32)
        red = (x[..., 0] > 60) & (x[..., 0] > 1.5 * x[..., 1]) & (x[..., 0] > 1.5 * x[..., 2])
        if int(red.sum()) >= 4:
            return True
    return False


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    OUT.mkdir(parents=True)
    entries, audit = [], []
    for seed, split in enumerate(('train', 'val', 'test')):
        source = ROOT / f'seed-{seed:03d}'
        verification = json.loads((source / 'verification.json').read_text())
        assert verification['verified'] and verification['sha256'] == sha256(source / 'expert-raw.npz')
        result = json.loads((source / 'result.json').read_text())
        assert result['success']
        with np.load(source / 'expert-raw.npz', allow_pickle=False) as z:
            raw = {k: z[k] for k in z.files}
        n = len(raw['states'])
        assert raw['end_effector_positions'].shape == raw['object_positions'].shape == (n, 3)
        assert np.isfinite(raw['end_effector_positions']).all()
        assert np.allclose(np.diff(raw['state_timestamps']), 1 / 60, atol=1e-7)
        ages = raw['state_timestamps'][:, None] - raw['image_timestamps']
        assert np.all(ages >= -1e-6) and np.all(ages <= .05)
        recorder, store = EpisodeRecorder(SCHEMA_ID), BeliefStore()
        # Reconstruct the task prior from the seed, independently of the
        # post-episode result; compare the latter only as a provenance check.
        goal = np.array([.3, -.3, .02575], np.float64)
        goal[:2] += np.random.default_rng(seed).uniform(-.015, .015, size=2)
        assert np.array_equal(goal, np.asarray(result['destination'], np.float64))
        for i, now in enumerate(raw['state_timestamps']):
            cargo, gripper = raw['object_positions'][i], raw['end_effector_positions'][i]
            base, wrist = raw['base_rgb'][i], raw['wrist_rgb'][i]
            objects = [
                dict(id='cargo', position=cargo, visible=red_cube_visible(base, wrist), is_target=True),
                dict(id='goal', position=goal, visible=False, is_target=False),
                dict(id='gripper', position=gripper, visible=False, is_target=False),
            ]
            relations = [('goal', 'target_of', 'cargo')]
            if np.linalg.norm(cargo - gripper) < .12:
                relations += [('cargo', 'near', 'gripper'), ('gripper', 'near', 'cargo')]
            graph = encode_belief_graph(store, objects, relations, now=float(now))
            # Empty evidence ledger means every clean/filled/held/at_tray
            # predicate remains unknown; controller phases/outcomes are unused.
            assert np.all(graph['features'][:, [8, 13, 18, 23]] == 1)
            recorder.append(
                state=raw['states'][i], action=raw['actions'][i],
                images={'base_0_rgb': base, 'left_wrist_0_rgb': wrist},
                prompt='Place the red cube at the graph goal.', graph=graph,
                timestamp=float(now), graph_timestamp=float(now),
            )
        episode = OUT / f'seed-{seed:03d}.npz'
        recorder.save(episode)
        # Retain sensor novelty separately from availability. Repeated frames
        # are actual recent sensor outputs, never new capture events or zeros.
        with np.load(episode, allow_pickle=False) as z:
            arrays = {k: z[k] for k in z.files}
        arrays['capture_timestamps'] = raw['image_timestamps']
        arrays['capture_fresh'] = raw['image_fresh']
        with episode.open('wb') as stream:
            np.savez_compressed(stream, **arrays)
        entries.append(dict(id=f'franka-seed-{seed:03d}', path=episode.name, split=split))
        audit.append(dict(seed=seed, split=split, frames=n,
                          fresh_camera_pairs=int(raw['image_fresh'].all(axis=1).sum()),
                          raw_sha256=verification['sha256'], episode_sha256=sha256(episode)))
        print('EPISODE_CONVERTED', seed, split, n, flush=True)
    manifest = dict(
        format_version=1, state_dim=9, action_dim=9, input_preset='canonical',
        action_convention=IsaacSimConfig.load('/workspace/grounded-vla/configs/runpod-franka-native.json').action_convention,
        control_period_seconds=1 / 60,
        graph_schema=dict(id=SCHEMA_ID, coordinate_frame='Isaac World, Z-up, metres; unscaled simulator oracle poses; goal is the prior task destination.',
                          features=list(FEATURES), relations=list(RELATIONS)),
        episodes=entries,
        provenance=dict(scope='Three-episode offline pipeline smoke test; not an independent scene/generalization benchmark.',
                        controller='Full absolute articulation targets read after submission before physics advance; seven arm positions in radians, then two finger positions in metres, in the native configuration joint order.',
                        graph_entities=['cargo', 'goal', 'gripper'],
                        semantic_predicates='Unknown; no held/clean/filled/at_tray labels inferred from future outcomes.',
                        visibility='Procedural red-pixel detection from actual current RGB buffers, at their retained capture timestamps.',
                        sensor_policy='Camera masks mean available actual buffers. capture_fresh separately marks new sensor frames; all capture ages are <=50ms.'),
    )
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    prepared = prepare_dataset(OUT / 'manifest.json', OUT / 'prepared.json')
    checked = load_prepared(OUT / 'prepared.json')
    for entry in checked['episodes']:
        load_episode(OUT / entry['path'], checked)
    with np.load(OUT / 'seed-000.npz', allow_pickle=False) as z:
        assert np.allclose(prepared['normalization']['state']['mean'], z['state'].astype(np.float64).mean(0))
        assert np.allclose(prepared['normalization']['action']['mean'], z['actions'].astype(np.float64).mean(0))
    (OUT / 'audit.json').write_text(json.dumps(dict(verified=True, episodes=audit, normalization_split='train'), indent=2))
    print('DATASET_PREPARED_AND_VERIFIED', OUT / 'prepared.json', flush=True)


if __name__ == '__main__':
    main()
