"""Read-only paired replay: identical recorded inputs, no training or simulator controls."""
import json,hashlib
from pathlib import Path
import numpy as np
import torch
from grounded_vla.training.data import decode_action_chunk
from learned_graph_baseline import numeric_inputs,causal_state_features
from learned_directional_v17 import BaselinePolicy
from learned_recurrent_v17b import Policy
ROOT=Path('/workspace/grounded-vla');STATUS=Path('/workspace/grounded-forge-status')
output=STATUS/'v17-input-command-diagnosis.json';assert not output.exists()

def load(path):
 with np.load(path,allow_pickle=False) as z:return {k:z[k].copy() for k in ['state','actions','graph_features','graph_edges','graph_valid']}

def compare(policy,raw,recurrent):
 q=raw['state'];a=raw['actions'];meta=policy.meta;period=meta['control_period_seconds'];artifact=policy.artifact
 context=causal_state_features(q,4,period);x=numeric_inputs(context,raw['graph_features'],raw['graph_edges'],raw['graph_valid'],len(meta['graph_schema']['relations']))
 normalized=(x-np.array(artifact['input_mean'],np.float32))/np.array(artifact['input_std'],np.float32)
 with torch.no_grad():
  if recurrent:predicted=policy.actor(torch.from_numpy(normalized)[None],None)[0][0].numpy()
  else:predicted=policy.actor(torch.from_numpy(normalized)).numpy()
 stats=meta['normalization']['action'];logits=predicted*np.array(stats['std'],np.float32)+np.array(stats['mean'],np.float32)
 offline=np.stack([decode_action_chunk(logits[i:i+1],q[i],meta)[0] for i in range(len(q))])
 policy.reset();stream=[]
 for i in range(len(q)):
  payload=dict(state=q[i],graph=dict(schema_id=meta['graph_schema']['id'],features=raw['graph_features'][i],edges=raw['graph_edges'][i],valid=raw['graph_valid'][i]))
  stream.append(policy.infer(payload)['actions'][0])
 stream=np.stack(stream);gap=np.max(np.abs(stream-offline),axis=1)
 teacher_delta=a[:,:7]-q[:,:7];model_delta=stream[:,:7]-q[:,:7];err=np.linalg.norm(stream[:,:7]-a[:,:7],axis=1);norm=np.linalg.norm(teacher_delta,axis=1);active=norm>1e-4
 cosine=np.sum(teacher_delta*model_delta,axis=1)/(norm*np.linalg.norm(model_delta,axis=1)+1e-12)
 return dict(samples=len(q),offline_streaming_max_command_gap=float(gap.max()),first_io_mismatch_gt1e_6=int(np.flatnonzero(gap>1e-6)[0]) if (gap>1e-6).any() else None,recorded_label_mean_arm_command_norm_rad=float(norm.mean()),model_mean_arm_command_norm_rad=float(np.linalg.norm(model_delta,axis=1).mean()),mean_arm_label_error_rad=float(err.mean()),active_fraction=float(active.mean()),active_median_error_to_label_norm_ratio=float(np.median(err[active]/norm[active])),active_opposite_arm_direction_fraction=float((cosine[active]<0).mean()),first32=[dict(index=i,state=q[i].tolist(),recorded_label=a[i].tolist(),model=stream[i].tolist(),arm_label_error_rad=float(err[i]),recorded_label_arm_delta_norm_rad=float(norm[i]),direction_cosine=float(cosine[i])) for i in range(min(32,len(q)))],stream=stream)

meta=json.loads((ROOT/'data/franka-recovery-v16/prepared.json').read_text());entry=next(e for e in meta['episodes'] if e['id']=='franka-seed-000');teacher_path=ROOT/'data/franka-recovery-v16'/entry['path'];teacher=load(teacher_path)
report=dict(scope='Paired same-observation input/command diagnosis; no training, task success or semantic claim',teacher_path=str(teacher_path),cases={})
for variant,cls,recurrent in [('v17',BaselinePolicy,False),('v17b',Policy,True)]:
 policy=cls(ROOT/'runs'/('learned-graph-baseline-'+variant));t=compare(policy,teacher,recurrent);t.pop('stream')
 rollout_path=STATUS/('learned-graph-baseline-'+variant+'-task')/'seed-0-attempt-0/learned-rollout.npz';actual=load(rollout_path);r=compare(policy,actual,recurrent);prediction=r.pop('stream');gap=np.max(np.abs(prediction-actual['actions']),axis=1)
 r['replay_vs_recorded_command_max_gap']=float(gap.max());r['first_replay_mismatch_gt1e_6']=int(np.flatnonzero(gap>1e-6)[0]) if (gap>1e-6).any() else None
 # Source geometry differences are observations, not evidence of a kinematic bug until controlled same-q audit.
 r['initial_arm_q_difference_from_teacher_rad']=float(np.linalg.norm(actual['state'][0,:7]-teacher['state'][0,:7]));r['initial_gripper_world_pose_difference_from_teacher_m']=float(np.linalg.norm(actual['graph_features'][0,2,:3]-teacher['graph_features'][0,2,:3]))
 checkpoints=[]
 for i in [0,1,9,29,99,299,599,1199,2999,len(actual['state'])-1]:
  distance=np.linalg.norm(teacher['state'][:,:7]-actual['state'][i,:7],axis=1);j=int(distance.argmin());checkpoints.append(dict(rollout_index=i,nearest_teacher_index=j,nearest_arm_distance_rad=float(distance[j])))
 r['nearest_teacher_support']=checkpoints
 report['cases'][variant]=dict(model_sha256=policy.artifact['weights_sha256'],teacher_forced=t,actual_rollout_replay=r)
 output.write_text(json.dumps(report,indent=2));print('DIAGNOSIS_CASE',variant,'teacher_io_gap',t['offline_streaming_max_command_gap'],'rollout_replay_gap',r['replay_vs_recorded_command_max_gap'],'teacher_arm_error',t['mean_arm_label_error_rad'],'error_to_command_ratio',t['active_median_error_to_label_norm_ratio'],'initial_pose_gap_m',r['initial_gripper_world_pose_difference_from_teacher_m'],flush=True)
print('DIAGNOSIS_READY',output,flush=True)
