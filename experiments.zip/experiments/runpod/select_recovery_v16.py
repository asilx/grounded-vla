"""Audit real learner drift and select pre-contact recovery resets; no policy control."""
import hashlib,json
from pathlib import Path
import numpy as np
ROOT=Path('/workspace/grounded-vla');STATUS=Path('/workspace/grounded-forge-status')
trace=STATUS/'learned-graph-baseline-v15-task/seed-0-attempt-0/trace.jsonl'
rows=[json.loads(s) for s in trace.read_text().splitlines()]
prepared=ROOT/'data/franka-recovery-v10/prepared.json';meta=json.loads(prepared.read_text())
references=[]
for e in meta['episodes']:
 if e['split']=='train':
  with np.load(prepared.parent/e['path'],allow_pickle=False) as d:
   references.append((e['id'],d['state'].copy()))
audit=[]
for step in (120,300,600,900,1200,1500,1800):
 row=next(r for r in rows if r['step']==step);q=np.array(row['joint_positions'])
 nearest=[]
 for name,states in references:
  distance=np.linalg.norm(states[:,:7]-q[:7],axis=1);idx=int(distance.argmin())
  nearest.append(dict(episode=name,index=idx,arm_l2_distance_rad=float(distance[idx])))
 audit.append(dict(step=step,cube=row['cube_position'],nearest=min(nearest,key=lambda x:x['arm_l2_distance_rad']),all_train_distances=nearest))
starts={}
for seed,step in zip((6,7,8),(600,900,1200)):
 row=next(r for r in rows if r['step']==step)
 assert np.linalg.norm(np.array(row['cube_position'])-np.array(rows[0]['cube_position']))<.001
 starts[str(seed)]=dict(joint_positions=row['joint_positions'],cube_position=row['cube_position'],
  source_trace=str(trace),source_trace_sha256=hashlib.file_digest(trace.open('rb'),'sha256').hexdigest(),source_step=step,source_timestamp=row['timestamp'],
  initialization_scope='Actual learner-visited q and cube position; new offline recovery episode. Joint velocities reset to zero, cube orientation nominal identity, 60 warmup ticks before recording; not identical-observation DAgger labeling.',
  warmup_ticks=60)
for path,data in [(STATUS/'recovery-v16-starts.json',starts),(STATUS/'recovery-v16-rollout-comparison.json',audit)]:
 assert not path.exists();path.write_text(json.dumps(data,indent=2))
print('V16_REAL_ROLLOUT_STARTS_SELECTED',[(k,v['source_step']) for k,v in starts.items()],flush=True)
for x in audit:print('TRAIN_SUPPORT_DISTANCE',x['step'],x['nearest'],flush=True)
