#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
for i in $(seq 1 1800); do
  if [ -f "$status/guarded-v7-training-200.exit" ]; then break; fi
  sleep 2
done
[ "$(cat "$status/guarded-v7-training-200.exit")" = 0 ]
[ "$(cat "$status/guarded-native-bridge.exit")" = 0 ]
JAX_PLATFORMS=cpu TOKENIZERS_PARALLELISM=false timeout 1800 \
 /workspace/pi0-train-env/bin/grounded-vla-serve runs/franka-pi0-guarded-v7/step-00000200 \
 --host 127.0.0.1 --port 8000 --device cuda --num-steps 10 --inference-seed 37 \
 > "$status/guarded-200-task-server.log" 2>&1 &
server_pid=$!
echo "$server_pid" > "$status/guarded-200-task-server.pid"
trap 'kill "$server_pid" 2>/dev/null || true' EXIT
/workspace/pi0-train-env/bin/python - <<'PY'
import time
from grounded_vla.backends.openpi import OpenPiTransport
for i in range(240):
    try:
        with OpenPiTransport('ws://127.0.0.1:8000',timeout=1.) as c:
            assert c.metadata['checkpoint_step']==200 and c.metadata['robot_interface_adaptation']
        print('GUARDED_200_POLICY_READY',flush=True)
        break
    except Exception:time.sleep(1)
else:raise TimeoutError('Model did not become ready')
PY
OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1 timeout 1200 \
 /workspace/isaac6-env/bin/python -u experiments/runpod/evaluate_pi0_task.py --seed 0 \
 --execute-steps 3 --out "$status/guarded-200-task/seed-0" \
 > "$status/guarded-200-task-seed-0.log" 2>&1
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('/workspace/grounded-forge-status/guarded-200-task/seed-0/result.json').read_text())
assert r.get('verified')
print('GUARDED_200_LEARNED_TASK',r['task_success'],r['reason'],r['executed_steps'],flush=True)
PY
