#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
export OPENPI_DATA_HOME=/tmp/grounded-pi0-assets
export JAX_PLATFORMS=cpu
export XLA_PYTHON_CLIENT_PREALLOCATE=false
python=/workspace/pi0-train-env/bin/python
"$python" -u - <<'PY'
import json, shutil
from pathlib import Path
import fsspec
from openpi.shared.download import maybe_download
fs=fsspec.filesystem('gs',token='anon')
size=fs.du('openpi-assets/checkpoints/pi0_base',total=True)
free=shutil.disk_usage('/workspace').free
print('MODEL_PREFLIGHT_BYTES',size,'free',free,flush=True)
assert size+25*1024**3 < free, 'Insufficient source, conversion, and reserve disk space'
source=maybe_download('gs://openpi-assets/checkpoints/pi0_base',gs={'token':'anon'})
assert (source/'params').exists()
tokenizer=maybe_download('gs://big_vision/paligemma_tokenizer.model',gs={'token':'anon'})
folder=Path('/workspace/models/tokenizers');folder.mkdir(parents=True,exist_ok=True)
shutil.copy2(tokenizer,folder/'paligemma_tokenizer.model')
Path('/workspace/grounded-forge-status/pi0-download.json').write_text(json.dumps({'source':str(source),'source_bytes':size,'tokenizer':str(folder/'paligemma_tokenizer.model'),'license_source':'https://github.com/Physical-Intelligence/openpi'},indent=2))
print('MODEL_AND_TOKENIZER_DOWNLOADED',source,flush=True)
PY
"$python" -u scripts/convert_pi0_checkpoint.py --openpi-dir /workspace/support/openpi-source --source /tmp/grounded-pi0-assets/openpi-assets/checkpoints/pi0_base --out /workspace/models/pi0-base-torch --precision bfloat16
