#!/bin/bash
ulimit -c 0
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 PYTHONUNBUFFERED=1
cd /workspace/grounded-vla
if [ -f /workspace/grounded-forge-status/physics-rgb-smoke/result.json ]; then mv /workspace/grounded-forge-status/physics-rgb-smoke/result.json /workspace/grounded-forge-status/physics-rgb-smoke/previous-result.json; fi
timeout 900 /workspace/isaac6-env/bin/python experiments/runpod/physics_rgb_smoke.py > /workspace/grounded-forge-status/physics-rgb-smoke.log 2>&1
python3.11 - <<'PY'
import json,sys
r=json.load(open('/workspace/grounded-forge-status/physics-rgb-smoke/result.json'))
sys.exit(0 if r['physics_passed'] and r['rgb_passed'] else 1)
PY
echo $? > /workspace/grounded-forge-status/physics-rgb-smoke.exit
