"""Correct inherited human-readable model labels; preserve every measurement."""
import hashlib,json,datetime
from pathlib import Path
s=Path('/workspace/grounded-forge-status');md=json.loads(Path('/workspace/grounded-vla/runs/learned-local-field-v18/metadata.json').read_text());records=[]
for p in (s/'learned-local-field-v18-task').glob('*/result.json'):
 before=p.read_bytes();d=json.loads(before);assert d['verified'] and d['task_success'];assert d['policy_metadata']['policy']==md['policy'];assert d['policy_metadata']['weights_sha256']==md['weights_sha256']
 original=p.with_name('result.original.json');assert not original.exists();original.write_bytes(before)
 after=dict(d);after['scope']='Closed-loop '+md['scope'];assert {k:v for k,v in d.items() if k!='scope'}=={k:v for k,v in after.items() if k!='scope'}
 p.write_text(json.dumps(after,indent=2));records.append({'file':str(p),'original':str(original),'original_sha256':hashlib.sha256(before).hexdigest(),'old_scope':d['scope'],'new_scope':after['scope'],'measurement_fields_unchanged':True})
 # Both success-preservation archives receive the same scope-only correction.
 archives=[s/'successful-learned-baseline-snapshots'/('v18-'+p.parent.name)/'verified-result.json',s/'successful-learned-snapshots'/('learned-local-field-v18-task-'+p.parent.name)/'verified-result.json']
 for a in archives:
  if a.exists():
   a.with_name('verified-result.original.json').write_bytes(a.read_bytes());a.write_text(json.dumps(after,indent=2))
a=s/'learned-baseline-v18-audit.json';before=a.read_bytes();d=json.loads(before);assert d['status']=='completed';a.with_name('learned-baseline-v18-audit.original.json').write_bytes(before);d['scope']=md['scope']
for r in d['attempts']:r['result']=json.loads((Path(r['output'])/'result.json').read_text())
a.write_text(json.dumps(d,indent=2));report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Reusable evaluator inherited the human-readable MLP scope label; actual policy_metadata and checkpoint already correctly identified learned local field','changed_fields':['scope'],'physics_outcomes_unchanged':True,'records':records};(s/'v18-scope-metadata-correction.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
