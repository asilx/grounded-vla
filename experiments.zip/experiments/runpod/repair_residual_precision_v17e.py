"""Reconstruct the already-selected residual fit without float32 coefficient loss."""
import json,hashlib,shutil
from pathlib import Path
import numpy as np
import torch
from safetensors.torch import load_file,save_file
from learned_directional_v17 import Actor,read_numeric,physical_targets,numeric_inputs,causal_state_features
from local_residual_v17d import basis
root=Path('/workspace/grounded-vla');old=root/'runs/learned-graph-baseline-v17d';out=root/'runs/learned-graph-baseline-v17e';assert not out.exists();torch.set_num_threads(4)
md=json.loads((old/'metadata.json').read_text());meta=md['dataset'];p=root/'data/franka-recovery-v16/prepared.json'
x,y,q,a=read_numeric(p,meta,'train',md['history_steps']);mean=np.asarray(md['input_mean'],np.float32);std=np.asarray(md['input_std'],np.float32);xs=torch.from_numpy((x-mean)/std)
actor=Actor(md['input_dim'],meta['action_dim'],md['width']);actor.load_state_dict(load_file(str(old/'actor.safetensors')));actor.eval();r=load_file(str(old/'residual.safetensors'));centers=r['centers'].double();selected=md['residual'];width=selected['width'];ridge=selected['ridge']
with torch.no_grad():base=actor(xs)
h=basis(xs.double(),centers,width);w=torch.ones(len(x),dtype=torch.float64);offset=0
for e in meta['episodes']:
 if e['split']!='train':continue
 with np.load(p.parent/e['path'],allow_pickle=False) as z:n=len(z['state'])
 w[offset:offset+min(n,64)]=10;offset+=n
residual=torch.from_numpy(y[:,:7]).double()-base[:,:7].double();coeff=torch.linalg.solve(h.T@(w[:,None]*h)+ridge*torch.eye(len(centers),dtype=torch.float64),h.T@(w[:,None]*residual))
out.mkdir();shutil.copy2(old/'actor.safetensors',out/'actor.safetensors');save_file({'centers':centers.contiguous(),'coefficients':coeff.contiguous()},str(out/'residual.safetensors'))
md['residual_sha256']=hashlib.file_digest((out/'residual.safetensors').open('rb'),'sha256').hexdigest();md['scope']='V17E numerical precision ablation of V17D: identical selected basis centers, width and ridge; preserve float64 residual coefficients and distance evaluation; unchanged MLP and finger commands';md['precision']='float64 kernel distances and coefficients; final neural logits remain float32';md['parent_residual_sha256']=hashlib.file_digest((old/'residual.safetensors').open('rb'),'sha256').hexdigest();(out/'metadata.json').write_text(json.dumps(md,indent=2))
records=[]
for split in ['train','val']:
 tx,ty,tq,ta=read_numeric(p,meta,split,md['history_steps']);xt=torch.from_numpy((tx-mean)/std)
 with torch.no_grad():b=actor(xt);fixed=b.clone();fixed[:,:7]+=(basis(xt.double(),centers,width)@coeff).float();oldpred=b.clone();oldpred[:,:7]+=basis(xt,r['centers'],width)@r['coefficients'];desired=torch.from_numpy(ta);states=torch.from_numpy(tq)
 for name,pred in [('v17d_float32',oldpred),('v17e_float64',fixed)]:
  err=torch.linalg.vector_norm((physical_targets(pred,states,meta)-desired)[:,:7],dim=1);records.append(dict(split=split,model=name,mean_arm_error_rad=err.mean().item(),first_arm_error_rad=err[0].item(),first32_arm_error_rad=err[:32].mean().item()))
report={'scope':md['scope'],'no_hyperparameter_reselection':True,'max_coefficient_magnitude':float(coeff.abs().max()),'scores':records};(out/'metrics.json').write_text(json.dumps(report,indent=2));Path('/workspace/grounded-forge-status/v17e-precision-repair.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
