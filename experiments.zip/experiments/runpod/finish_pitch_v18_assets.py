"""Produce pitch media and current-source archives with verified provenance."""
import base64,datetime,hashlib,json,shutil,subprocess,time,zipfile
from pathlib import Path
root=Path('/workspace/grounded-vla');status=Path('/workspace/grounded-forge-status');out=status/'pitch-v18-deliverables'
deadline=time.monotonic()+2400
while True:
 a=status/'pitch-v18-recording-retake1-audit.json';d=json.loads(a.read_text()) if a.exists() else {}
 if d.get('status') in ('completed','error') and (out/'original-video-provenance.json').exists():break
 if time.monotonic()>deadline:raise TimeoutError('Pitch assets readiness')
 time.sleep(3)
original=[]
for seed in [0,1,2]:
 p=status/'learned-local-field-v18-task'/f'seed-{seed}-attempt-0';r=json.loads((p/'result.json').read_text());assert r['verified'] and r['task_success'];original.append(r)
 target=out/'snapshots'/f'original-seed-{seed}';target.mkdir(parents=True)
 for row in json.loads((p/'snapshots/index.json').read_text()):
  key='document_camera_1024' if 'document_camera_1024' in row['images'] else 'base_0_rgb';name=row['images'][key]
  shutil.copy2(p/'snapshots'/name,target/(row['label']+'.png'));(target/(row['label']+'.json')).write_text(json.dumps(row,indent=2))
 (target/'verified-result.json').write_text(json.dumps(r,indent=2))
recording=status/'learned-v18-pitch-recording/seed-0-retake-1';r=json.loads((recording/'result.json').read_text()) if (recording/'result.json').exists() else {}
live=bool(r.get('verified') and r.get('task_success') and r.get('pitch_video',{}).get('encoder_exit')==0 and r['pitch_video']['frames']>100)
if live:
 source=recording/'grounded-forge-v18-live-1024.mp4';shutil.copy2(source,out/source.name);source=out/source.name
 shutil.copy2(recording/'result.json',out/'live-pitch-take-result.json');shutil.copy2(recording/'video-capture-records.json',out/'live-video-capture-records.json')
 shutil.copytree(recording/'snapshots',out/'snapshots/live-pitch-take')
else:source=out/'v18-seed-0-base-original-60fps.mp4';r=original[0]
font=next(iter(Path('/usr/share/fonts').rglob('DejaVuSans.ttf')),None)
if font is None:raise RuntimeError('No installed DejaVuSans font')
labels=[('GROUNDED',48,70,42,'white'),('FORGE',48,126,42,'0xF9A64A'),('Learned',48,244,32,'white'),('pick and place',48,290,32,'white'),('Isaac Sim | V18',48,390,24,'0xBAC7DE'),('2x playback',48,432,24,'0xBAC7DE'),('This take',48,596,22,'0xBAC7DE'),('Verified success',48,634,27,'0x70E6BA'),(f"XY error: {r['planar_error_m']*1000:.1f} mm",48,690,24,'white'),('Stable release: 2.0 s',48,730,22,'white'),('Actual simulator footage',48,956,20,'0xBAC7DE'),('Learned local control',48,990,20,'0xBAC7DE'),('Earlier evaluation',1516,88,26,'0xBAC7DE'),('3 / 3 successful trials',1516,134,28,'0x70E6BA')]
for i,o in enumerate(original):labels.extend([(f"Seed {i}",1516,280+i*120,26,'white'),(f"XY error: {o['planar_error_m']*1000:.1f} mm",1516,322+i*120,23,'0xBAC7DE')])
labels.extend([('Controlled task',1516,848,22,'white'),('Small goal perturbations',1516,888,19,'0xBAC7DE'),('Native camera recording',1516,990,19,'0xBAC7DE')])
filters=['setpts=PTS/2','fps=30','scale=1024:1024:flags=lanczos','pad=1920:1080:448:28:color=0x0D1526']
for i,(text,x,y,size,color) in enumerate(labels):
 p=out/f'label-{i:02d}.txt';p.write_text(text);filters.append(f'drawtext=fontfile={font}:textfile={p}:expansion=none:fontsize={size}:fontcolor={color}:x={x}:y={y}')
pitch=out/'grounded-forge-v18-pitch.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),'-vf',','.join(filters),'-an','-c:v','libx264','-preset','fast','-crf','18','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',str(pitch)],check=True)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height,codec_name,pix_fmt,avg_frame_rate,nb_frames:format=duration,size','-of','json',str(pitch)]));assert probe['streams'][0]['width']==1920 and probe['streams'][0]['height']==1080
for t in [8,17,24]:subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(t),'-i',str(pitch),'-frames:v','1',str(out/f'pitch-preview-{t:02d}s.png')],check=True)
provenance={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pitch_file':pitch.name,'pitch_probe':probe,'playback_speed':2,'pitch_source':'New live verified learned V18 controller rollout' if live else 'Original verified seed0 native camera recording','pitch_source_resolution':r.get('pitch_video',{}).get('source_resolution',[224,224]),'pitch_source_sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'original_evaluation':[{'seed':o['seed'],'verified':o['verified'],'task_success':o['task_success'],'steps':o['executed_steps'],'xy_error_mm':o['planar_error_m']*1000,'rollout_sha256':o['rollout_recording_sha256']} for o in original],'scope':'Learned numeric local control using simulator-oracle geometry; no pi0/VLA, semantic causal effect or real-robot performance claim','live_recording_verified_success':live}
(out/'pitch-provenance.json').write_text(json.dumps(provenance,indent=2))
(out/'README.txt').write_text('Grounded Forge — pitch media'+chr(10)*2+'Main pitch clip: 1920x1080, 30 fps, 2x playback, actual simulator camera recording. See pitch-provenance.json for exact source and original resolution.'+chr(10)+'Original seed0/1/2 base and wrist videos: exact recorded camera frames,224x224,60fps,real-time playback. No generated/interpolated motion.'+chr(10)+'Snapshots: original native image buffers at initialization, lift, transport, release and final verified success; documentary camera snapshots are1024x1024 where available. Initial observations are224x224.'+chr(10)+'Outcome scope: learned local control in a controlled simulated task with small goal perturbations. Do not describe these as pi0/VLA, semantic-adapter causality or real-robot demonstrations.'+chr(10))
media=out/'grounded-forge-v18-pitch-assets.zip'
with zipfile.ZipFile(media,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file() and p.suffix in ('.mp4','.png','.json','.txt') and not p.name.startswith('label-'):z.write(p,str(p.relative_to(out)))
(status/'V18_PITCH_ASSETS_EXPORT.txt').write_text(base64.b64encode(media.read_bytes()).decode())
# Final snapshot of the current source, after recording fixes. No branch instructions.
selected=[];top=['README.md','pyproject.toml','requirements-simulation.txt','requirements-training.txt','Dockerfile.isaacsim','Dockerfile.train','LICENSE','NOTICE','CITATION.cff','CONTRIBUTING.md','CHANGELOG.md','.gitignore'];allowed={'.py','.sh','.md','.json','.toml','.yaml','.yml','.txt','.ttl','.owl','.rdf','.urdf','.xacro','.csv','.png','.svg','.cff'}
for name in top:
 p=root/name
 if p.is_file():selected.append(p)
for name in ['src','configs','experiments','tests','docs','scripts','examples','knowledge','assets','.github']:
 for p in (root/name).rglob('*'):
  if p.is_file() and not p.is_symlink() and p.suffix.lower() in allowed and not any(x in ('__pycache__','.git','.venv','node_modules') or x.endswith('.egg-info') for x in p.relative_to(root).parts) and not p.name.startswith('.env') and p.suffix not in ('.pem','.key'):selected.append(p)
sourcezip=out/'grounded-forge-v18-current-source.zip';manifest={'exported_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'Actual current running pod project; generated checkpoints/data/cache excluded except explicit V18 model artifact','git_history_included':False,'files':[]}
with zipfile.ZipFile(sourcezip,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(selected)):
  b=p.read_bytes();name=str(p.relative_to(root));z.writestr(name,b);manifest['files'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 for p in (root/'runs/learned-local-field-v18').glob('*'):
  if p.is_file():z.write(p,'artifacts/isaac-v18/model/'+p.name)
 for seed,o in enumerate(original):z.writestr(f'artifacts/isaac-v18/results/seed-{seed}.json',json.dumps(o,indent=2))
 z.writestr('artifacts/isaac-v18/RESULTS.md','# Verified V18 learned-control results'+chr(10)*2+chr(10).join(f"- Seed {o['seed']}: verified success;{o['executed_steps']} accepted actions;XY error{o['planar_error_m']*1000:.3f}mm;120 stable release steps." for o in original)+chr(10)*2+'Learned local dynamical-field numeric imitation, simulator-oracle geometry. No pi0/VLA or semantic causal-effect claim. The source preserves the existing Runpod runtime paths and external Isaac/OpenPI dependencies; original training RGB data and vendor robot assets are not embedded.'+chr(10))
 z.writestr('SOURCE_EXPORT_MANIFEST.json',json.dumps(manifest,indent=2))
(status/'V18_CURRENT_SOURCE_EXPORT.txt').write_text(base64.b64encode(sourcezip.read_bytes()).decode());(out/'DELIVERY_COMPLETE.json').write_text(json.dumps({'media_bytes':media.stat().st_size,'code_bytes':sourcezip.stat().st_size,'pitch_bytes':pitch.stat().st_size,'live_success':live,'source_files':len(selected),'pitch_duration':probe['format']['duration']},indent=2));print('DELIVERY_COMPLETE',(out/'DELIVERY_COMPLETE.json').read_text(),flush=True)
