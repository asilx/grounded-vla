#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
/workspace/pi0-train-env/bin/python - <<'PY'
import time
from grounded_vla.backends.openpi import OpenPiTransport
for i in range(240):
    try:
        with OpenPiTransport('ws://127.0.0.1:8000',timeout=1.) as c:
            assert c.metadata['checkpoint_step']==100
            assert c.metadata['robot_interface_adaptation'] is False
        print('OLD_POLICY_READY',flush=True)
        break
    except Exception:
        time.sleep(1)
else: raise TimeoutError('Original policy did not become ready')
PY
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1
for seed in 0 1 2; do
    timeout 900 /workspace/isaac6-env/bin/python -u experiments/runpod/evaluate_pi0_task.py \
      --seed "$seed" --out "/workspace/grounded-forge-status/old-policy-task/seed-$seed" \
      > "/workspace/grounded-forge-status/old-policy-task-seed-$seed.log" 2>&1
done
/workspace/pi0-train-env/bin/python - <<'PY'
import json
from pathlib import Path
root=Path('/workspace/grounded-forge-status/old-policy-task')
rows=[json.loads((root/f'seed-{i}'/'result.json').read_text()) for i in range(3)]
assert all(x.get('verified') for x in rows)
r={'scope':'Original 100-step graph-only policy on ideal robot gravity-compensation scene; no learned output clipping',
   'episodes':rows,'successes':sum(x['task_success'] for x in rows),'attempts':len(rows)}
(root/'summary.json').write_text(json.dumps(r,indent=2))
print('ORIGINAL_POLICY_TASK_SUCCESS',r['successes'],r['attempts'],flush=True)
PY
