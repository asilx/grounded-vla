#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
export UV_CACHE_DIR=/tmp/grounded-train-uv-cache
export UV_PYTHON_INSTALL_DIR=/workspace/python-runtimes
python=/workspace/pi0-train-env/bin/python
if [ ! -x "$python" ]; then uv venv --python 3.11 /workspace/pi0-train-env; fi
uv pip install --python "$python" torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128
uv pip install --python "$python" -r requirements-training.txt
uv pip install --python "$python" --no-deps -e /workspace/support/openpi-source -e /workspace/support/openpi-source/packages/openpi-client -e /workspace/grounded-vla
"$python" scripts/patch_openpi_transformers.py
uv pip install --python "$python" pytest
"$python" - <<'PY'
import torch
from grounded_vla.training.runtime import verify_runtime
verify_runtime()
assert torch.cuda.is_available()
x=torch.arange(10,device='cuda')
assert float((x*x).sum().cpu())==285
print('TRAIN_RUNTIME_VERIFIED',torch.__version__,torch.cuda.get_device_name(0),flush=True)
PY
"$python" -m pytest tests/test_pi0_integration.py -q
