#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv > "$status/resume-gpu.txt"
bash experiments/runpod/setup_system.sh > "$status/resume-system.log" 2>&1
timeout 1800 bash experiments/runpod/install_isaac6.sh > "$status/resume-install.log" 2>&1
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1
ulimit -c 0
timeout 900 /workspace/isaac6-env/bin/python experiments/runpod/check_native_bridge.py > "$status/resume-native-bridge.log" 2>&1
/workspace/isaac6-env/bin/python - <<'PY'
from pathlib import Path
import json
p=Path('/workspace/grounded-forge-status/native-bridge-check/result.json')
assert p.exists(), 'native bridge result missing'
print(json.dumps(json.loads(p.read_text()),indent=2))
PY
