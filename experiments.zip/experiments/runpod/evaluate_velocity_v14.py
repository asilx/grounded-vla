"""Finite learned-policy evaluation sequence; teacher data never controls evaluation."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path('/workspace/grounded-vla')
STATUS = Path('/workspace/grounded-forge-status')
os.chdir(ROOT)
ENV = dict(os.environ, OPENPI_SOURCE='/workspace/support/openpi-source',
           JAX_PLATFORMS='cpu', TOKENIZERS_PARALLELISM='false',
           OMNI_KIT_ACCEPT_EULA='YES', OMNI_KIT_ALLOW_ROOT='1')
audit = {'started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'strategy': 'Native pi0 plus causal observed motor velocity graph; seed0 first, held-out seeds1/2 after success; unchanged physical criteria.',
         'attempts': []}


def persist():
    (STATUS/'pi0-velocity-v14-eval-audit.json').write_text(json.dumps(audit, indent=2))


def wait_exit(name, limit=7200):
    deadline = time.monotonic() + limit
    p = STATUS/name
    while not p.exists():
        if time.monotonic() > deadline:
            raise TimeoutError(name)
        time.sleep(5)
    return int(p.read_text().strip())


def run_seed(prefix, seed, checkpoint):
    for attempt in range(2):
        folder = STATUS/f'{prefix}-task'/f'seed-{seed}-attempt-{attempt}'
        if folder.exists():
            raise FileExistsError(folder)
        log = STATUS/f'{prefix}-seed-{seed}-attempt-{attempt}.log'
        cmd = ['/workspace/isaac6-env/bin/python', '-u',
               'experiments/runpod/evaluate_pi0_velocity_task.py', '--uri', 'ws://127.0.0.1:8004', '--seed', str(seed),
               '--execute-steps', '1', '--out', str(folder)]
        with log.open('w') as stream:
            try:
                code = subprocess.run(cmd, env=ENV, stdout=stream,
                                      stderr=subprocess.STDOUT, timeout=3000).returncode
            except subprocess.TimeoutExpired:
                code = 124
        path = folder/'result.json'
        result = json.loads(path.read_text()) if path.exists() else {
            'verified': False, 'task_success': False, 'reason': 'no_authoritative_result',
            'process_exit': code}
        entry = {'case': prefix, 'seed': seed, 'attempt': attempt,
                 'checkpoint': str(checkpoint), 'process_exit': code,
                 'output': str(folder), 'result': result}
        audit['attempts'].append(entry)
        persist()
        print('ATTEMPT_COMPLETED', prefix, seed, attempt, result.get('verified'),
              result.get('task_success'), result.get('reason'), flush=True)
        if result.get('verified') and result.get('task_success'):
            archive = STATUS/'successful-learned-snapshots'/f'{prefix}-seed-{seed}-attempt-{attempt}'
            archive.mkdir(parents=True, exist_ok=True)
            shutil.copy2(checkpoint/'metadata.json', archive/'checkpoint-metadata.json')
            provenance = {'checkpoint': str(checkpoint), 'weights_sha256': {
                p.name: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
                for p in checkpoint.glob('*.safetensors')},
                'evaluation_result': str(path), 'seed': seed, 'attempt': attempt}
            (archive/'model-provenance.json').write_text(json.dumps(provenance, indent=2))
            if (folder/'snapshots').exists():
                shutil.copytree(folder/'snapshots', archive/'snapshots', dirs_exist_ok=True)
            shutil.copy2(path, archive/'verified-result.json')
            return True
        if result.get('verified') or result.get('error_type') != 'CameraNotReady':
            return False
    return False


def evaluate(prefix, checkpoint, step):
    from grounded_vla.backends.openpi import OpenPiTransport
    serverlog = STATUS/f'{prefix}-server.log'
    with serverlog.open('w') as stream:
        server = subprocess.Popen([
            '/workspace/pi0-train-env/bin/grounded-vla-serve', str(checkpoint),
            '--host', '127.0.0.1', '--port', '8004', '--device', 'cuda',
            '--num-steps', '10', '--inference-seed', '37', '--zero-noise'],
            env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        try:
            deadline = time.monotonic()+360
            while True:
                if server.poll() is not None:
                    raise RuntimeError('Policy server exited before readiness')
                try:
                    with OpenPiTransport('ws://127.0.0.1:8004', timeout=2) as client:
                        assert client.metadata['checkpoint_step'] == step
                        assert client.metadata['graph_schema_id'] == 'grounded-vla-belief-motor-velocity-v2'
                        assert client.metadata['graph_feature_dim'] == 35
                        assert client.metadata['action_expert_adaptation']
                        assert client.metadata['action_encoding'] == 'bounded_joint_interval_logits'
                    break
                except Exception:
                    if time.monotonic() > deadline:
                        raise TimeoutError('Policy server readiness')
                    time.sleep(1)
            if not run_seed(prefix, 0, checkpoint):
                print('GENERALIZATION_DEFERRED_AFTER_SEED0_FAILURE', prefix, flush=True)
                return False
            for seed in (1, 2):
                run_seed(prefix, seed, checkpoint)
            return True
        finally:
            server.terminate()
            try:
                server.wait(timeout=20)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait()


try:
    persist()
    assert wait_exit('pi0-velocity-v14-train.exit') == 0
    evaluate('pi0-velocity-v14-final4000', ROOT/'runs/franka-pi0-velocity-v14/step-00004000', 4000)
    audit['status'] = 'completed'
except BaseException as exc:
    audit.update(status='error', error_type=type(exc).__name__, error=str(exc))
    raise
finally:
    audit['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    persist()
