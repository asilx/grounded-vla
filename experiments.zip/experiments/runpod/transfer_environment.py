import getpass,urllib.request,urllib.parse,urllib.error,pathlib,json,hashlib,time,tarfile
base=getpass.getpass('Source Jupyter login URL (hidden): ')
u=urllib.parse.urlsplit(base)
def fetch(name):
    url=urllib.parse.urlunsplit((u.scheme,u.netloc,'/files/workspace/'+name,'',''))
    token=urllib.parse.parse_qs(u.query)['token'][0]
    req=urllib.request.Request(url,headers={'Authorization':'token '+token,'User-Agent':'Mozilla/5.0'})
    try: return urllib.request.urlopen(req,timeout=120)
    except urllib.error.HTTPError as e:
        print('HTTP',e.code,e.read(200).decode(errors='replace'),flush=True); raise SystemExit(1)
with fetch('grounded-forge-status/archive.sha256') as r:
    expected=r.read().decode().split()[0]
print('Expected SHA256:',expected,flush=True)
dest=pathlib.Path('/workspace/isaac-env-complete.tar')
h=hashlib.sha256(); total=0; last=0; started=time.monotonic()
with fetch('isaac-env-complete.tar') as r, dest.open('wb') as f:
    length=int(r.headers.get('Content-Length',0))
    assert 'text/html' not in r.headers.get('Content-Type','')
    print('Downloading bytes:',length,flush=True)
    while block:=r.read(8*1024*1024):
        f.write(block); h.update(block); total+=len(block)
        if total-last>=1024**3:
            print('Downloaded GiB:',round(total/1024**3,2),'seconds:',round(time.monotonic()-started),flush=True); last=total
assert total==length,(total,length)
assert h.hexdigest()==expected,(h.hexdigest(),expected)
print('SHA256 verified. Extracting.',flush=True)
with tarfile.open(dest) as t: t.extractall('/workspace')
pathlib.Path('/workspace/grounded-forge-status/transfer-result.json').write_text(json.dumps({'sha256':expected,'bytes':total,'verified':True,'extracted':True},indent=2))
print('Environment transfer completed.',flush=True)
