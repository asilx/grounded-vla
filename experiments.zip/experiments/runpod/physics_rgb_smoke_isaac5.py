"""Procedural physics/RGB check, not a VLA or manipulation benchmark."""
import json
from pathlib import Path
from isaacsim import SimulationApp
app = SimulationApp({'headless': True, 'width': 640, 'height': 480})
try:
    import numpy as np
    import omni.usd
    from pxr import UsdLux
    from PIL import Image
    from isaacsim.core.api import World
    from isaacsim.core.api.objects import DynamicCuboid
    from isaacsim.sensors.camera import Camera
    out = Path('/workspace/grounded-forge-status/physics-rgb-smoke')
    out.mkdir(parents=True, exist_ok=True)
    world = World(stage_units_in_meters=1.0, physics_dt=1/60, rendering_dt=1/60)
    world.scene.add_default_ground_plane()
    cube = world.scene.add(DynamicCuboid(prim_path='/World/Cube', name='falling_cube', position=np.array([0.,0.,0.8]), size=0.1, color=np.array([0.9,0.1,0.1])))
    light = UsdLux.DomeLight.Define(omni.usd.get_context().get_stage(), '/World/Light')
    light.CreateIntensityAttr(1500.)
    camera = Camera(prim_path='/World/Camera', position=np.array([0.,0.,2.]), resolution=(640,480), frequency=30)
    camera.set_world_pose(position=np.array([0.,0.,2.]), orientation=np.array([1.,0.,0.,0.]), camera_axes='usd')
    world.reset()
    camera.initialize()
    start, _ = cube.get_world_pose()
    poses = []
    for tick in range(240):
        world.step(render=True)
        position, _ = cube.get_world_pose()
        poses.append(position.tolist())
    final, _ = cube.get_world_pose()
    rgba = camera.get_rgba()
    physics_ok = bool(np.isfinite(final).all() and start[2]-final[2] > 0.5 and 0.02 < final[2] < 0.15)
    rgb_ok = bool(rgba is not None and rgba.shape[:2] == (480,640) and np.isfinite(rgba).all() and np.std(rgba[...,:3]) > 1)
    if rgba is not None and rgba.size:
        Image.fromarray(rgba.astype(np.uint8)).save(out/'camera.png')
    np.save(out/'cube_positions.npy', np.asarray(poses))
    result = {'scope':'procedural cube gravity/contact and camera smoke check','isaac_version':'5.1.0','seed':0,'steps':240,'initial_position':start.tolist(),'final_position':final.tolist(),'physics_passed':physics_ok,'rgb_passed':rgb_ok}
    (out/'result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
    if not physics_ok or not rgb_ok:
        raise RuntimeError('Physics/RGB smoke check failed; inspect saved evidence.')
except BaseException:
    import traceback,sys
    traceback.print_exc()
    sys.stderr.flush()
    raise
finally:
    app.close()
