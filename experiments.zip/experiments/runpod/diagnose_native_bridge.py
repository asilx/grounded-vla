from pathlib import Path
import json
import isaacsim
from isaacsim.simulation_app import SimulationApp
app=SimulationApp({'headless':True})
for _ in range(3): app.update()
try:
 import numpy as np
 from PIL import Image
 from grounded_vla.backends.isaacsim import IsaacSimConfig,IsaacSimEnvironment
 from isaacsim.core.api import World
 original_world_step=World.step
 def rendered_world_step(self,*args,**kwargs):
  result=original_world_step(self,*args,**kwargs)
  if kwargs.get('render',True): app.update()
  return result
 World.step=rendered_world_step
 original_observe=IsaacSimEnvironment.observe
 diagnostic_calls=[0]
 def diagnosed_observe(self):
  try:
   return original_observe(self)
  except Exception as error:
   diagnostic_calls[0]+=1
   if diagnostic_calls[0] in [1,2,3,10,60,120]:
    print('CAMERA_DIAGNOSTIC',diagnostic_calls[0],float(self.world.current_time),repr(error),{name:{'keys':list(frame),'time':frame.get('rendering_time'),'shape':getattr(frame.get('rgba'),'shape',None)} for name,cam in self.cameras.items() for frame in [cam.get_current_frame()]},flush=True)
   raise
 IsaacSimEnvironment.observe=diagnosed_observe
 config=IsaacSimConfig.load('/workspace/grounded-vla/configs/runpod-franka-native.json')
 env=IsaacSimEnvironment.from_config(config)
 out=Path('/workspace/grounded-forge-status/native-bridge-check');out.mkdir(parents=True,exist_ok=True)
 obs=env.observe();times=[obs.timestamp];states=[obs.state.tolist()]
 for step in range(3):
  obs=env.step(obs.state)
  times.append(obs.timestamp);states.append(obs.state.tolist())
  for name,image in obs.images.items():Image.fromarray(image).save(out/f'{name}-{step:02d}.png')
 checks=[]
 for kind in ['joint_limit','joint_step']:
  if kind=='joint_step':obs=env.reset()
  before=float(env.world.current_time);state=env.robot.get_joint_positions().copy()
  target=obs.state.copy()
  if kind=='joint_limit':target[0]=config.upper_limits[0]+1
  else:target[0]+=2*config.max_joint_step[0]
  try:
   env.step(target);raise AssertionError('Invalid target unexpectedly executed')
  except ValueError as error:
   after=float(env.world.current_time)
   unchanged=np.array_equal(state,env.robot.get_joint_positions())
   assert before==after and unchanged
   checks.append({'kind':kind,'error':str(error),'physics_time_before':before,'physics_time_after':after,'joint_state_unchanged':bool(unchanged)})
 result={'scope':'native camera/state/action-guard integration; no learned policy','cameras':list(obs.images),'rgb_shapes':{k:list(v.shape) for k,v in obs.images.items()},'rgb_std':{k:float(v.std()) for k,v in obs.images.items()},'joint_count':len(obs.state),'timestamps':times,'state_history':states,'camera_freshness_passed':bool(np.all(np.diff(times)>0)),'rejections':checks}
 assert result['camera_freshness_passed'] and len(checks)==2
 (out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
except BaseException:
 import traceback;traceback.print_exc();raise
finally:app.close()
