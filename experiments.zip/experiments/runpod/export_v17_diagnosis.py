"""Package authoritative diagnostic evidence and the learned residual checkpoint."""
import base64,io,json,zipfile,hashlib,datetime
import numpy as np
from pathlib import Path
root=Path('/workspace/grounded-vla');status=Path('/workspace/grounded-forge-status');files=[]
for name in ['v17-input-command-diagnosis','franka-fk-fresh-audit','franka-fk-loaded-audit','teacher-command-prefix-audit','v17-observation-alias-audit','v17c-arm-calibration','v17c-physical-calibration','v17d-local-residual-fit','v17d-local-residual-checks','learned-baseline-v17d-audit','v17e-precision-repair','v17e-local-residual-checks','learned-baseline-v17e-audit','v18-local-field-fit','v18-local-field-checks','learned-baseline-v18-audit','v18-scope-metadata-correction']:
 for ext in ['.json','.log']:
  p=status/(name+ext)
  if p.exists():files.append((p,'evidence/'+p.name))
for pattern in ['learned-baseline-v17d-*.log','v17d-evaluation-coordinator.log','learned-baseline-v17e-*.log','v17e-evaluation-coordinator.log','learned-baseline-v18-*.log','v18-evaluation-coordinator.log','learned-baseline-v18-audit.original.json']:
 for p in status.glob(pattern):files.append((p,'evidence/'+p.name))
for name in ['diagnose_v17_io.py','audit_franka_fk.py','audit_teacher_command_prefix.py','audit_observation_alias_v17.py','calibrate_arm_head_v17c.py','calibrate_physical_head_v17c.py','local_residual_v17d.py','check_local_residual_v17d.py','evaluate_baseline_v17d.py','learned_directional_v17.py','evaluate_learned_recovery_v16_task.py','export_v17_diagnosis.py','repair_residual_precision_v17e.py','local_residual_v17e.py','check_local_residual_v17e.py','evaluate_baseline_v17e.py','learned_local_field_v18.py','check_local_field_v18.py','evaluate_baseline_v18.py','correct_v18_scope_metadata.py']:
 p=root/'experiments/runpod'/name
 if p.exists():files.append((p,'code/'+name))
for version in ['v17d','v17e','v18']:
 for p in (root/('runs/'+('learned-local-field-' if version=='v18' else 'learned-graph-baseline-')+version)).glob('*'):
  if p.is_file():files.append((p,'model/'+version+'/'+p.name))
for version in ['v17d','v17e','v18']:
 for p in (status/(('learned-local-field-' if version=='v18' else 'learned-graph-baseline-')+version+'-task')).glob('*/result*.json'):files.append((p,'physical/'+version+'/'+p.parent.name+'/'+p.name))
for version in ['v17d','v17e','v18']:
 for p in (status/(('learned-local-field-' if version=='v18' else 'learned-graph-baseline-')+version+'-task')).glob('*/trace.jsonl'):files.append((p,'physical/'+version+'/'+p.parent.name+'/trace.jsonl'))
for version in ['v17d','v17e','v18']:
 for p in (status/(('learned-local-field-' if version=='v18' else 'learned-graph-baseline-')+version+'-task')).glob('*/snapshots/*'):
  if p.is_file():files.append((p,'physical/'+version+'/'+p.parent.parent.name+'/snapshots/'+p.name))
readme='''Grounded Forge — measured diagnosis and V17D local residual experiment

Scope: numeric proprioception/geometric-KG learned control, not pi0/VLA.
MLP V17A and GRU V17B did not achieve pick/place success.
Teacher-command replay is a scripted diagnostic and cannot establish learned success.
Same-q fresh/loaded Franka FK matched the recorded teacher pose exactly.
Replay of the first600 teacher commands passed unchanged guards and matched teacher joint states with maximum arm-state L2 error3.44e-7 rad.
Offline vs streaming input/output parity: about2.4e-7 rad; recorded rollout command replay matched exactly.
Rounding-based observation audit found near identical observations with differing commands; not a proof of exact mathematical input equality.
Both frozen-output-head calibration variants failed the prespecified improvement/validation gates and were not evaluated physically.
V17D fits a learned local Gaussian-feature arm residual on seven training episodes. Baseline MLP/finger commands and bounded decoder unchanged.
Runtime artifacts contain learned feature centers and residual coefficients; no demonstration actions, teacher, reference trajectory index, future observations, or clock/phase lookup.
Heldout validation selects kernel width/ridge; the test split is untouched by fitting.
Batch/stream command parity, unchanged finger commands, bounds and episode reset checked.
Successful calibration is not physical task success. Only physical/*/result.json verified=true and task_success=true establishes task success for that seed.
Independent seed0 physical test triggers seeds1/2 and successful snapshot preservation only after seed0 success.
Full raw RGB rollout NPZ remains on the pod; its hash is recorded in the physical result.
V17E is a numerical precision ablation: same V17D-selected centers, width and ridge; reconstruct the exact fit preserving float64 kernel coefficients. See precision repair and independent checks.
V18 learns unordered local dynamical fields from training cluster statistics, with a fixed normal-contraction prior. It is a separate numeric imitation baseline, not an MLP/VLA success. It has no ordered waypoint sequence, phase clock or runtime teacher. See CURRENT_STATUS.json for the actual physical evaluation state at export.
GPU remains running per user instruction.
'''
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[]}
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('README.txt',readme)
 current={}
 for version in ['v17d','v17e','v18']:
  audit=status/('learned-baseline-'+version+'-audit.json')
  if audit.exists():
   d=json.loads(audit.read_text());current[version]={'status':d.get('status','running'),'attempts':[{'seed':a['seed'],'verified':a['result'].get('verified'),'task_success':a['result'].get('task_success'),'steps':a['result'].get('executed_steps')} for a in d['attempts']]}
 z.writestr('CURRENT_STATUS.json',json.dumps(current,indent=2))
 success=[]
 for p in (status/'learned-local-field-v18-task').glob('*/result.json'):
  d=json.loads(p.read_text())
  if d.get('verified') and d.get('task_success'):
   success.append(d)
   recording=p.parent/'learned-rollout.npz'
   with np.load(recording,allow_pickle=False) as raw:small={k:raw[k] for k in raw.files if not k.startswith('images/')}
   assert len(small['state'])==d['recorded_accepted_actions']==d['executed_steps']
   numeric=io.BytesIO();np.savez_compressed(numeric,**small);b=numeric.getvalue();name='physical/v18/'+p.parent.name+'/numeric-rollout.npz';z.writestr(name,b);manifest['files'].append({'name':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'source_full_rgb_recording_sha256':d['rollout_recording_sha256'],'omitted_fields':'images/*; actual camera timestamps/freshness retained'})
 success.sort(key=lambda d:d['seed'])
 summary='# Grounded Forge — verified learned control results'+chr(10)*2
 summary+='V18 is a learned local dynamical-field numeric imitation controller. It uses current joint positions and simulator-oracle cargo/goal geometry. RGB/language, MLP and pi0/VLA success, semantic graph-adapter causality, broad generalization and real-robot performance are not established by this experiment.'+chr(10)*2
 summary+='| Seed | Verified physical success | Accepted actions | Peak cube height (m) | Destination XY error (mm) | Stable release steps |'+chr(10)+'|---|---|---|---|---|---|'+chr(10)
 for d in success:summary+=f"| {d['seed']} | {d['verified'] and d['task_success']} | {d['executed_steps']} | {d['peak_height_m']:.6f} | {d['planar_error_m']*1000:.3f} | {d['stable_steps']} |"+chr(10)
 summary+=chr(10)+'The success criterion was unchanged: lift above initial height by >70 mm, XY destination error <40 mm, vertical error <30 mm, separated/open gripper, and 120 consecutive stable physics steps. Actions passed the existing native joint and per-step guards. Intrinsic command bounds and a fixed normal-contraction prior are architectural constraints, not learned safety guarantees.'+chr(10)*2
 summary+='The three seeds perturb the requested destination XY by at most15 mm per axis. Cube/robot initial conditions are otherwise fixed. These are narrow repeatability checks, not broad randomized-state generalization tests. Training comprised seven scripted successful demonstrations (seed0 plus recovery3–8); validation used original seed1 and original seed2 was not used for fitting.'+chr(10)*2
 summary+='The package includes actual camera snapshots at initial, lift, transport, release and final success, plus state/time records; full accepted state/action/graph numeric rollouts; model parameters and code; earlier failed V17D/E results and simulator parity diagnostics. Full RGB rollout NPZs remain on the pod and their SHA256 identifiers are in each result. No pi0 transfer or semantic intervention has yet run.'+chr(10)*2
 summary+='Metadata erratum: the reusable evaluator initially inherited a human-readable MLP scope label. The recorded policy_metadata and field checkpoint always identified the actual learned local-field controller. Only the scope string was corrected after evaluation; all physical measurements/flags were preserved exactly. Original result JSONs and the scope-correction audit are included.'+chr(10)
 z.writestr('RESULTS.md',summary)
 for p,name in files:
  b=p.read_bytes();z.writestr(name,b);manifest['files'].append({'name':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
(status/'V17_DIAGNOSIS_EXPORT.txt').write_text(base64.b64encode(buf.getvalue()).decode())
print('DIAGNOSIS_EXPORT',len(buf.getvalue()),len(files),hashlib.sha256(buf.getvalue()).hexdigest(),flush=True)
