#!/usr/bin/env bash
set -euo pipefail
if [[ ${OMNI_KIT_ACCEPT_EULA:-} != YES ]]; then
  echo 'Isaac installation paused: explicit NVIDIA EULA approval required.' >&2
  exit 2
fi
export UV_CACHE_DIR=/workspace/uv-cache
uv pip install --python /workspace/isaac-env/bin/python 'isaacsim[all,extscache]==5.1.0' --extra-index-url https://pypi.nvidia.com
uv pip install --python /workspace/isaac-env/bin/python --no-deps -r /workspace/grounded-vla/requirements-simulation.txt
uv pip freeze --python /workspace/isaac-env/bin/python > /workspace/grounded-forge-status/installed-packages.txt
