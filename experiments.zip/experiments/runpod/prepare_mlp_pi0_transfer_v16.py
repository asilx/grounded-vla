"""Gate transfer data on three physically successful independent learned rollouts."""
import copy,hashlib,json,os
from pathlib import Path
import numpy as np
from grounded_vla.training.data import load_prepared,prepare_dataset
from grounded_vla.training.velocity_graph import velocity_schema
from grounded_vla.backends.isaacsim import IsaacSimConfig
ROOT=Path('/workspace/grounded-vla');STATUS=Path('/workspace/grounded-forge-status')
a=json.loads((STATUS/'learned-baseline-v16-audit.json').read_text());assert a['status']=='completed'
entries=[]
for seed in (0,1,2):
 matches=[e for e in a['attempts'] if e['seed']==seed and e['result'].get('verified') and e['result'].get('task_success')]
 assert len(matches)==1, 'No uniquely verified learned success for seed '+str(seed)
 e=matches[0];p=Path(e['output'])/'learned-rollout.npz';assert p.exists()
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==e['result']['rollout_recording_sha256']
 with np.load(p,allow_pickle=False) as d:
  assert len(d['state'])==e['result']['recorded_accepted_actions']
  ages=d['timestamps'][:,None]-d['capture_timestamps'];assert np.all(ages>=-1e-6) and np.all(ages<=.05)
 entries.append((seed,p,e))
source=ROOT/'data/franka-recovery-v16/prepared.json';meta=load_prepared(source)
out=ROOT/'data/franka-mlp-pi0-transfer-v16';out.mkdir(exist_ok=False)
manifest=copy.deepcopy(meta);manifest.pop('normalization');manifest.pop('normalization_split')
manifest['episodes']=[dict(e,path=os.path.relpath((source.parent/e['path']).resolve(),out)) for e in meta['episodes'] if e['split']=='train']
for seed,p,e in entries:
 manifest['episodes'].append(dict(id=f'verified-learned-mlp-v16-{seed}',path=os.path.relpath(p,out),split=('train','val','test')[seed]))
manifest['learned_transfer_provenance']=[dict(seed=seed,source=str(p),sha256=e['result']['rollout_recording_sha256'],physical_result=e['result']) for seed,p,e in entries]
c=IsaacSimConfig.load(ROOT/'configs/runpod-franka-guarded.json')
source_schema=manifest['graph_schema']['id'];manifest['graph_schema']=velocity_schema(manifest['graph_schema'],list(c.joint_names))
manifest['proprio_velocity_graph']=dict(source_schema_id=source_schema,robot_node_index=2,node_order=['cargo','goal','gripper'],ordered_joint_names=list(c.joint_names),method='causal backward difference; first frame zero')
old=load_prepared(ROOT/'data/franka-velocity-v14/prepared.json');assert manifest['graph_schema']==old['graph_schema']
(out/'manifest.json').write_text(json.dumps(manifest,indent=2));prepare_dataset(out/'manifest.json',out/'prepared.json')
config=json.loads((ROOT/'configs/runpod-pi0-velocity.json').read_text());config.update(dataset='../data/franka-mlp-pi0-transfer-v16/prepared.json',output_dir='../runs/franka-pi0-mlp-transfer-v16',steps=2000,save_every=1000,eval_every=1000)
(ROOT/'configs/runpod-pi0-mlp-transfer-v16.json').write_text(json.dumps(config,indent=2))
print('VERIFIED_MLP_PI0_TRANSFER_DATA_READY',flush=True)
