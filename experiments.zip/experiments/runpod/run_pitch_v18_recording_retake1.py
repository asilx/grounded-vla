"""Finite verified live recording of the learned V18 policy."""
import datetime,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/grounded-vla');STATUS=Path('/workspace/grounded-forge-status');os.chdir(ROOT)
AUDIT=STATUS/'pitch-v18-recording-retake1-audit.json';assert not AUDIT.exists()
state={'status':'starting','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'New live learned-controller documentary recording, not action replay','checkpoint':'runs/learned-local-field-v18'}
def save():AUDIT.write_text(json.dumps(state,indent=2))
env=dict(os.environ,PYTHONPATH='src:experiments/runpod',OPENPI_SOURCE='/workspace/support/openpi-source',JAX_PLATFORMS='cpu',TOKENIZERS_PARALLELISM='false',OMNI_KIT_ACCEPT_EULA='YES',OMNI_KIT_ALLOW_ROOT='1')
server=None
try:
 save();log=(STATUS/'pitch-v18-server.log').open('w');server=subprocess.Popen(['/workspace/pi0-train-env/bin/python','-u','experiments/runpod/learned_local_field_v18.py','serve','--port','8014'],env=env,stdout=log,stderr=subprocess.STDOUT)
 from grounded_vla.backends.openpi import OpenPiTransport
 deadline=time.monotonic()+120
 while True:
  if server.poll() is not None:raise RuntimeError('Recording policy server exited')
  try:
   with OpenPiTransport('ws://127.0.0.1:8014',timeout=2) as c:
    assert c.metadata['policy']=='learned-local-contracting-field';assert c.metadata['weights_sha256']==json.loads((ROOT/'runs/learned-local-field-v18/metadata.json').read_text())['weights_sha256']
   break
  except Exception:
   if time.monotonic()>deadline:raise TimeoutError('Recording server readiness')
   time.sleep(1)
 state['status']='recording';save();out=STATUS/'learned-v18-pitch-recording'/'seed-0-retake-1'
 with (STATUS/'pitch-v18-sdk.log').open('w') as l:
  code=subprocess.run(['/workspace/isaac6-env/bin/python','-u','experiments/runpod/record_pitch_v18_task.py','--seed','0','--execute-steps','1','--uri','ws://127.0.0.1:8014','--out',str(out)],env=env,stdout=l,stderr=subprocess.STDOUT,timeout=3000).returncode
 d=json.loads((out/'result.json').read_text());state.update(status='completed',process_exit=code,result=d,verified_success=bool(d.get('verified') and d.get('task_success')))
except BaseException as e:state.update(status='error',error_type=type(e).__name__,error=str(e));raise
finally:
 if server is not None:
  server.terminate()
  try:server.wait(timeout=15)
  except subprocess.TimeoutExpired:server.kill();server.wait()
 state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(state),flush=True)
