"""Frozen-feature arm-only ridge calibration; no runtime teacher or trajectory lookup."""
import copy,json,hashlib
from pathlib import Path
import numpy as np
import torch
from safetensors.torch import load_file,save_file
from learned_directional_v17 import Actor,read_numeric,physical_targets

def main():
 torch.set_num_threads(4)
 root=Path('/workspace/grounded-vla'); cp=root/'runs/learned-graph-baseline-v17'; out=root/'runs/learned-graph-baseline-v17c'
 assert not out.exists()
 md=json.loads((cp/'metadata.json').read_text()); meta=md['dataset']; prepared=Path('/workspace/data/franka-recovery-v16/prepared.json')
 if not prepared.exists(): prepared=Path('/workspace/grounded-vla/data/franka-recovery-v16/prepared.json')
 # Resolve the prepared data path from the established experiment location.
 if not prepared.exists(): prepared=next(Path('/workspace').glob('**/franka-recovery-v16/prepared.json'))
 model=Actor(md['input_dim'],meta['action_dim'],md['width']); original=load_file(str(cp/'actor.safetensors')); model.load_state_dict(original);model.eval()
 assert hashlib.file_digest((cp/'actor.safetensors').open('rb'),'sha256').hexdigest()==md['weights_sha256']
 arrays={s:read_numeric(prepared,meta,s,md['history_steps']) for s in ['train','val']}
 features={}; base={}
 with torch.no_grad():
  for s,(x,y,q,a) in arrays.items():
   xt=torch.from_numpy((x-np.array(md['input_mean'],np.float32))/np.array(md['input_std'],np.float32))
   features[s]=torch.cat([model.network[:-1](xt).double(),torch.ones(len(x),1,dtype=torch.float64)],1)
   pred=model(xt); base[s]=pred
 def score(s,pred):
  q=torch.from_numpy(arrays[s][2]);a=torch.from_numpy(arrays[s][3]); delta=physical_targets(pred.float(),q,meta)-a
  err=torch.linalg.vector_norm(delta[:,:7],dim=1)
  return {'mean_arm_error_rad':err.mean().item(),'first32_arm_error_rad':err[:32].mean().item(),'first_arm_error_rad':err[0].item()}
 before={s:score(s,base[s]) for s in arrays}; print('BEFORE',before,flush=True)
 h=features['train']; residual=torch.from_numpy(arrays['train'][1][:,:7]).double()-base['train'][:,:7].double()
 weight=torch.ones(len(h),dtype=torch.float64)
 # Each episode startup receives extra weight, using training boundaries only.
 offset=0
 for e in meta['episodes']:
  if e['split']!='train':continue
  with np.load(prepared.parent/e['path'],allow_pickle=False) as z:n=len(z['state'])
  weight[offset:offset+min(n,64)]=20;offset+=n
 assert offset==len(h)
 old=torch.cat([original['network.6.weight'][:7].double().T,original['network.6.bias'][:7].double()[None]],0)
 candidates=[]; best=None
 for lam in [.01,.1,1.,10.]:
  correction=torch.linalg.solve(h.T@(weight[:,None]*h)+lam*torch.eye(h.shape[1],dtype=torch.float64),h.T@(weight[:,None]*residual))
  head=old+correction; scores={}
  for s in arrays:
   pred=base[s].clone();pred[:,:7]=(features[s]@head).float();scores[s]=score(s,pred)
  gate=scores['train']['first_arm_error_rad']<=before['train']['first_arm_error_rad']/5 and scores['val']['mean_arm_error_rad']<=before['val']['mean_arm_error_rad']*1.05
  record={'ridge':lam,'scores':scores,'eligible':gate};candidates.append(record);print(json.dumps(record),flush=True)
  if gate and (best is None or scores['val']['mean_arm_error_rad']<best[0]):best=(scores['val']['mean_arm_error_rad'],head,record)
 report={'scope':'arm output head only; frozen MLP body and unchanged finger output; no physical success claim','before':before,'candidates':candidates,'selected':None if best is None else best[2]}
 Path('/workspace/grounded-forge-status/v17c-arm-calibration.json').write_text(json.dumps(report,indent=2))
 if best is None:print('CALIBRATION_GATE_FAILED',flush=True);return
 weights=copy.deepcopy(original);weights['network.6.weight'][:7]=best[1][:-1].T.float();weights['network.6.bias'][:7]=best[1][-1].float()
 assert torch.equal(weights['network.6.weight'][7:],original['network.6.weight'][7:]);assert torch.equal(weights['network.6.bias'][7:],original['network.6.bias'][7:])
 out.mkdir();save_file(weights,str(out/'actor.safetensors'));md['warm_start']=md['weights_sha256'];md['weights_sha256']=hashlib.file_digest((out/'actor.safetensors').open('rb'),'sha256').hexdigest();md['scope']=report['scope'];md['calibration']=best[2];md['selection']='validation mean arm error after startup improvement gate; test untouched';(out/'metadata.json').write_text(json.dumps(md,indent=2));(out/'metrics.json').write_text(json.dumps(report,indent=2));print('CALIBRATION_SAVED',out,flush=True)
if __name__=='__main__':main()
