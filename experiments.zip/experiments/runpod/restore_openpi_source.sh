#!/usr/bin/env bash
set -euo pipefail
repo=/workspace/support/openpi-source
if [ ! -d "$repo/.git" ]; then git clone https://github.com/Physical-Intelligence/openpi.git "$repo"; fi
git -C "$repo" checkout --detach 215abfb217dbac7d5f1273282331b9b1866c0479
git -C "$repo" rev-parse HEAD
