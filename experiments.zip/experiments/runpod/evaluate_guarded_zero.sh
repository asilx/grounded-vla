#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
for i in $(seq 1 1800); do
  if [ -f "$status/guarded-v7-training-2000.exit" ]; then break; fi
  sleep 2
done
[ "$(cat "$status/guarded-v7-training-2000.exit")" = 0 ]
JAX_PLATFORMS=cpu TOKENIZERS_PARALLELISM=false timeout 3600 \
 /workspace/pi0-train-env/bin/grounded-vla-serve runs/franka-pi0-guarded-v7/step-00002000 \
 --host 127.0.0.1 --port 8000 --device cuda --num-steps 10 --inference-seed 37 --zero-noise \
 > "$status/guarded-2000-zero-task-20261013-server.log" 2>&1 &
server_pid=$!
echo "$server_pid" > "$status/guarded-2000-zero-task-20261013-server.pid"
trap 'kill "$server_pid" 2>/dev/null || true' EXIT
/workspace/pi0-train-env/bin/python - <<'PY'
import time
from grounded_vla.backends.openpi import OpenPiTransport
for i in range(240):
    try:
        with OpenPiTransport('ws://127.0.0.1:8000',timeout=1.) as c:
            assert c.metadata['checkpoint_step']==2000 and c.metadata['robot_interface_adaptation']
        print('GUARDED_2000_ZERO_POLICY_READY',flush=True)
        break
    except Exception:time.sleep(1)
else:raise TimeoutError('Model did not become ready')
PY
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1
for seed in 0 1 2; do
 timeout 1200 /workspace/isaac6-env/bin/python -u experiments/runpod/evaluate_pi0_task.py \
   --seed "$seed" --execute-steps 3 --out "$status/guarded-2000-zero-task-20261013/seed-$seed" \
   > "$status/guarded-2000-zero-task-20261013-seed-$seed.log" 2>&1
done
python3 - <<'PY'
import json
from pathlib import Path
root=Path('/workspace/grounded-forge-status/guarded-2000-zero-task-20261013')
rows=[json.loads((root/f'seed-{i}'/'result.json').read_text()) for i in range(3)]
valid=[r for r in rows if r.get('verified')]
summary={'scope':'Three closed-loop learned-policy task trials; matched procedural scene; ideal robot gravity compensation; no policy-output clipping',
 'episodes':rows,'valid_trials':len(valid),'attempts':3,'invalid_trials':3-len(valid),
 'successes':sum(r['task_success'] for r in valid)}
(root/'summary.json').write_text(json.dumps(summary,indent=2))
print('GUARDED_2000_ZERO_LEARNED_SUCCESS',summary['successes'],summary['valid_trials'],flush=True)
assert summary['invalid_trials']==0
PY
