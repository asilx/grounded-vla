"""Learned numeric-control baseline; deliberately no RGB/language/VLA claim."""
import argparse
from collections import deque
import copy
import hashlib
import json
from pathlib import Path

import numpy as np
import torch
from torch import nn
from safetensors.torch import load_file, save_file
from grounded_vla.training.data import load_prepared, encode_action_chunk, decode_action_chunk


def numeric_inputs(states, features, edges, valid, relations):
    states, features = np.asarray(states, np.float32), np.asarray(features, np.float32)
    edges, valid = np.asarray(edges), np.asarray(valid)
    if states.ndim != 2 or features.ndim != 3 or states.shape[0] != features.shape[0]:
        raise ValueError('Invalid batched state/graph dimensions')
    b, n, _ = features.shape
    if edges.shape != (b,n,n) or valid.shape != (b,n) or edges.dtype != np.int64 or valid.dtype != np.bool_:
        raise ValueError('Invalid graph edges/validity')
    if not np.isfinite(states).all() or not np.isfinite(features).all():
        raise ValueError('Non-finite state/graph')
    if edges.size and (edges.min() < 0 or edges.max() >= relations):
        raise ValueError('Unknown graph relation')
    visible_features = features * valid[:,:,None]
    onehot = np.eye(relations, dtype=np.float32)[edges]
    onehot *= (valid[:,:,None] & valid[:,None,:])[:,:,:,None]
    return np.concatenate([states, visible_features.reshape(b,-1), onehot.reshape(b,-1), valid.astype(np.float32)], axis=1)


class Actor(nn.Module):
    def __init__(self, input_dim, action_dim, width=256):
        super().__init__()
        self.network = nn.Sequential(nn.Linear(input_dim,width), nn.SiLU(),
                                     nn.Linear(width,width), nn.SiLU(),
                                     nn.Linear(width,width), nn.SiLU(),
                                     nn.Linear(width,action_dim))

    def forward(self, x):
        return self.network(x)


def causal_state_features(states, history, period):
    states=np.asarray(states,np.float32)
    if states.ndim!=2 or not 1<=history<=8 or not np.isfinite(period) or period<=0:
        raise ValueError('Invalid causal state history')
    positions=np.arange(len(states))
    windows=np.stack([states[np.maximum(positions-lag,0)] for lag in range(history)],axis=1)
    velocities=(windows[:,:-1]-windows[:,1:])/period
    return np.concatenate([states,velocities.reshape(len(states),-1)],axis=1)


def read_numeric(prepared, meta, split, history=1):
    xs, ys, qs, targets = [], [], [], []
    entries = [e for e in meta['episodes'] if e['split'] == split]
    for entry in entries:
        with np.load(prepared.parent/entry['path'], allow_pickle=False) as z:
            q = z['state'].copy(); a = z['actions'].copy()
            context=causal_state_features(q,history,meta['control_period_seconds'])
            x = numeric_inputs(context,z['graph_features'],z['graph_edges'],z['graph_valid'],len(meta['graph_schema']['relations']))
        encoded = np.stack([encode_action_chunk(a[i:i+1],q[i],meta)[0] for i in range(len(q))])
        norm = meta['normalization']['action']
        y = (encoded-np.asarray(norm['mean'],np.float32))/np.asarray(norm['std'],np.float32)
        xs.append(x); ys.append(y); qs.append(q); targets.append(a)
    if not xs:
        raise ValueError('Empty requested split')
    return tuple(np.concatenate(arrays).astype(np.float32) for arrays in (xs,ys,qs,targets))


def physical_targets(prediction, states, meta):
    stats = meta['normalization']['action']
    logits = prediction * prediction.new_tensor(stats['std']) + prediction.new_tensor(stats['mean'])
    step = prediction.new_tensor(meta['encoding_max_joint_step']) * .9999
    lower = torch.maximum(prediction.new_tensor(meta['encoding_lower_limits']), states-step)
    upper = torch.minimum(prediction.new_tensor(meta['encoding_upper_limits']), states+step)
    return lower+(upper-lower)*torch.sigmoid(logits)


def train(prepared, out, steps=2000, history=4):
    torch.set_num_threads(4); torch.manual_seed(31)
    prepared, out = Path(prepared).resolve(), Path(out).resolve()
    if out.exists():
        raise FileExistsError(out)
    meta = load_prepared(prepared)
    if meta['action_encoding'] != 'bounded_joint_interval_logits' or meta['action_encoding_horizon'] != 1:
        raise ValueError('Baseline requires the existing bounded H1 action contract')
    tx,ty,tq,ta = read_numeric(prepared,meta,'train',history)
    vx,vy,vq,va = read_numeric(prepared,meta,'val',history)
    mean, std = tx.mean(0), np.maximum(tx.std(0),.1)
    tx, vx = (tx-mean)/std, (vx-mean)/std
    tx,ty,tq,ta,vx,vy,vq,va = [torch.from_numpy(x) for x in (tx,ty,tq,ta,vx,vy,vq,va)]
    model = Actor(tx.shape[1],ty.shape[1]); optimizer = torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-4)
    cp=Path('/workspace/grounded-vla/runs/learned-graph-baseline-v13')
    prior=json.loads((cp/'metadata.json').read_text());assert prior['history_steps']==history
    assert hashlib.file_digest((cp/'actor.safetensors').open('rb'),'sha256').hexdigest()==prior['weights_sha256']
    weights=load_file(str(cp/'actor.safetensors'))
    oldmean=torch.tensor(prior['input_mean']);oldstd=torch.tensor(prior['input_std'])
    w=weights['network.0.weight'].clone()
    weights['network.0.bias']+=w@((torch.from_numpy(mean)-oldmean)/oldstd)
    weights['network.0.weight']=w*(torch.from_numpy(std)/oldstd)[None,:]
    old=prior['dataset']['normalization']['action'];new=meta['normalization']['action']
    ratio=torch.tensor(old['std'])/torch.tensor(new['std'])
    weights['network.6.weight']*=ratio[:,None]
    weights['network.6.bias']=weights['network.6.bias']*ratio+(torch.tensor(old['mean'])-torch.tensor(new['mean']))/torch.tensor(new['std'])
    model.load_state_dict(weights,strict=True)
    # Verify normalization conversion preserves the source model before adaptation.
    original_model=Actor(tx.shape[1],ty.shape[1])
    original_model.load_state_dict(load_file(str(cp/'actor.safetensors')),strict=True)
    with torch.no_grad():
        actual=tx[:32]*torch.from_numpy(std)+torch.from_numpy(mean)
        prior_output=original_model((actual-oldmean)/oldstd)
        converted_expected=prior_output*ratio+(torch.tensor(old['mean'])-torch.tensor(new['mean']))/torch.tensor(new['std'])
        torch.testing.assert_close(model(tx[:32]),converted_expected,rtol=1e-4,atol=1e-4)
    print('V17_NORMALIZATION_WARMSTART_PARITY_PASSED',flush=True)
    out.mkdir(parents=True); metrics=[]; best=float('inf'); best_state=None; best_step=0
    scale = ty.new_tensor(meta['encoding_max_joint_step'])
    from gripper_direction_v17 import direction_labels
    labels=torch.from_numpy(direction_labels(tq.numpy(),ta.numpy()))
    groups=[torch.where(labels==k)[0] for k in range(3)]
    assert all(len(g)>0 for g in groups)
    print('V17_DIRECTION_GROUPS_HOLD_OPEN_CLOSE',[len(g) for g in groups],flush=True)
    for step in range(1,steps+1):
        indices = torch.cat([g[torch.randint(len(g),(n,))] for g,n in zip(groups,(84,86,86))]); pred=model(tx[indices])
        loss = ((pred-ty[indices])**2).mean()+20*(((physical_targets(pred,tq[indices],meta)-ta[indices])/scale)**2).mean()
        if not torch.isfinite(loss):
            raise FloatingPointError('Non-finite baseline training loss')
        optimizer.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True); optimizer.step()
        if step%200 == 0 or step == steps:
            with torch.no_grad():
                val=model(vx); decoded=physical_targets(val,vq,meta)
                error=torch.linalg.vector_norm(decoded[:,:7]-va[:,:7],dim=-1).mean().item()
                val_loss=((val-vy)**2).mean().item()
            record=dict(step=step,train_loss=loss.item(),val_logit_mse=val_loss,val_mean_arm_command_error_rad=error)
            metrics.append(record); print(json.dumps(record),flush=True)
            if error < best:
                best=error; best_state=copy.deepcopy(model.state_dict()); best_step=step
    if best_state is None:
        raise RuntimeError('No validated baseline checkpoint')
    save_file(best_state,str(out/'actor.safetensors'))
    metadata=dict(dataset=meta,input_dim=tx.shape[1],nodes=3,width=256,history_steps=history,input_mean=mean.tolist(),input_std=std.tolist(),
                  selected_step=best_step,training_steps=steps,selection='minimum validation mean arm command error; test split untouched',
                  dataset_sha256=hashlib.file_digest(prepared.open('rb'),'sha256').hexdigest(),
                  train_episodes=[e['id'] for e in meta['episodes'] if e['split']=='train'],
                  val_episodes=[e['id'] for e in meta['episodes'] if e['split']=='val'],
                  scope='V17A controlled ablation: V16 dataset and MLP architecture with hold/open/close balanced sampling based on action minus observed gripper position; no RGB/language/VLA, no teacher or waypoints at inference',warm_start=prior['weights_sha256'])
    metadata['weights_sha256']=hashlib.file_digest((out/'actor.safetensors').open('rb'),'sha256').hexdigest()
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2))
    (out/'metrics.json').write_text(json.dumps(metrics,indent=2))
    print('LEARNED_BASELINE_SAVED',str(out),best_step,best,flush=True)


class BaselinePolicy:
    def __init__(self, checkpoint):
        torch.set_num_threads(2)
        cp=Path(checkpoint); self.artifact=json.loads((cp/'metadata.json').read_text()); self.meta=self.artifact['dataset']
        if hashlib.file_digest((cp/'actor.safetensors').open('rb'),'sha256').hexdigest()!=self.artifact['weights_sha256']:
            raise ValueError('Baseline checkpoint identity mismatch')
        self.actor=Actor(self.artifact['input_dim'],self.meta['action_dim'],self.artifact['width'])
        self.actor.load_state_dict(load_file(str(cp/'actor.safetensors')),strict=True); self.actor.eval()
        self.history=self.artifact.get('history_steps',1)
        self.reset()
        self.metadata=dict(policy='learned-proprio-geometric-graph-mlp-baseline',uses_rgb=False,uses_language=False,
                           scope=self.artifact['scope'],weights_sha256=self.artifact['weights_sha256'],
                           checkpoint_step=self.artifact['selected_step'],history_steps=self.history,input_preset='canonical',graph_required=True,
                           state_dim=self.meta['state_dim'],action_dim=self.meta['action_dim'],action_horizon=1,
                           action_encoding=self.meta['action_encoding'],action_convention=self.meta['action_convention'],
                           control_period_seconds=self.meta['control_period_seconds'],graph_schema_id=self.meta['graph_schema']['id'],
                           graph_feature_dim=len(self.meta['graph_schema']['features']),graph_relation_types=len(self.meta['graph_schema']['relations']))

    def reset(self):
        self.states=deque(maxlen=self.history)

    @torch.no_grad()
    def infer(self, payload):
        state=np.asarray(payload['state'],np.float32)
        if state.shape!=(self.meta['state_dim'],):
            raise ValueError('Wrong baseline joint-state dimensions')
        graph=payload['graph']
        if graph['schema_id']!=self.metadata['graph_schema_id']:
            raise ValueError('Baseline graph schema mismatch')
        f,e,v=np.asarray(graph['features']),np.asarray(graph['edges']),np.asarray(graph['valid'])
        if f.shape!=(self.artifact['nodes'],self.metadata['graph_feature_dim']):
            raise ValueError('Baseline graph node count/feature dimensions mismatch')
        self.states.append(state.copy())
        context=causal_state_features(np.stack(self.states),self.history,self.meta['control_period_seconds'])[-1:]
        x=numeric_inputs(context,f[None],e[None],v[None],self.metadata['graph_relation_types'])
        x=(x-np.asarray(self.artifact['input_mean'],np.float32))/np.asarray(self.artifact['input_std'],np.float32)
        prediction=self.actor(torch.from_numpy(x)).numpy()
        stats=self.meta['normalization']['action']
        logits=prediction*np.asarray(stats['std'],np.float32)+np.asarray(stats['mean'],np.float32)
        actions=decode_action_chunk(logits,state,self.meta)
        if not np.isfinite(actions).all():
            raise FloatingPointError('Non-finite learned baseline command')
        return {'actions':actions}


def main():
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='command',required=True)
    t=sub.add_parser('train');t.add_argument('prepared');t.add_argument('out');t.add_argument('--steps',type=int,default=4000);t.add_argument('--history',type=int,default=1)
    s=sub.add_parser('serve');s.add_argument('checkpoint');s.add_argument('--port',type=int,default=8002)
    args=p.parse_args()
    if args.command=='train':
        train(args.prepared,args.out,args.steps,args.history)
    else:
        from openpi.serving.websocket_policy_server import WebsocketPolicyServer
        class EpisodeServer(WebsocketPolicyServer):
            active=False
            async def _handler(self, websocket):
                if self.active:
                    await websocket.close(code=1013,reason='One episode connection at a time')
                    return
                self.active=True
                self._policy.reset()
                try:
                    await super()._handler(websocket)
                finally:
                    self.active=False
        policy=BaselinePolicy(args.checkpoint)
        EpisodeServer(policy,host='127.0.0.1',port=args.port,metadata=policy.metadata).serve_forever()


if __name__=='__main__':
    main()
