from pathlib import Path
import json, os
import numpy as np
from grounded_vla.training.data import prepare_dataset, load_prepared

root = Path('/workspace/grounded-vla')
original = root / 'data/franka-guarded-v7/prepared.json'
meta = load_prepared(original)
out = root / 'data/franka-relative-v8'
out.mkdir(parents=True, exist_ok=True)
assert not (out/'prepared.json').exists()
meta.pop('normalization'); meta.pop('normalization_split')
meta['action_encoding'] = 'relative_to_observed_joint_positions'
meta['action_encoding_horizon'] = 1
for entry in meta['episodes']:
    entry['path'] = os.path.relpath((original.parent/entry['path']).resolve(), out)
(out/'manifest.json').write_text(json.dumps(meta, indent=2))
prepared = prepare_dataset(out/'manifest.json', out/'prepared.json')
train = [e for e in prepared['episodes'] if e['split']=='train']
assert len(train)==1
with np.load(out/train[0]['path'], allow_pickle=False) as z:
    delta = z['actions'].astype(np.float64)-z['state'].astype(np.float64)
np.testing.assert_allclose(prepared['normalization']['action']['mean'],delta.mean(0),atol=1e-7)
np.testing.assert_allclose(prepared['normalization']['action']['std'],np.sqrt(np.maximum(delta.var(0),1e-12)),atol=1e-7)
config=json.loads((root/'configs/runpod-pi0-guarded.json').read_text())
config.update(dataset='../data/franka-relative-v8/prepared.json',output_dir='../runs/franka-pi0-relative-v8',action_horizon=1,steps=4000,eval_every=250,save_every=250)
config['adapter']['initial_gate']=0.05
(root/'configs/runpod-pi0-relative.json').write_text(json.dumps(config,indent=2))
print('RELATIVE_DATA_PREPARED',prepared['normalization']['action'],flush=True)
