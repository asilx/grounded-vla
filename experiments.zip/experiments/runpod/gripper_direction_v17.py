"""Training-only gripper command labels; absolute aperture is not control direction."""
import numpy as np
HOLD,OPEN,CLOSE=0,1,2

def direction_labels(states,actions,threshold=.0005):
    q=np.asarray(states);a=np.asarray(actions)
    if q.shape!=a.shape or q.ndim!=2 or q.shape[1]!=9 or not np.isfinite(q).all() or not np.isfinite(a).all() or threshold<=0:
        raise ValueError('Invalid physical state/action arrays')
    delta=(a[:,7:]-q[:,7:]).mean(1)
    labels=np.full(len(q),HOLD,np.int64)
    labels[delta>threshold]=OPEN;labels[delta<-threshold]=CLOSE
    return labels
