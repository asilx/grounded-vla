#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
trap 'echo $? > "$status/recovery-v16-pipeline.exit"' EXIT
/workspace/pi0-train-env/bin/python -u experiments/runpod/select_recovery_v16.py
bash experiments/runpod/collect_recovery_v16.sh
/workspace/pi0-train-env/bin/python -u experiments/runpod/prepare_recovery_v16.py
set +e
/workspace/pi0-train-env/bin/python -u experiments/runpod/learned_recovery_v16.py train data/franka-recovery-v16/prepared.json runs/learned-graph-baseline-v16 --steps 2000 --history 4
train_exit=$?
echo "$train_exit" > "$status/learned-baseline-v16-train.exit"
set -e
test "$train_exit" = 0
/workspace/pi0-train-env/bin/python -u experiments/runpod/evaluate_baseline_v16.py
