#!/usr/bin/env bash
set -u
status=/workspace/grounded-forge-status
for attempt in $(seq 1 90); do [ -f "$status/transfer-result.json" ] && break; sleep 5; done
[ -f "$status/transfer-result.json" ] || exit 2
export OMNI_KIT_ACCEPT_EULA=YES
export OMNI_KIT_ALLOW_ROOT=1
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4
export PYTHONUNBUFFERED=1
cd /workspace/grounded-vla
/workspace/isaac6-env/bin/python -c 'import importlib.metadata as m; print({p:m.version(p) for p in ["isaacsim","torch","torchvision","numpy","openpi-client"]})' > "$status/runtime-versions.txt" 2>&1
timeout 900 /workspace/isaac6-env/bin/python -m pytest -q > "$status/integration-tests-resume.log" 2>&1
echo $? > "$status/integration-tests-resume.exit"
timeout 900 /workspace/isaac6-env/bin/python experiments/runpod/physics_rgb_smoke.py > "$status/physics-rgb-smoke.log" 2>&1
echo $? > "$status/physics-rgb-smoke.exit"
