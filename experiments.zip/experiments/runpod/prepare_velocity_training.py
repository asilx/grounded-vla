"""Extend recorded KG inputs with backward-difference motor velocities, preserving raw data."""
from pathlib import Path
import copy
import json
import os
import shutil
from safetensors.torch import load_file,save_file
from grounded_vla.backends.isaacsim import IsaacSimConfig
from grounded_vla.training.data import load_prepared,prepare_dataset
from grounded_vla.training.graph import SCHEMA_ID
from grounded_vla.training.velocity_graph import velocity_schema,extend_adapter_weights
from grounded_vla.training.runtime import sha256
from grounded_vla.training.config import TrainConfig

root=Path('/workspace/grounded-vla');status=Path('/workspace/grounded-forge-status')
assert int((status/'recovery-long-v11-train-6000.exit').read_text())==0
source=root/'data/franka-recovery-v10/prepared.json';meta=load_prepared(source)
config=IsaacSimConfig.load(root/'configs/runpod-franka-guarded.json')
out=root/'data/franka-velocity-v14';out.mkdir(exist_ok=False)
manifest=copy.deepcopy(meta)
manifest.pop('normalization');manifest.pop('normalization_split')
manifest['graph_schema']=velocity_schema(meta['graph_schema'],list(config.joint_names))
manifest['proprio_velocity_graph']={
    'source_schema_id':SCHEMA_ID,'robot_node_index':2,
    'node_order':['cargo','goal','gripper'],'ordered_joint_names':list(config.joint_names),
    'source_dataset_sha256':sha256(source),
    'method':'Backward finite differences of observed joint states at the declared control period; first frame zero; no future states or target actions used'}
for entry in manifest['episodes']:
    entry['path']=os.path.relpath((source.parent/entry['path']).resolve(),out)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
prepared=prepare_dataset(out/'manifest.json',out/'prepared.json')
print('VELOCITY_DATASET_READY',len(prepared['graph_schema']['features']),flush=True)
c=json.loads((root/'configs/runpod-pi0-recovery-long.json').read_text())
c.update(dataset='../data/franka-velocity-v14/prepared.json',output_dir='../runs/franka-pi0-velocity-v14',steps=4000,
         save_every=1000,eval_every=1000,learning_rate=3e-5,warmup_steps=100)
c['adapter']['feature_dim']=35;c['adapter']['initial_gate']=.05
(root/'configs/runpod-pi0-velocity.json').write_text(json.dumps(c,indent=2))
previous=root/'runs/franka-pi0-recovery-long-v11/step-00006000'
old=json.loads((previous/'metadata.json').read_text());assert old['step']==6000
assert old['dataset']['action_convention']==prepared['action_convention']
assert old['dataset']['normalization']==prepared['normalization']
init=root/'runs/franka-pi0-velocity-initializer-v14/step-00000000';init.mkdir(parents=True,exist_ok=False)
old_weights=load_file(str(previous/'adapter.safetensors'))
weights=extend_adapter_weights(old_weights,35,reset_gate=.05)
save_file(weights,str(init/'adapter.safetensors'))
for name in ['action_io.safetensors','action_expert.safetensors']:
    shutil.copy2(previous/name,init/name)
new=copy.deepcopy(old)
new.update(step=0,cursor=0,dataset={k:v for k,v in prepared.items() if k!='episodes'},training_config=TrainConfig.load(root/'configs/runpod-pi0-velocity.json').to_dict())
new['identity']['prepared_dataset']=sha256(out/'prepared.json')
new['graph_extension_initialization']={
    'scope':'Initialization artifact, not a newly trained checkpoint',
    'source_checkpoint':str(previous),'source_step':6000,
    'source_weight_sha256':{p.name:sha256(p) for p in previous.glob('*.safetensors')},
    'projection':'Preserve original 26 feature columns; append nine zero columns',
    'gate_reset':{'previous':float(old_weights['gate']), 'new':.05},
    'unchanged_modules':['action_io','action_expert','frozen pretrained VLM'],
    'new_observations':'Nine causally estimated motor velocities in the robot KG node; original graph features and success/guard criteria unchanged'}
(init/'metadata.json').write_text(json.dumps(new,indent=2))
print('VELOCITY_INITIALIZER_READY',str(init),flush=True)
