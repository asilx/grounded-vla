import json
from pathlib import Path
import numpy as np
import torch
from learned_local_field_v18 import Policy,features,predict
cp=Path('/workspace/grounded-vla/runs/learned-local-field-v18');p=Policy(cp);m=p.meta;prepared=Path('/workspace/grounded-vla/data/franka-recovery-v16/prepared.json');entry=next(e for e in m['episodes'] if e['split']=='val')
with np.load(prepared.parent/entry['path'],allow_pickle=False) as z:q=z['state'][:64];f=z['graph_features'][:64]
expected=predict(torch.from_numpy(q),torch.from_numpy(features(q,f)),p.params).numpy().astype(np.float32);actual=[]
for i in range(len(q)):
 payload={'state':q[i],'graph':{'schema_id':p.metadata['graph_schema_id'],'features':f[i]}}
 a=p.infer(payload)['actions'][0];actual.append(a)
 assert np.all(a>=np.asarray(m['encoding_lower_limits'])-1e-7) and np.all(a<=np.asarray(m['encoding_upper_limits'])+1e-7)
 assert np.all(np.abs(a-q[i])<=np.asarray(m['encoding_max_joint_step'])+1e-7)
np.testing.assert_allclose(np.asarray(actual),expected,rtol=0,atol=1e-7)
first=p.infer({'state':q[0],'graph':{'schema_id':p.metadata['graph_schema_id'],'features':f[0]}})['actions'][0];np.testing.assert_array_equal(first,actual[0]);p.reset();np.testing.assert_array_equal(p.infer({'state':q[0],'graph':{'schema_id':p.metadata['graph_schema_id'],'features':f[0]}})['actions'][0],actual[0])
report={'verified':True,'samples':64,'stream_batch_max_error_rad':float(np.abs(np.asarray(actual)-expected).max()),'checks':['native joint and per-step bounds','batch/stream parity','no sequence/phase dependence','episode reset identity'],'weights_sha256':p.artifact['weights_sha256']};Path('/workspace/grounded-forge-status/v18-local-field-checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
