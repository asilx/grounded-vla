#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends libatomic1 libegl1 libgl1 libglu1-mesa libglx0 libgomp1 libsm6 libxi6 libxrandr2 libxt6 libglib2.0-0 libnghttp2-14 libvulkan1 vulkan-tools libx11-6 libxcb1 libxext6 libxrender1 libice6
