"""Scripted Franka physics pilot; does not measure pretrained VLA performance."""
import argparse
import json
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=0)
args = parser.parse_args()
import importlib.metadata
ISAAC_VERSION=importlib.metadata.version("isaacsim")
import isaacsim
from isaacsim.simulation_app import SimulationApp
app = SimulationApp({'headless':True, 'width':640, 'height':480})
try:
    import omni.kit.app
    manager = omni.kit.app.get_app().get_extension_manager()
    manager.set_extension_enabled_immediate('isaacsim.core.api', True)
    manager.set_extension_enabled_immediate('isaacsim.sensors.experimental.rtx', True)
    manager.set_extension_enabled_immediate('isaacsim.robot.manipulators.examples', True)
    import numpy as np
    import omni.usd
    from pxr import UsdLux, UsdGeom, Gf
    from PIL import Image
    from isaacsim.core.api import World
    from isaacsim.core.api.objects import DynamicCuboid, FixedCuboid
    from isaacsim.robot.manipulators.examples.franka import Franka
    from isaacsim.robot.manipulators.examples.franka.controllers import PickPlaceController
    from isaacsim.sensors.experimental.rtx import RtxCamera, CameraSensor
    rng = np.random.default_rng(args.seed)
    destination = np.array([0.3,-0.3,0.02575])
    destination[:2] += rng.uniform(-0.015,0.015,size=2)
    directory = Path('/workspace/grounded-forge-status/franka-expert-guarded-v7')/f'seed-{args.seed:03d}'
    directory.mkdir(parents=True,exist_ok=False)
    world = World(stage_units_in_meters=1.,physics_dt=1/60,rendering_dt=1/60)
    world.scene.add(FixedCuboid(prim_path='/World/Ground',name='ground',position=np.array([0.,0.,-.05]),scale=np.array([4.,4.,.1]),color=np.array([.25,.25,.25])))
    arm = world.scene.add(Franka(prim_path='/World/Robot',name='franka'))
    cargo = world.scene.add(DynamicCuboid(prim_path='/World/Cargo',name='cargo',position=np.array([0.3,0.3,0.15]),scale=np.full(3,0.0515),color=np.array([0.9,0.1,0.1])))
    dome = UsdLux.DomeLight.Define(omni.usd.get_context().get_stage(),'/World/Light')
    dome.CreateIntensityAttr(1500.)
    camera = RtxCamera('/World/Camera',tick_rate=60.0)
    transform=UsdGeom.Xformable(omni.usd.get_context().get_stage().GetPrimAtPath('/World/Camera'))
    transform.ClearXformOpOrder()
    transform.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(1.3,1.3,1.1),Gf.Vec3d(.3,0.,.2),Gf.Vec3d(0.,0.,1.)).GetInverse())
    sensor=CameraSensor(camera,resolution=(224,224),annotators=['rgb'])
    from grounded_vla.backends.rtx_camera import RtxCameraBridge
    import omni.replicator.core as rep
    timer=rep.AnnotatorRegistry.get_annotator('IsaacReadSimulationTime')
    timer.attach([str(sensor.render_product.GetPath())])
    base_bridge=RtxCameraBridge(sensor,timer)
    wrist_path='/World/Robot/panda_hand/WristCamera'
    wrist=RtxCamera(wrist_path,tick_rate=60.0)
    wt=UsdGeom.Xformable(omni.usd.get_context().get_stage().GetPrimAtPath(wrist_path))
    wt.ClearXformOpOrder()
    wt.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(Gf.Vec3d(.05,0,-.03),Gf.Vec3d(.05,0,.5),Gf.Vec3d(1,0,0)).GetInverse())
    wrist_bridge=RtxCameraBridge.attach(wrist_path,tick_rate=60.0)
    rows=[]
    last_image_times=None
    from grounded_vla.backends.isaacsim import IsaacSimConfig
    from isaacsim.core.utils.types import ArticulationAction
    limits=IsaacSimConfig.load('/workspace/grounded-vla/configs/runpod-franka-pi0.json')
    teacher_limited=0
    world.reset()
    arm.disable_gravity()
    servo=arm.get_articulation_controller()
    original_kp,original_kd=servo.get_gains()
    gains_kp=np.array([6000.]*7+[1000.,0.])
    gains_kd=np.array([300.]*7+[50.,0.])
    servo.set_gains(kps=gains_kp,kds=gains_kd,save_to_usd=True)
    (directory/'drive-gains.json').write_text(json.dumps({'kp':gains_kp.tolist(),'kd':gains_kd.tolist(),'original_kp':np.asarray(original_kp).tolist(),'original_kd':np.asarray(original_kd).tolist(),'scope':'simulation actuator tracking calibration; unchanged joint/step bounds','robot_gravity_compensation':'ideal: disabled gravity on robot links only','object_gravity':True},indent=2))
    print('SIMULATOR_DRIVE_GAINS',gains_kp.tolist(),gains_kd.tolist(),flush=True)
    for _ in range(60): world.step(render=True); world.render()
    # A feedback-paced scripted teacher, not the learned policy.
    with np.load(Path('/workspace/grounded-forge-status/franka-expert-raw')/f'seed-{args.seed:03d}'/'expert-raw.npz',allow_pickle=False) as z:
        ref_states=z['states'].copy()
        ref_actions=z['actions'].copy()
        ref_events=z['controller_events'].copy()
    class ReferenceTeacher:
        def __init__(self): self.index=0
        def is_done(self): return self.index>=len(ref_states)
        def get_current_event(self): return int(ref_events[min(self.index,len(ref_states)-1)])
        def forward(self,**unused):
            j=min(self.index+1,len(ref_states)-1)
            target=ref_states[j].copy()
            target[7:]=.04 if self.get_current_event() in (0,1) or self.get_current_event()>=7 else 0.
            return ArticulationAction(joint_positions=target,joint_indices=np.arange(9))
        def advance(self,positions):
            if self.is_done(): return
            j=min(self.index+1,len(ref_states)-1)
            tolerance=.01 if self.get_current_event() in (4,5,6) else .003
            if np.max(np.abs(positions[:7]-ref_states[j,:7]))<tolerance:
                self.index+=1
    controller=ReferenceTeacher()
    teacher_desired=arm.get_joint_positions().copy()
    initial,_ = cargo.get_world_pose()
    highest = float(initial[2])
    done_at = None
    with (directory/'trace.jsonl').open('w') as trace:
        for step in range(12000):
            position,orientation = cargo.get_world_pose()
            highest = max(highest,float(position[2]))
            if not controller.is_done():
                command = controller.forward(picking_position=position,placing_position=destination,current_joint_positions=arm.get_joint_positions())
                frames=[base_bridge.get_current_frame(),wrist_bridge.get_current_frame()]
                now=float(world.current_time)
                image_times=np.array([f.get('rendering_time',float('nan')) for f in frames],dtype=np.float64)
                assert all('rgba' in f for f in frames), 'missing real camera frame'
                assert np.isfinite(image_times).all() and np.all(image_times<=now+1e-6) and np.all(now-image_times<=.05), 'camera timestamp invalid'
                assert last_image_times is None or np.all(image_times>=last_image_times), 'camera clock moved backward'
                fresh=np.ones(2,dtype=bool) if last_image_times is None else image_times>last_image_times
                state=arm.get_joint_positions().copy()
                target=teacher_desired.copy()
                indices=range(9) if command.joint_indices is None else command.joint_indices
                assert command.joint_positions is not None, 'expert command has no position targets'
                for index,value in zip(indices,command.joint_positions):
                    if value is not None: target[index]=float(value)
                assert state.shape==target.shape==(9,) and np.isfinite(target).all()
                teacher_desired=target.copy()
                # Limit the scripted teacher before submission. Model outputs are never clipped.
                bounded=np.clip(target,limits.lower_limits,limits.upper_limits)
                bounded=np.clip(bounded,state-np.asarray(limits.max_joint_step)*.999,state+np.asarray(limits.max_joint_step)*.999)
                bounded=np.clip(bounded,limits.lower_limits,limits.upper_limits)
                assert np.all(bounded>=limits.lower_limits) and np.all(bounded<=limits.upper_limits)
                assert np.all(np.abs(bounded-state)<=np.asarray(limits.max_joint_step)+1e-7)
                teacher_limited+=int(not np.allclose(bounded,target))
                arm.apply_action(ArticulationAction(joint_positions=bounded,joint_indices=np.arange(9)))
                applied=arm.get_applied_action()
                target=np.asarray(applied.joint_positions,dtype=np.float64).copy()
                assert target.shape==(9,) and np.isfinite(target).all(), 'incomplete applied position target'
                assert float(world.current_time)==now, 'physics advanced during action recording'
                end_effector=arm.end_effector.get_world_pose()[0].copy()
                rows.append((now,image_times.copy(),state,target,frames[0]['rgba'][...,:3].copy(),frames[1]['rgba'][...,:3].copy(),position.copy(),orientation.copy(),controller.get_current_event(),fresh.copy(),end_effector))
                last_image_times=image_times
            elif done_at is None:
                done_at = step
            world.step(render=True); world.render()
            controller.advance(arm.get_joint_positions())
            if step % 6 == 0:
                trace.write(json.dumps({'step':step,'sim_time':step/60,'position':position.tolist(),'orientation':orientation.tolist(),'joint_positions':arm.get_joint_positions().tolist(),'end_effector_position':arm.end_effector.get_world_pose()[0].tolist(),'controller_event':controller.get_current_event()})+'\n')
            if step % 60 == 0:
                rgba, info = sensor.get_data("rgb")
                if rgba is not None: rgba=rgba.numpy() if hasattr(rgba,"numpy") else np.asarray(rgba)
                if rgba is not None and rgba.size:
                    Image.fromarray(rgba.astype(np.uint8)).save(directory/f'frame-{step:04d}.png')
            if done_at is not None and step-done_at >= 120: break
    final,_ = cargo.get_world_pose()
    planar_error = float(np.linalg.norm(final[:2]-destination[:2]))
    success = bool(done_at is not None and highest > initial[2]+0.07 and planar_error < 0.04 and abs(final[2]-destination[2]) < 0.03)
    result = {'scope':'feedback-paced guarded reference-waypoint scripted Franka teacher; not learned policy','isaac_version':ISAAC_VERSION,'robot_api':'legacy Franka compatibility extension','events_dt':None,'teacher_reference':'previous successful physical episode joint states; feedback tracking tolerance .003 rad unloaded and .01 rad carrying; unchanged .05 rad command guard','seed':args.seed,'controller_completed':done_at is not None,'success':success,'initial_position':initial.tolist(),'destination':destination.tolist(),'final_position':final.tolist(),'planar_error_m':planar_error,'peak_height_m':highest,'steps':step+1,'teacher_commands_limited':teacher_limited,'teacher_limiting':'scripted targets bounded before physics; no learned-policy output clipping'}
    (directory/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    assert rows, 'no causal expert samples recorded'
    times=np.array([r[0] for r in rows])
    assert np.allclose(np.diff(times),1/60,atol=1e-7), 'expert time grid is not 60 Hz'
    np.savez_compressed(directory/'expert-raw.npz',state_timestamps=times,image_timestamps=np.stack([r[1] for r in rows]),states=np.stack([r[2] for r in rows]),actions=np.stack([r[3] for r in rows]),base_rgb=np.stack([r[4] for r in rows]),wrist_rgb=np.stack([r[5] for r in rows]),object_positions=np.stack([r[6] for r in rows]),object_orientations=np.stack([r[7] for r in rows]),controller_events=np.array([r[8] for r in rows]),image_fresh=np.stack([r[9] for r in rows]),end_effector_positions=np.stack([r[10] for r in rows]))
    metadata={'scope':'raw causal scripted Franka expert; not learned VLA and not training-ready graph dataset','seed':args.seed,'samples':len(rows),'control_period_s':1/60,'action_mode':'full position targets read from articulation get_applied_action after submission, before physics step','cameras':['base','wrist'],'image_shape':[224,224,3],'image_time_source':'IsaacReadSimulationTime attached to each real render product','max_capture_age_s':float(np.max(times[:,None]-np.stack([r[1] for r in rows]))),'physics_success':success,'fresh_pair_samples':int(sum(bool(r[9].all()) for r in rows)),'camera_sample_policy':'actual recent images; repeated sensor frames flagged separately; availability and novelty are distinct','semantic_graph_features_recorded':False,'split_and_normalization_complete':False}
    (directory/'expert-metadata.json').write_text(json.dumps(metadata,indent=2))
    print(json.dumps(metadata,indent=2),flush=True)
    if not success: raise RuntimeError('Franka pilot did not meet independent physical success criteria.')
except BaseException:
    import traceback; traceback.print_exc(); raise
finally:
    app.close()
