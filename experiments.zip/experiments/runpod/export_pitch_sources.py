"""Export original successful recordings and the actual current project source."""
import base64,datetime,hashlib,io,json,shutil,subprocess,zipfile
from pathlib import Path
import numpy as np
root=Path('/workspace/grounded-vla');status=Path('/workspace/grounded-forge-status');out=status/'pitch-v18-deliverables';out.mkdir(exist_ok=False)
records=[]
for seed in [0,1,2]:
 p=status/'learned-local-field-v18-task'/f'seed-{seed}-attempt-0';d=json.loads((p/'result.json').read_text());assert d['verified'] and d['task_success']
 assert hashlib.file_digest((p/'learned-rollout.npz').open('rb'),'sha256').hexdigest()==d['rollout_recording_sha256']
 for camera,label in [('base_0_rgb','base'),('left_wrist_0_rgb','wrist')]:
  with np.load(p/'learned-rollout.npz',allow_pickle=False) as z:frames=z['images/'+camera];times=z['timestamps'].copy()
  assert frames.shape==(d['executed_steps'],224,224,3) and frames.dtype==np.uint8;assert np.allclose(np.diff(times),1/60,atol=1e-6)
  target=out/f'v18-seed-{seed}-{label}-original-60fps.mp4';log=out/f'v18-seed-{seed}-{label}-encoder.log'
  with log.open('w') as l:
   proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','224x224','-r','60','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','16','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],stdin=subprocess.PIPE,stdout=l,stderr=subprocess.STDOUT)
   for frame in frames:proc.stdin.write(frame.tobytes())
   proc.stdin.close();assert proc.wait(timeout=120)==0
  records.append(dict(seed=seed,camera=camera,file=target.name,source_resolution=[224,224],source_frames=len(frames),fps=60,simulation_start=float(times[0]),simulation_end=float(times[-1]),source_rollout_sha256=d['rollout_recording_sha256'],sha256=hashlib.file_digest(target.open('rb'),'sha256').hexdigest()))
  print('ORIGINAL_VIDEO_ENCODED',target.name,target.stat().st_size,flush=True);del frames
(out/'original-video-provenance.json').write_text(json.dumps(records,indent=2))
# Whitelisted source tree only. Runtime data/checkpoints/logs/caches/credentials are excluded.
selected=[];top=['README.md','pyproject.toml','requirements-simulation.txt','requirements-training.txt','Dockerfile.isaacsim','Dockerfile.train','LICENSE','NOTICE','CITATION.cff','CONTRIBUTING.md','CHANGELOG.md','.gitignore']
for name in top:
 p=root/name
 if p.is_file():selected.append(p)
allowed={'.py','.sh','.md','.json','.toml','.yaml','.yml','.txt','.ttl','.owl','.rdf','.urdf','.xacro','.csv','.png','.svg','.cff'}
for name in ['src','configs','experiments','tests','docs','scripts','examples','knowledge','assets','.github']:
 for p in (root/name).rglob('*'):
  if not p.is_file() or p.is_symlink() or any(x in ('__pycache__','.git','.venv','node_modules') or x.endswith('.egg-info') for x in p.relative_to(root).parts):continue
  if p.suffix.lower() not in allowed:continue
  if p.name.startswith('.env') or p.suffix in ('.pem','.key'):continue
  selected.append(p)
manifest={'exported_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'Actual running pod /workspace/grounded-vla; no Git history exists in this directory','files':[]}
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(selected)):
  b=p.read_bytes();name=str(p.relative_to(root));z.writestr(name,b);manifest['files'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 z.writestr('SOURCE_EXPORT_MANIFEST.json',json.dumps(manifest,indent=2))
raw=buf.getvalue();(status/'V18_CURRENT_SOURCE_EXPORT.txt').write_text(base64.b64encode(raw).decode());(out/'current-source.zip').write_bytes(raw);print('CURRENT_SOURCE_EXPORT',len(raw),len(selected),hashlib.sha256(raw).hexdigest(),flush=True)
