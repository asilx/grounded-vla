#!/usr/bin/env bash
set -euo pipefail
status=/workspace/grounded-forge-status
for attempt in $(seq 1 660); do
  if [ -f "$status/resume-gpu-validation.exit" ]; then break; fi
  sleep 5
done
[ "$(cat "$status/resume-gpu-validation.exit")" = 0 ]
cd /workspace/grounded-vla
export OMNI_KIT_ACCEPT_EULA=YES OMNI_KIT_ALLOW_ROOT=1
ulimit -c 0
for seed in 0 1 2; do
  timeout 900 /workspace/isaac6-env/bin/python experiments/runpod/franka_expert_raw.py --seed "$seed" > "$status/expert-seed-$seed.log" 2>&1
  /workspace/isaac6-env/bin/python - "$seed" <<'PY'
import sys,json,hashlib
from pathlib import Path
import numpy as np
p=Path('/workspace/grounded-forge-status/franka-expert-raw')/f'seed-{int(sys.argv[1]):03d}'
m=json.loads((p/'expert-metadata.json').read_text())
assert m['physics_success'] is True
with np.load(p/'expert-raw.npz',allow_pickle=False) as d:
    n=len(d['states'])
    assert n>100 and d['states'].shape==d['actions'].shape==(n,9)
    assert d['base_rgb'].shape==d['wrist_rgb'].shape==(n,224,224,3)
    assert d['base_rgb'].dtype==d['wrist_rgb'].dtype==np.uint8
    assert np.isfinite(d['states']).all() and np.isfinite(d['actions']).all()
    assert np.allclose(np.diff(d['state_timestamps']),1/60,atol=1e-7)
    ages=d['state_timestamps'][:,None]-d['image_timestamps']
    assert np.all(ages>=-1e-6) and np.all(ages<=.05)
    assert np.all(np.diff(d['image_timestamps'],axis=0)>=0)
    expected_fresh=np.vstack([np.ones((1,2),dtype=bool),np.diff(d['image_timestamps'],axis=0)>0])
    assert np.array_equal(d['image_fresh'],expected_fresh)
    assert int(np.all(d['image_fresh'],axis=1).sum())>100
    assert float(d['base_rgb'].std())>1 and float(d['wrist_rgb'].std())>1
sha=hashlib.sha256((p/'expert-raw.npz').read_bytes()).hexdigest()
(p/'verification.json').write_text(json.dumps({'verified':True,'samples':n,'sha256':sha,'scope':'raw scripted expert data; no learned policy or graph ablation'},indent=2))
print('EXPERT_VERIFIED',sys.argv[1],n,sha,flush=True)
PY
done
