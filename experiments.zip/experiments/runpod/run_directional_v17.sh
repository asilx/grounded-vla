#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
trap 'echo $? > "$status/v17-pipeline.exit"' EXIT
/workspace/pi0-train-env/bin/python -m pytest tests/test_gripper_direction_v17.py -q
set +e
/workspace/pi0-train-env/bin/python -u experiments/runpod/learned_directional_v17.py train data/franka-recovery-v16/prepared.json runs/learned-graph-baseline-v17 --steps 2000 --history 4
train_exit=$?
echo "$train_exit" > "$status/learned-baseline-v17-train.exit"
set -e
test "$train_exit" = 0
/workspace/pi0-train-env/bin/python -u experiments/runpod/evaluate_baseline_v17.py
