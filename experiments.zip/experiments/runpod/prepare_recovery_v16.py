from pathlib import Path
import json,os
import numpy as np
from grounded_vla.training.data import load_prepared,prepare_dataset
from grounded_vla.training.recording import EpisodeRecorder
from grounded_vla.training.graph import encode_belief_graph,SCHEMA_ID
from grounded_vla.training.runtime import sha256
from grounded_vla.belief import BeliefStore
from grounded_vla.backends.isaacsim import IsaacSimConfig

root=Path('/workspace/grounded-vla');status=Path('/workspace/grounded-forge-status')
original=root/'data/franka-recovery-v10/prepared.json';meta=load_prepared(original)
out=root/'data/franka-recovery-v16';out.mkdir(exist_ok=False)
limits=IsaacSimConfig.load(root/'configs/runpod-franka-guarded.json')
entries=[];audit=[]
for e in meta['episodes']:
    entries.append({**e,'path':os.path.relpath((original.parent/e['path']).resolve(),out)})
for seed in [6,7,8]:
    src=status/'franka-expert-recovery-v16'/f'seed-{seed:03d}'
    verification=json.loads((src/'verification.json').read_text());result=json.loads((src/'result.json').read_text());provenance=json.loads((src/'expert-metadata.json').read_text())
    assert verification['verified'] and verification['sha256']==sha256(src/'expert-raw.npz')
    assert result['success'] and result['stable_release_steps']>=120
    with np.load(src/'expert-raw.npz',allow_pickle=False) as z:raw={k:z[k] for k in z.files}
    assert np.all(raw['actions']>=limits.lower_limits) and np.all(raw['actions']<=limits.upper_limits)
    assert np.all(np.abs(raw['actions']-raw['states'])<=np.asarray(limits.max_joint_step)+1e-7)
    goal=np.array([.3,-.3,.02575]);goal[:2]+=np.random.default_rng(provenance['reference_seed']).uniform(-.015,.015,2)
    np.testing.assert_array_equal(goal,result['destination'])
    recorder=EpisodeRecorder(SCHEMA_ID);store=BeliefStore()
    for i,now in enumerate(raw['state_timestamps']):
        cargo=raw['object_positions'][i];gripper=raw['end_effector_positions'][i]
        images={'base_0_rgb':raw['base_rgb'][i],'left_wrist_0_rgb':raw['wrist_rgb'][i]}
        visible=False
        for image in images.values():
            x=image.astype(np.float32)
            if ((x[...,0]>60)&(x[...,0]>1.5*x[...,1])&(x[...,0]>1.5*x[...,2])).sum()>=4:visible=True
        objects=[dict(id='cargo',position=cargo,visible=visible,is_target=True),dict(id='goal',position=goal,visible=False,is_target=False),dict(id='gripper',position=gripper,visible=False,is_target=False)]
        relations=[('goal','target_of','cargo')]
        if np.linalg.norm(cargo-gripper)<.12:relations+=[('cargo','near','gripper'),('gripper','near','cargo')]
        graph=encode_belief_graph(store,objects,relations,now=float(now))
        recorder.append(state=raw['states'][i],action=raw['actions'][i],images=images,prompt='Place the red cube at the graph goal.',graph=graph,timestamp=float(now),graph_timestamp=float(now))
    episode=out/f'recovery-{seed}.npz';recorder.save(episode)
    with np.load(episode,allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
    arrays['capture_timestamps']=raw['image_timestamps'];arrays['capture_fresh']=raw['image_fresh']
    with episode.open('wb') as f:np.savez_compressed(f,**arrays)
    entries.append(dict(id=f'franka-recovery-{seed}',path=episode.name,split='train'))
    audit.append(dict(seed=seed,frames=len(raw['states']),source_sha256=verification['sha256'],initialization=provenance['initialization_provenance'],goal_prior=goal.tolist()))
    print('RECOVERY_EPISODE_PREPARED',seed,len(raw['states']),flush=True)
meta.pop('normalization');meta.pop('normalization_split');meta['episodes']=entries
meta['recovery_training_provenance']=meta.get('recovery_training_provenance',[])+audit
(out/'manifest.json').write_text(json.dumps(meta,indent=2))
prepared=prepare_dataset(out/'manifest.json',out/'prepared.json')
assert len([e for e in prepared['episodes'] if e['split']=='train'])==7
print('V16_RECOVERY_DATASET_READY',[(e['id'],e['split'],e['frames']) for e in prepared['episodes']],flush=True)
