#!/usr/bin/env bash
set -euo pipefail
cd /workspace/grounded-vla
status=/workspace/grounded-forge-status
for attempt in $(seq 1 500); do
  if [ -f "$status/pi0-download-convert.exit" ]; then break; fi
  sleep 5
done
[ "$(cat "$status/pi0-download-convert.exit")" = 0 ]
export JAX_PLATFORMS=cpu
export OPENPI_SOURCE=/workspace/support/openpi-source
export TOKENIZERS_PARALLELISM=false
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
timeout 900 /workspace/pi0-train-env/bin/grounded-vla-train configs/runpod-pi0-smoke.json --stop-after 10
