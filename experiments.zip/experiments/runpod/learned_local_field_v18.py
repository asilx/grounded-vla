"""Unordered learned local dynamical fields from successful demonstrations.
The model contains learned cluster statistics, not ordered rollout/waypoint commands.
No runtime teacher, reference index, phase label, clock, RGB or language input.
"""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import torch
from safetensors.torch import save_file,load_file
from grounded_vla.training.data import load_prepared

def features(q,f):
 q=np.asarray(q,np.float32);f=np.asarray(f,np.float32)
 if q.ndim!=2 or q.shape[1]!=9 or f.shape!=(len(q),3,26):raise ValueError('Invalid observation dimensions')
 if not np.isfinite(q).all() or not np.isfinite(f).all():raise ValueError('Nonfinite input')
 return np.concatenate([q[:,:7],q[:,7:]*20,f[:,:2,:3].reshape(len(q),6)*10],axis=1)

def load_split(prepared,meta,split):
 rows=[]
 for e in meta['episodes']:
  if e['split']!=split:continue
  with np.load(prepared.parent/e['path'],allow_pickle=False) as z:
   q=z['state'].copy();a=z['actions'].copy();f=z['graph_features'].copy()
  nextq=np.concatenate([q[1:],q[-1:]])
  movement=nextq-q
  active=(np.linalg.norm(movement[:,:7],axis=1)>2e-5)|(np.max(np.abs(movement[:,7:]),axis=1)>2e-6)
  # Terminal settling remains represented. No waiting counter is an input.
  active[-64:]=True
  rows.append((features(q,f),q,a,movement,active))
 return tuple(np.concatenate([r[i] for r in rows]) for i in range(5))

def distances(x,c):return (x[:,None]-c[None]).square().sum(-1)

def predict(q,x,params,gain=.15):
 q=q.double();x=x.double();c=params['centers'];meanq=params['mean_q'];delta=params['mean_delta'];t=params['tangent']
 dist=distances(x,c);weights=torch.softmax(-dist/(2*float(params['width'].item())**2),dim=1)
 offset=q[:,None,:7]-meanq[None,:,:7]
 normal=offset-(offset*t[None]).sum(-1,keepdim=True)*t[None]
 arm=delta[None,:,:7]-gain*normal
 d=(weights[:,:,None]*arm).sum(1)
 fingers=weights@(meanq[:,7:]+delta[:,7:])-q[:,7:]
 desired=q+torch.cat([d,fingers],dim=1)
 step=params['steps']*.9999;lo=torch.maximum(params['lower'],q-step);hi=torch.minimum(params['upper'],q+step)
 mid=(lo+hi)/2;half=(hi-lo)/2
 # Intrinsically bounded smooth action head, no submitted-action clipping.
 return mid+half*torch.tanh((desired-mid)/half.clamp_min(1e-12))

def train():
 torch.set_num_threads(4);torch.manual_seed(173);root=Path('/workspace/grounded-vla');p=root/'data/franka-recovery-v16/prepared.json';meta=load_prepared(p);out=root/'runs/learned-local-field-v18';assert not out.exists()
 tx,tq,ta,tm,active=load_split(p,meta,'train');vx,vq,va,vm,_=load_split(p,meta,'val');indices=np.flatnonzero(active)
 if len(indices)<512:raise ValueError('Insufficient active samples')
 device='cuda' if torch.cuda.is_available() else 'cpu';x=torch.from_numpy(tx[indices]).to(device);k=512
 centers=x[torch.randperm(len(x),device=device)[:k]].clone()
 for iteration in range(40):
  dist=torch.cdist(x,centers).square();labels=dist.argmin(1);counts=torch.bincount(labels,minlength=k)
  sums=torch.zeros_like(centers);sums.index_add_(0,labels,x);new=sums/counts.clamp_min(1)[:,None]
  empty=counts==0
  if empty.any():new[empty]=x[dist.min(1).values.topk(int(empty.sum())).indices]
  change=(new-centers).abs().max().item();centers=new
  if iteration%10==0:print('KMEANS',iteration,change,flush=True)
 labels=torch.cdist(x,centers).argmin(1).cpu();centers=centers.cpu().double();count=torch.bincount(labels,minlength=k).double()
 keep=count>0
 mapping=torch.full((k,),-1,dtype=torch.int64);mapping[keep]=torch.arange(int(keep.sum()));labels=mapping[labels];centers=centers[keep];count=count[keep];k=len(centers)
 assert (count>0).all()
 def means(values):
  values=torch.from_numpy(values[indices]).double();s=torch.zeros(k,values.shape[1],dtype=torch.float64);s.index_add_(0,labels,values);return s/count[:,None]
 meanq=means(tq);delta=means(ta-tq);movement=means(tm[:,:7]);length=movement.norm(dim=1,keepdim=True);tangent=torch.where(length>1e-6,movement/length.clamp_min(1e-12),torch.zeros_like(movement))
 pair=torch.cdist(centers,centers);pair.fill_diagonal_(float('inf'));width=pair.min(1).values.median()*1.25
 params=dict(centers=centers.contiguous(),mean_q=meanq.contiguous(),mean_delta=delta.contiguous(),tangent=tangent.contiguous(),width=width.reshape(1),steps=torch.tensor(meta['encoding_max_joint_step'],dtype=torch.float64),lower=torch.tensor(meta['encoding_lower_limits'],dtype=torch.float64),upper=torch.tensor(meta['encoding_upper_limits'],dtype=torch.float64))
 scores={}
 for split,x,q,a in [('train',tx,tq,ta),('val',vx,vq,va)]:
  predictions=[]
  for i in range(0,len(x),128):predictions.append(predict(torch.from_numpy(q[i:i+128]),torch.from_numpy(x[i:i+128]),params).numpy())
  pred=np.concatenate(predictions);err=np.linalg.norm(pred[:,:7]-a[:,:7],axis=1);scores[split]=dict(mean_arm_command_error_rad=float(err.mean()),first_arm_command_error_rad=float(err[0]),first32_arm_command_error_rad=float(err[:32].mean()))
  assert np.isfinite(pred).all();assert np.all(pred>=np.asarray(meta['encoding_lower_limits'])-1e-7) and np.all(pred<=np.asarray(meta['encoding_upper_limits'])+1e-7);assert np.all(np.abs(pred-q)<=np.asarray(meta['encoding_max_joint_step'])+1e-7)
 # An offline validity gate, not a task-success gate.
 eligible=scores['train']['first_arm_command_error_rad']<.01 and scores['val']['mean_arm_command_error_rad']<.01
 report=dict(scope='Learned local contracting dynamical-field numeric imitation baseline; no pi0/VLA or learned safety claim',train_samples=len(tx),active_fit_samples=len(indices),clusters=k,kmeans_iterations=iteration+1,width=float(width),fixed_normal_contraction_gain=.15,scores=scores,eligible=eligible,selection='Fixed 512 clusters and gain; width derived from training centroid spacing; no validation/test hyperparameter tuning',training_filter='Exclude near-stationary waiting observations using training next-state movement; retain final64 observations per episode; future movement is used only for fitting')
 Path('/workspace/grounded-forge-status/v18-local-field-fit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
 if not eligible:print('LOCAL_FIELD_GATE_FAILED',flush=True);return
 out.mkdir();save_file(params,str(out/'field.safetensors'));md=dict(dataset=meta,scope=report['scope'],policy='learned-local-contracting-field',uses_rgb=False,uses_language=False,history_steps=1,weights_sha256=hashlib.file_digest((out/'field.safetensors').open('rb'),'sha256').hexdigest(),fit=report,train_episodes=[e['id'] for e in meta['episodes'] if e['split']=='train'],val_episodes=[e['id'] for e in meta['episodes'] if e['split']=='val'],runtime='Unordered learned cluster statistics; no raw demonstration actions, ordered trajectory, nearest reference step or phase clock');(out/'metadata.json').write_text(json.dumps(md,indent=2));(out/'metrics.json').write_text(json.dumps(report,indent=2));print('LEARNED_FIELD_SAVED',out,flush=True)

class Policy:
 def __init__(self,checkpoint):
  torch.set_num_threads(2);p=Path(checkpoint);self.artifact=json.loads((p/'metadata.json').read_text());self.meta=self.artifact['dataset'];self.params=load_file(str(p/'field.safetensors'))
  assert hashlib.file_digest((p/'field.safetensors').open('rb'),'sha256').hexdigest()==self.artifact['weights_sha256']
  self.metadata=dict(policy=self.artifact['policy'],uses_rgb=False,uses_language=False,scope=self.artifact['scope'],weights_sha256=self.artifact['weights_sha256'],history_steps=1,input_preset='canonical',graph_required=True,state_dim=9,action_dim=9,action_horizon=1,action_encoding=self.meta['action_encoding'],action_convention=self.meta['action_convention'],control_period_seconds=self.meta['control_period_seconds'],graph_schema_id=self.meta['graph_schema']['id'],graph_feature_dim=26,graph_relation_types=len(self.meta['graph_schema']['relations']))
 def reset(self):pass
 @torch.no_grad()
 def infer(self,payload):
  q=np.asarray(payload['state'],np.float32);g=payload['graph'];f=np.asarray(g['features'],np.float32)
  if q.shape!=(9,) or g['schema_id']!=self.metadata['graph_schema_id'] or f.shape!=(3,26):raise ValueError('Invalid policy input schema')
  x=features(q[None],f[None]);a=predict(torch.from_numpy(q[None]),torch.from_numpy(x),self.params).numpy().astype(np.float32)
  if not np.isfinite(a).all():raise FloatingPointError('Nonfinite learned field command')
  return {'actions':a}

def main():
 p=argparse.ArgumentParser();p.add_argument('command',choices=['train','serve']);p.add_argument('--checkpoint',default='/workspace/grounded-vla/runs/learned-local-field-v18');p.add_argument('--port',type=int,default=8013);a=p.parse_args()
 if a.command=='train':train();return
 from openpi.serving.websocket_policy_server import WebsocketPolicyServer
 class Server(WebsocketPolicyServer):
  active=False
  async def _handler(self,websocket):
   if self.active:await websocket.close(code=1013,reason='One episode at a time');return
   self.active=True
   try:await super()._handler(websocket)
   finally:self.active=False
 policy=Policy(a.checkpoint);Server(policy,host='127.0.0.1',port=a.port,metadata=policy.metadata).serve_forever()
if __name__=='__main__':main()
