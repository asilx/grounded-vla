"""Finite fallback: inspect authoritative V17A outcome, run GRU only without reproducible success."""
from pathlib import Path
import datetime,json,os,subprocess,time
ROOT=Path('/workspace/grounded-vla');STATUS=Path('/workspace/grounded-forge-status');os.chdir(ROOT)
state=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='waiting_for_v17a',scope='V17A sampling correction first; V17B causal GRU only if V17A has no reproducible seed0/1/2 success')
path=STATUS/'v17a-to-v17b-stage.json'
def save():path.write_text(json.dumps(state,indent=2))
env=dict(os.environ,OPENPI_SOURCE='/workspace/support/openpi-source',JAX_PLATFORMS='cpu',TOKENIZERS_PARALLELISM='false')
try:
 save();deadline=time.monotonic()+6000
 while True:
  p=STATUS/'learned-baseline-v17-audit.json'
  if p.exists():
   a=json.loads(p.read_text())
   if a.get('status') in ('completed','error'):break
  p=STATUS/'v17-pipeline.exit'
  if p.exists() and int(p.read_text())!=0:raise RuntimeError('V17A pipeline error; not a completed physical failure')
  if time.monotonic()>deadline:raise TimeoutError('V17A outcome deadline')
  time.sleep(5)
 successes={e['seed'] for e in a.get('attempts',[]) if e['result'].get('verified') and e['result'].get('task_success')}
 state['v17a_successful_seeds']=sorted(successes);save()
 if a.get('status')!='completed':raise RuntimeError('V17A invalid infrastructure outcome; preserve rather than treating as learned failure')
 if successes=={0,1,2}:state.update(status='v17a_reproducible_success_no_gru_needed');save()
 else:
  state['status']='testing_recurrent_contracts';save()
  subprocess.run(['/workspace/pi0-train-env/bin/python','-m','pytest','tests/test_recurrent_v17b.py','tests/test_gripper_direction_v17.py','-q'],env=env,check=True)
  state['status']='training_v17b';save()
  with (STATUS/'learned-baseline-v17b-train.log').open('w') as log:
   code=subprocess.run(['/workspace/pi0-train-env/bin/python','-u','experiments/runpod/learned_recurrent_v17b.py','train','data/franka-recovery-v16/prepared.json','runs/learned-graph-baseline-v17b','--updates','1200'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600).returncode
  (STATUS/'learned-baseline-v17b-train.exit').write_text(str(code));assert code==0
  state['status']='evaluating_v17b';save()
  with (STATUS/'learned-baseline-v17b-eval.log').open('w') as log:
   subprocess.run(['/workspace/pi0-train-env/bin/python','-u','experiments/runpod/evaluate_baseline_v17b.py'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=10800,check=True)
  b=json.loads((STATUS/'learned-baseline-v17b-audit.json').read_text());state.update(status='completed',v17b_audit_status=b.get('status'),v17b_successful_seeds=sorted({e['seed'] for e in b.get('attempts',[]) if e['result'].get('verified') and e['result'].get('task_success')}));save()
except BaseException as e:
 state.update(status='error',error_type=type(e).__name__,error=str(e));save();raise
